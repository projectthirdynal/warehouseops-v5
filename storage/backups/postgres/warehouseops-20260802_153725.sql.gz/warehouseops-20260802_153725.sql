--
-- PostgreSQL database dump
--

\restrict dsYlgNfZzfKEZDKQ2NN8DEyzyOQSxZMlvfF8RvUnUa03SfoNVIH9GjSpUzoOf1G

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: protect_waybill_terminal_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.protect_waybill_terminal_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                -- If existing record has a terminal status, preserve it
                IF OLD.status IN ('DELIVERED', 'RETURNED', 'CANCELLED') THEN
                    NEW.status = OLD.status;
                    NEW.delivered_at = COALESCE(OLD.delivered_at, NEW.delivered_at);
                    NEW.returned_at = COALESCE(OLD.returned_at, NEW.returned_at);
                END IF;

                -- Never overwrite a valid delivered_at with null
                IF OLD.delivered_at IS NOT NULL AND NEW.delivered_at IS NULL THEN
                    NEW.delivered_at = OLD.delivered_at;
                END IF;

                -- Never overwrite a valid returned_at with null
                IF OLD.returned_at IS NOT NULL AND NEW.returned_at IS NULL THEN
                    NEW.returned_at = OLD.returned_at;
                END IF;

                -- Never overwrite a valid dispatched_at with null
                IF OLD.dispatched_at IS NOT NULL AND NEW.dispatched_at IS NULL THEN
                    NEW.dispatched_at = OLD.dispatched_at;
                END IF;

                RETURN NEW;
            END;
            $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    entity_type character varying(255),
    entity_id bigint,
    metadata json,
    ip_address character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activity_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: address_correction_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.address_correction_history (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    user_id bigint,
    before json NOT NULL,
    after json NOT NULL,
    confidence_before double precision DEFAULT '0'::double precision NOT NULL,
    confidence_after double precision DEFAULT '0'::double precision NOT NULL,
    action character varying(255) DEFAULT 'manual_edit'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: address_correction_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.address_correction_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: address_correction_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.address_correction_history_id_seq OWNED BY public.address_correction_history.id;


--
-- Name: address_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.address_mappings (
    id bigint NOT NULL,
    country character varying(255) DEFAULT 'PH'::character varying NOT NULL,
    region character varying(255),
    province character varying(255) NOT NULL,
    city_municipality character varying(255) NOT NULL,
    barangay character varying(255),
    island_group character varying(255),
    courier_zone character varying(255),
    postal_code character varying(255),
    aliases json,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: address_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.address_mappings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: address_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.address_mappings_id_seq OWNED BY public.address_mappings.id;


--
-- Name: addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.addresses (
    id bigint NOT NULL,
    third_party_id bigint NOT NULL,
    type character varying(255) DEFAULT 'billing'::character varying NOT NULL,
    label character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    address_line1 character varying(255) NOT NULL,
    address_line2 character varying(255),
    barangay character varying(255),
    city character varying(255) NOT NULL,
    state_province character varying(255),
    postal_code character varying(255),
    country character varying(255) DEFAULT 'Philippines'::character varying NOT NULL,
    contact_name character varying(255),
    contact_phone character varying(255),
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.addresses_id_seq OWNED BY public.addresses.id;


--
-- Name: agent_badges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_badges (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    badge_id bigint NOT NULL,
    metadata json,
    awarded_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agent_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_badges_id_seq OWNED BY public.agent_badges.id;


--
-- Name: agent_commissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_commissions (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_id bigint,
    lead_id bigint,
    waybill_id bigint,
    sale_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    commission_rate numeric(8,4) DEFAULT '0'::numeric NOT NULL,
    commission_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    earned_at timestamp(0) without time zone,
    approved_at timestamp(0) without time zone,
    paid_at timestamp(0) without time zone,
    cancelled_at timestamp(0) without time zone,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agent_commissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_commissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_commissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_commissions_id_seq OWNED BY public.agent_commissions.id;


--
-- Name: agent_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flags (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    flag_type character varying(255) NOT NULL,
    severity character varying(255) DEFAULT 'warning'::character varying NOT NULL,
    description text NOT NULL,
    metadata json,
    is_resolved boolean DEFAULT false NOT NULL,
    resolved_by bigint,
    resolved_at timestamp(0) without time zone,
    resolution_notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agent_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_flags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_flags_id_seq OWNED BY public.agent_flags.id;


--
-- Name: agent_milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_milestones (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    milestone_id bigint NOT NULL,
    current_value integer DEFAULT 0 NOT NULL,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agent_milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_milestones_id_seq OWNED BY public.agent_milestones.id;


--
-- Name: agent_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_profiles (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    max_active_cycles integer DEFAULT 10 NOT NULL,
    product_skills json,
    regions json,
    priority_weight numeric(3,2) DEFAULT '1'::numeric NOT NULL,
    is_available boolean DEFAULT true NOT NULL,
    performance_score integer DEFAULT 50 NOT NULL,
    last_assignment_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    distribution_weight numeric(3,2) DEFAULT '1'::numeric NOT NULL,
    auto_assign_enabled boolean DEFAULT true NOT NULL,
    shift_start time(0) without time zone,
    shift_end time(0) without time zone,
    max_daily_leads integer DEFAULT 50 NOT NULL,
    concurrent_lead_cap integer,
    preferred_lead_sources json,
    excluded_regions json,
    category_skills json,
    last_seen_at timestamp(0) without time zone,
    max_active_conversations integer DEFAULT 15 NOT NULL,
    overflow_enabled boolean DEFAULT true NOT NULL,
    idle_threshold_minutes integer DEFAULT 15 NOT NULL
);


--
-- Name: agent_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_profiles_id_seq OWNED BY public.agent_profiles.id;


--
-- Name: agent_streaks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_streaks (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    streak_type character varying(50) DEFAULT 'daily_activity'::character varying NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    last_activity_date date,
    streak_started_at date,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: agent_streaks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_streaks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_streaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_streaks_id_seq OWNED BY public.agent_streaks.id;


--
-- Name: agent_workloads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_workloads (
    agent_id bigint NOT NULL,
    active_leads_count integer DEFAULT 0 NOT NULL,
    today_assigned_count integer DEFAULT 0 NOT NULL,
    today_converted_count integer DEFAULT 0 NOT NULL,
    last_assigned_at timestamp(0) without time zone,
    next_available_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: approval_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_rules (
    id bigint NOT NULL,
    module character varying(20) NOT NULL,
    role_required character varying(30) NOT NULL,
    min_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    max_amount numeric(14,2),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: approval_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approval_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_rules_id_seq OWNED BY public.approval_rules.id;


--
-- Name: approval_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_settings (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    value character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: approval_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approval_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_settings_id_seq OWNED BY public.approval_settings.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    auditable_type character varying(255) NOT NULL,
    auditable_id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    old_values json,
    new_values json,
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auto_merge_suggestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_merge_suggestions (
    id bigint NOT NULL,
    target_customer_id bigint NOT NULL,
    source_customer_id bigint NOT NULL,
    confidence_score double precision DEFAULT '0'::double precision NOT NULL,
    match_reasons json,
    merge_preview json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    actioned_by bigint,
    actioned_at timestamp(0) without time zone,
    action_note text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: auto_merge_suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_merge_suggestions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auto_merge_suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_merge_suggestions_id_seq OWNED BY public.auto_merge_suggestions.id;


--
-- Name: badges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.badges (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    icon character varying(255) DEFAULT 'Award'::character varying NOT NULL,
    color character varying(20) DEFAULT 'primary'::character varying NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying NOT NULL,
    criteria_type character varying(50),
    criteria_value integer,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: badges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.badges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.badges_id_seq OWNED BY public.badges.id;


--
-- Name: batch_item_error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_item_error_logs (
    id bigint NOT NULL,
    courier_export_batch_id bigint NOT NULL,
    courier_export_row_id bigint NOT NULL,
    order_id bigint,
    error_type character varying(255) DEFAULT 'export'::character varying NOT NULL,
    error_message text NOT NULL,
    severity character varying(255) DEFAULT 'error'::character varying NOT NULL,
    resolution character varying(255),
    resolved_at timestamp(0) without time zone,
    resolved_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: batch_item_error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_item_error_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_item_error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_item_error_logs_id_seq OWNED BY public.batch_item_error_logs.id;


--
-- Name: batch_scan_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_scan_items (
    id bigint NOT NULL,
    batch_session_id bigint NOT NULL,
    waybill_id bigint,
    scanned_value character varying(255) NOT NULL,
    is_valid boolean DEFAULT false NOT NULL,
    error_message character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: batch_scan_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_scan_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_scan_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_scan_items_id_seq OWNED BY public.batch_scan_items.id;


--
-- Name: batch_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    scanned_count integer DEFAULT 0 NOT NULL,
    valid_count integer DEFAULT 0 NOT NULL,
    invalid_count integer DEFAULT 0 NOT NULL,
    started_at timestamp(0) without time zone NOT NULL,
    closed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: batch_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_sessions_id_seq OWNED BY public.batch_sessions.id;


--
-- Name: batch_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_status_history (
    id bigint NOT NULL,
    courier_export_batch_id bigint NOT NULL,
    from_status character varying(255),
    to_status character varying(255) NOT NULL,
    changed_by bigint,
    notes character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: batch_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_status_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_status_history_id_seq OWNED BY public.batch_status_history.id;


--
-- Name: broadcast_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broadcast_campaigns (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    facebook_page_id bigint,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    targeting json,
    split_type character varying(255) DEFAULT 'single'::character varying NOT NULL,
    split_percentage integer DEFAULT 50 NOT NULL,
    total_recipients integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    delivered_count integer DEFAULT 0 NOT NULL,
    read_count integer DEFAULT 0 NOT NULL,
    replied_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    scheduled_at timestamp(0) without time zone,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: broadcast_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.broadcast_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: broadcast_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.broadcast_campaigns_id_seq OWNED BY public.broadcast_campaigns.id;


--
-- Name: broadcast_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broadcast_recipients (
    id bigint NOT NULL,
    broadcast_campaign_id bigint NOT NULL,
    broadcast_variant_id bigint,
    conversation_id bigint NOT NULL,
    customer_id bigint,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    error_message text,
    message_id bigint,
    sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.broadcast_recipients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.broadcast_recipients_id_seq OWNED BY public.broadcast_recipients.id;


--
-- Name: broadcast_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broadcast_variants (
    id bigint NOT NULL,
    broadcast_campaign_id bigint NOT NULL,
    label character varying(255) NOT NULL,
    body text NOT NULL,
    quick_replies json,
    recipient_count integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    delivered_count integer DEFAULT 0 NOT NULL,
    read_count integer DEFAULT 0 NOT NULL,
    replied_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: broadcast_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.broadcast_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: broadcast_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.broadcast_variants_id_seq OWNED BY public.broadcast_variants.id;


--
-- Name: capex_asset_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capex_asset_assignments (
    id bigint NOT NULL,
    capex_asset_id bigint NOT NULL,
    assigned_to bigint NOT NULL,
    department character varying(100),
    location character varying(200),
    assigned_at timestamp(0) without time zone NOT NULL,
    returned_at timestamp(0) without time zone,
    assigned_by bigint NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: capex_asset_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.capex_asset_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: capex_asset_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.capex_asset_assignments_id_seq OWNED BY public.capex_asset_assignments.id;


--
-- Name: capex_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capex_assets (
    id bigint NOT NULL,
    asset_code character varying(60) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(40) DEFAULT 'OTHER'::character varying NOT NULL,
    depreciation_years smallint NOT NULL,
    purchase_date date NOT NULL,
    acquisition_cost numeric(15,4) NOT NULL,
    salvage_value numeric(15,4) DEFAULT '0'::numeric NOT NULL,
    current_book_value numeric(15,4) DEFAULT '0'::numeric NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    warehouse_id bigint,
    assigned_to bigint,
    department character varying(100),
    uom_id bigint,
    quantity integer DEFAULT 1 NOT NULL,
    disposed_at timestamp(0) without time zone,
    disposal_reason character varying(500),
    disposal_value numeric(15,4),
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: capex_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.capex_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: capex_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.capex_assets_id_seq OWNED BY public.capex_assets.id;


--
-- Name: capex_depreciation_schedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capex_depreciation_schedule (
    id bigint NOT NULL,
    capex_asset_id bigint NOT NULL,
    year smallint NOT NULL,
    fiscal_year smallint NOT NULL,
    opening_book_value numeric(15,4) NOT NULL,
    depreciation_amount numeric(15,4) NOT NULL,
    closing_book_value numeric(15,4) NOT NULL,
    depreciation_date date NOT NULL,
    is_posted boolean DEFAULT false NOT NULL,
    posted_at timestamp(0) without time zone,
    posted_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: capex_depreciation_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.capex_depreciation_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: capex_depreciation_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.capex_depreciation_schedule_id_seq OWNED BY public.capex_depreciation_schedule.id;


--
-- Name: cart_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_templates (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    items json NOT NULL,
    courier_code character varying(255),
    shipping_fee numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    discount_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    remarks text,
    is_shared boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: cart_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cart_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cart_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cart_templates_id_seq OWNED BY public.cart_templates.id;


--
-- Name: claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.claims (
    id bigint NOT NULL,
    claim_number character varying(30) NOT NULL,
    waybill_id bigint NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'DRAFT'::character varying NOT NULL,
    description text,
    claim_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    approved_amount numeric(10,2),
    jnt_reference_number character varying(255),
    filed_by bigint NOT NULL,
    filed_at timestamp(0) without time zone,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    resolved_at timestamp(0) without time zone,
    resolution_notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    auto_created boolean DEFAULT false NOT NULL,
    source character varying(255) DEFAULT 'manual'::character varying NOT NULL
);


--
-- Name: claims_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.claims_id_seq OWNED BY public.claims.id;


--
-- Name: cod_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cod_settlements (
    id bigint NOT NULL,
    courier_code character varying(255) NOT NULL,
    reference_number character varying(255),
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_cod_collected numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    courier_fee numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    net_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    order_count integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    received_at timestamp(0) without time zone,
    reconciled_at timestamp(0) without time zone,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: cod_settlements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cod_settlements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cod_settlements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cod_settlements_id_seq OWNED BY public.cod_settlements.id;


--
-- Name: cogs_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cogs_entries (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    waybill_id bigint,
    order_id bigint,
    cost_lot_id bigint,
    method character varying(20) DEFAULT 'FIFO'::character varying NOT NULL,
    quantity numeric(12,4) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    total_cost numeric(14,4) NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    exchange_rate numeric(14,6) DEFAULT '1'::numeric NOT NULL,
    recorded_at timestamp(0) without time zone NOT NULL,
    synced_to_qbo_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: cogs_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cogs_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cogs_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cogs_entries_id_seq OWNED BY public.cogs_entries.id;


--
-- Name: commission_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commission_rules (
    id bigint NOT NULL,
    product_id bigint,
    rate_type character varying(255) DEFAULT 'PERCENTAGE'::character varying NOT NULL,
    rate_value numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    min_sale_amount numeric(10,2),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: commission_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commission_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: commission_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.commission_rules_id_seq OWNED BY public.commission_rules.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    third_party_id bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255),
    title character varying(255),
    "position" character varying(255),
    department character varying(255),
    email character varying(255),
    phone character varying(255),
    phone_alt character varying(255),
    is_primary boolean DEFAULT false NOT NULL,
    notes text,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: conversation_assignment_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_assignment_histories (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    from_agent_id bigint,
    to_agent_id bigint,
    assigned_by_id bigint,
    reason character varying(255) DEFAULT 'manual'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: conversation_assignment_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_assignment_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_assignment_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_assignment_histories_id_seq OWNED BY public.conversation_assignment_histories.id;


--
-- Name: conversation_exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_exports (
    id bigint NOT NULL,
    export_number character varying(255) NOT NULL,
    created_by bigint,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    conversation_count integer DEFAULT 0 NOT NULL,
    message_count integer DEFAULT 0 NOT NULL,
    file_path character varying(255),
    filters json,
    exported_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: conversation_exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_exports_id_seq OWNED BY public.conversation_exports.id;


--
-- Name: conversation_status_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_status_histories (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    from_status character varying(255),
    to_status character varying(255) NOT NULL,
    changed_by_id bigint,
    changed_by_role character varying(255),
    reason text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: conversation_status_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_status_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_status_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_status_histories_id_seq OWNED BY public.conversation_status_histories.id;


--
-- Name: conversation_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_tag (
    conversation_id bigint NOT NULL,
    tag_id bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id bigint NOT NULL,
    facebook_page_id bigint,
    customer_id bigint,
    customer_identity_id bigint,
    assigned_agent_id bigint,
    channel character varying(255) DEFAULT 'messenger'::character varying NOT NULL,
    status character varying(255) DEFAULT 'open'::character varying NOT NULL,
    thread_key character varying(255),
    last_message_preview text,
    last_message_at timestamp(0) without time zone,
    unread_count integer DEFAULT 0 NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    priority character varying(255) DEFAULT 'normal'::character varying NOT NULL,
    is_flagged boolean DEFAULT false NOT NULL,
    flag_reason text,
    flagged_at timestamp(0) without time zone,
    snoozed_until timestamp(0) without time zone,
    reminder_at timestamp(0) without time zone,
    snooze_reason text,
    merged_into_id bigint,
    first_response_at timestamp(0) without time zone,
    resolved_at timestamp(0) without time zone,
    first_response_time_seconds integer,
    resolution_time_seconds integer,
    sentiment character varying(255) DEFAULT 'neutral'::character varying NOT NULL,
    sentiment_score double precision DEFAULT '0'::double precision NOT NULL,
    typing_at timestamp(0) without time zone,
    draft_body text,
    archived_at timestamp(0) without time zone,
    compressed_at timestamp(0) without time zone,
    message_count integer DEFAULT 0 NOT NULL
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: courier_api_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_api_logs (
    id bigint NOT NULL,
    courier_provider_id bigint,
    courier_code character varying(255) NOT NULL,
    action character varying(255) NOT NULL,
    direction character varying(255) NOT NULL,
    endpoint character varying(255),
    request_data json,
    response_data json,
    http_status integer,
    is_success boolean DEFAULT false NOT NULL,
    error_message text,
    response_time_ms numeric(10,2),
    waybill_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_api_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_api_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_api_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_api_logs_id_seq OWNED BY public.courier_api_logs.id;


--
-- Name: courier_csv_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_csv_templates (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    courier_code character varying(30) NOT NULL,
    columns json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_csv_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_csv_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_csv_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_csv_templates_id_seq OWNED BY public.courier_csv_templates.id;


--
-- Name: courier_csv_validation_error_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_csv_validation_error_logs (
    id bigint NOT NULL,
    courier_export_batch_id bigint,
    courier_export_row_id bigint,
    order_id bigint,
    courier_code character varying(30),
    error_type character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    error_message text NOT NULL,
    context json,
    source character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_csv_validation_error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_csv_validation_error_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_csv_validation_error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_csv_validation_error_logs_id_seq OWNED BY public.courier_csv_validation_error_logs.id;


--
-- Name: courier_export_batch_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_export_batch_shares (
    id bigint NOT NULL,
    courier_export_batch_id bigint NOT NULL,
    token character varying(64) NOT NULL,
    created_by bigint,
    expires_at timestamp(0) without time zone NOT NULL,
    revoked_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_export_batch_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_export_batch_shares_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_export_batch_shares_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_export_batch_shares_id_seq OWNED BY public.courier_export_batch_shares.id;


--
-- Name: courier_export_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_export_batches (
    id bigint NOT NULL,
    batch_number character varying(255) NOT NULL,
    courier_code character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    created_by bigint,
    row_count integer DEFAULT 0 NOT NULL,
    file_path character varying(255),
    exported_at timestamp(0) without time zone,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    downloaded_at timestamp(0) without time zone,
    archived_at timestamp(0) without time zone,
    region character varying(255),
    notes text,
    file_size bigint,
    file_hash character varying(64),
    file_generated_at timestamp(0) without time zone
);


--
-- Name: courier_export_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_export_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_export_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_export_batches_id_seq OWNED BY public.courier_export_batches.id;


--
-- Name: courier_export_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_export_rows (
    id bigint NOT NULL,
    courier_export_batch_id bigint NOT NULL,
    order_id bigint,
    row_number integer,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    receiver_name character varying(255),
    phone_number character varying(255),
    complete_address text,
    province character varying(255),
    city character varying(255),
    barangay character varying(255),
    landmark character varying(255),
    product_name character varying(255),
    cod_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    remarks text,
    payload json,
    error_message text,
    exported_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_export_rows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_export_rows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_export_rows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_export_rows_id_seq OWNED BY public.courier_export_rows.id;


--
-- Name: courier_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_providers (
    id bigint NOT NULL,
    code character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    config json,
    api_endpoint character varying(255),
    webhook_secret character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_providers_id_seq OWNED BY public.courier_providers.id;


--
-- Name: courier_sync_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_sync_logs (
    id bigint NOT NULL,
    run_id character varying(255) NOT NULL,
    courier_code character varying(255),
    trigger character varying(255) DEFAULT 'scheduled'::character varying NOT NULL,
    waybills_checked integer DEFAULT 0 NOT NULL,
    waybills_updated integer DEFAULT 0 NOT NULL,
    waybills_unchanged integer DEFAULT 0 NOT NULL,
    errors_count integer DEFAULT 0 NOT NULL,
    errors json,
    per_courier json,
    duration_ms integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'completed'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: courier_sync_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courier_sync_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courier_sync_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courier_sync_logs_id_seq OWNED BY public.courier_sync_logs.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currencies (
    code character(3) NOT NULL,
    name character varying(60) NOT NULL,
    symbol character varying(6) NOT NULL,
    decimal_places smallint DEFAULT '2'::smallint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: customer_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_addresses (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    label character varying(255),
    canonical_address text,
    landmark character varying(255),
    barangay character varying(255),
    city_municipality character varying(255),
    province character varying(255),
    region character varying(255),
    postal_code character varying(255),
    country character varying(255) DEFAULT 'Philippines'::character varying NOT NULL,
    contact_name character varying(255),
    contact_phone character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    source character varying(255),
    used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: customer_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_addresses_id_seq OWNED BY public.customer_addresses.id;


--
-- Name: customer_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_audit_logs (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    field character varying(255),
    before_state json,
    after_state json,
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: customer_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_audit_logs_id_seq OWNED BY public.customer_audit_logs.id;


--
-- Name: customer_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_identities (
    id bigint NOT NULL,
    customer_id bigint,
    facebook_page_id bigint,
    provider character varying(255) DEFAULT 'facebook'::character varying NOT NULL,
    provider_user_id character varying(255) NOT NULL,
    display_name character varying(255),
    profile_pic_url character varying(255),
    phone_detected character varying(255),
    first_seen_at timestamp(0) without time zone,
    last_seen_at timestamp(0) without time zone,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: customer_identities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_identities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_identities_id_seq OWNED BY public.customer_identities.id;


--
-- Name: customer_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_notes (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    user_id bigint,
    note_type character varying(255) DEFAULT 'agent_note'::character varying NOT NULL,
    body text NOT NULL,
    tags jsonb,
    metadata jsonb,
    pinned_until timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: customer_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_notes_id_seq OWNED BY public.customer_notes.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id bigint NOT NULL,
    phone character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    canonical_address text,
    total_orders integer DEFAULT 0 NOT NULL,
    successful_orders integer DEFAULT 0 NOT NULL,
    returned_orders integer DEFAULT 0 NOT NULL,
    success_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    total_revenue numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    risk_level character varying(255) DEFAULT 'LOW'::character varying NOT NULL,
    is_blacklisted boolean DEFAULT false NOT NULL,
    blacklist_reason text,
    blacklisted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    normalized_phone character varying(255),
    facebook_name character varying(255),
    landmark character varying(255),
    barangay character varying(255),
    city_municipality character varying(255),
    province character varying(255),
    region character varying(255),
    last_page_ordered_from bigint,
    last_order_date timestamp(0) without time zone,
    tags jsonb,
    average_order_value numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    preferred_courier character varying(255),
    payment_method character varying(255),
    preferred_contact_method character varying(255),
    preferred_contact_time character varying(255),
    marketing_opt_out boolean DEFAULT false NOT NULL,
    language_preference character varying(255),
    profile_image_path character varying(255),
    CONSTRAINT customers_risk_level_check CHECK (((risk_level)::text = ANY ((ARRAY['LOW'::character varying, 'MEDIUM'::character varying, 'HIGH'::character varying, 'BLACKLISTED'::character varying])::text[])))
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: dashboard_widget_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_widget_configs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    dashboard character varying(50) DEFAULT 'sales'::character varying NOT NULL,
    widget_key character varying(100) NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    settings json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: dashboard_widget_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dashboard_widget_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dashboard_widget_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dashboard_widget_configs_id_seq OWNED BY public.dashboard_widget_configs.id;


--
-- Name: dead_stocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dead_stocks (
    id bigint NOT NULL,
    item_type character varying(20) NOT NULL,
    supply_id bigint,
    product_id bigint,
    warehouse_id bigint,
    quantity integer NOT NULL,
    unit_cost numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    total_value numeric(14,4) DEFAULT '0'::numeric NOT NULL,
    reason character varying(500),
    recorded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: dead_stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dead_stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dead_stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dead_stocks_id_seq OWNED BY public.dead_stocks.id;


--
-- Name: delivery_proofs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_proofs (
    id bigint NOT NULL,
    waybill_id bigint NOT NULL,
    type character varying(255) DEFAULT 'photo'::character varying NOT NULL,
    file_path character varying(255) NOT NULL,
    original_filename character varying(255),
    mime_type character varying(100),
    file_size integer,
    source character varying(255) DEFAULT 'manual_upload'::character varying NOT NULL,
    courier_code character varying(20),
    metadata json,
    uploaded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT delivery_proofs_source_check CHECK (((source)::text = ANY ((ARRAY['courier_callback'::character varying, 'manual_upload'::character varying, 'courier_api'::character varying])::text[]))),
    CONSTRAINT delivery_proofs_type_check CHECK (((type)::text = ANY ((ARRAY['photo'::character varying, 'signature'::character varying, 'pod_document'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: delivery_proofs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delivery_proofs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delivery_proofs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delivery_proofs_id_seq OWNED BY public.delivery_proofs.id;


--
-- Name: distribution_queues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distribution_queues (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    rule_id bigint,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    assigned_agent_id bigint,
    score_snapshot json,
    attempt_count integer DEFAULT 0 NOT NULL,
    processed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: distribution_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.distribution_queues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: distribution_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.distribution_queues_id_seq OWNED BY public.distribution_queues.id;


--
-- Name: distribution_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distribution_rules (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    strategy character varying(255) NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    filters json,
    weight_formula json,
    is_active boolean DEFAULT true NOT NULL,
    supervisor_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: distribution_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.distribution_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: distribution_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.distribution_rules_id_seq OWNED BY public.distribution_rules.id;


--
-- Name: duplicate_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_audit_logs (
    id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    entity_type character varying(255),
    entity_id bigint,
    entity_label character varying(255),
    before_state json,
    after_state json,
    note text,
    ip_address character varying(255),
    user_agent character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_audit_logs_id_seq OWNED BY public.duplicate_audit_logs.id;


--
-- Name: duplicate_detection_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_detection_rules (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    match_method character varying(255),
    is_enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    config json,
    description text,
    created_by bigint,
    updated_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_detection_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_detection_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_detection_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_detection_rules_id_seq OWNED BY public.duplicate_detection_rules.id;


--
-- Name: duplicate_families; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_families (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    group_key character varying(255),
    group_method character varying(255),
    anchor_ref_id bigint,
    anchor_label character varying(255),
    member_count integer DEFAULT 0 NOT NULL,
    merged_count integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    metadata json,
    actioned_by bigint,
    actioned_at timestamp(0) without time zone,
    action_note text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_families_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_families_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_families_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_families_id_seq OWNED BY public.duplicate_families.id;


--
-- Name: duplicate_family_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_family_members (
    id bigint NOT NULL,
    family_id bigint NOT NULL,
    customer_id bigint,
    is_anchor boolean DEFAULT false NOT NULL,
    member_data json,
    match_reason character varying(255),
    similarity_score double precision,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_family_members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_family_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_family_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_family_members_id_seq OWNED BY public.duplicate_family_members.id;


--
-- Name: duplicate_ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_ml_models (
    id bigint NOT NULL,
    name character varying(255) DEFAULT 'default'::character varying NOT NULL,
    version character varying(255) DEFAULT 'v1'::character varying NOT NULL,
    feature_weights json,
    training_stats json,
    training_samples integer DEFAULT 0 NOT NULL,
    accuracy double precision,
    "precision" double precision,
    recall double precision,
    f1_score double precision,
    trained_at timestamp(0) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_ml_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_ml_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_ml_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_ml_models_id_seq OWNED BY public.duplicate_ml_models.id;


--
-- Name: duplicate_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_notifications (
    id bigint NOT NULL,
    user_id bigint,
    type character varying(255) NOT NULL,
    severity character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    entity_type character varying(255),
    entity_id bigint,
    action_url character varying(255),
    action_label character varying(255),
    metadata json,
    read_at timestamp(0) without time zone,
    read_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_notifications_id_seq OWNED BY public.duplicate_notifications.id;


--
-- Name: duplicate_review_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.duplicate_review_items (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    primary_ref_id bigint,
    duplicate_ref_id bigint,
    primary_label character varying(255),
    duplicate_label character varying(255),
    match_method character varying(255),
    similarity_score double precision,
    severity character varying(255) DEFAULT 'low'::character varying NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    metadata json,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    review_note text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: duplicate_review_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.duplicate_review_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: duplicate_review_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.duplicate_review_items_id_seq OWNED BY public.duplicate_review_items.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_rates (
    id bigint NOT NULL,
    from_currency character(3) NOT NULL,
    to_currency character(3) NOT NULL,
    rate numeric(14,6) NOT NULL,
    rate_date date NOT NULL,
    source character varying(30) DEFAULT 'manual'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exchange_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: facebook_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.facebook_accounts (
    id bigint NOT NULL,
    user_id bigint,
    facebook_user_id character varying(255) NOT NULL,
    facebook_user_name character varying(255),
    email character varying(255),
    access_token text,
    token_expires_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'connected'::character varying NOT NULL,
    connected_at timestamp(0) without time zone,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: facebook_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.facebook_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: facebook_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.facebook_accounts_id_seq OWNED BY public.facebook_accounts.id;


--
-- Name: facebook_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.facebook_pages (
    id bigint NOT NULL,
    facebook_account_id bigint,
    connected_by bigint,
    page_id character varying(255) NOT NULL,
    page_name character varying(255) NOT NULL,
    category character varying(255),
    business_id character varying(255),
    page_access_token text,
    token_expires_at timestamp(0) without time zone,
    connected_status character varying(255) DEFAULT 'disconnected'::character varying NOT NULL,
    webhook_status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    last_sync_at timestamp(0) without time zone,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    default_courier character varying(255)
);


--
-- Name: facebook_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.facebook_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: facebook_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.facebook_pages_id_seq OWNED BY public.facebook_pages.id;


--
-- Name: facebook_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.facebook_webhook_events (
    id bigint NOT NULL,
    facebook_page_id bigint,
    event_id character varying(255),
    object character varying(255),
    event_type character varying(255),
    sender_psid character varying(255),
    recipient_id character varying(255),
    payload json NOT NULL,
    signature_valid boolean DEFAULT false NOT NULL,
    processed_at timestamp(0) without time zone,
    error_message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: facebook_webhook_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.facebook_webhook_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: facebook_webhook_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.facebook_webhook_events_id_seq OWNED BY public.facebook_webhook_events.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: finance_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.finance_settings (
    id bigint NOT NULL,
    key character varying(60) NOT NULL,
    value json NOT NULL,
    locked_at timestamp(0) without time zone,
    locked_by bigint,
    locked_trigger_reference character varying(120),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: finance_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.finance_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: finance_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.finance_settings_id_seq OWNED BY public.finance_settings.id;


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_transactions (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    amount numeric(12,2) NOT NULL,
    reference_type character varying(255),
    reference_id bigint,
    description text,
    recorded_by bigint,
    transaction_date date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.financial_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.financial_transactions_id_seq OWNED BY public.financial_transactions.id;


--
-- Name: fraud_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fraud_flags (
    id bigint NOT NULL,
    agent_id bigint NOT NULL,
    lead_id bigint,
    flag_type character varying(255) NOT NULL,
    severity character varying(255) DEFAULT 'WARNING'::character varying NOT NULL,
    details json,
    is_reviewed boolean DEFAULT false NOT NULL,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    resolution_notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: fraud_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fraud_flags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fraud_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fraud_flags_id_seq OWNED BY public.fraud_flags.id;


--
-- Name: import_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_chunks (
    id bigint NOT NULL,
    upload_id bigint NOT NULL,
    chunk_number integer NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    rows_count integer DEFAULT 0 NOT NULL,
    inserted_count integer DEFAULT 0 NOT NULL,
    updated_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    errors json,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: import_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.import_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: import_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.import_chunks_id_seq OWNED BY public.import_chunks.id;


--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    type character varying(255) NOT NULL,
    quantity integer NOT NULL,
    reference_type character varying(255),
    reference_id bigint,
    notes text,
    performed_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    warehouse_id bigint,
    location_id bigint,
    to_location_id bigint,
    batch_number character varying(60),
    expiry_date date,
    approved_by bigint,
    approved_at timestamp(0) without time zone
);


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_id_seq OWNED BY public.inventory_movements.id;


--
-- Name: invoice_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_lines (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    product_id bigint,
    product_ref character varying(255),
    description character varying(255) NOT NULL,
    unit character varying(255),
    qty numeric(10,3) DEFAULT '1'::numeric NOT NULL,
    unit_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    discount_pct numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    discount_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_ht numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_ttc numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: invoice_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_lines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_lines_id_seq OWNED BY public.invoice_lines.id;


--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_payments (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_date date NOT NULL,
    payment_method character varying(255) DEFAULT 'cash'::character varying NOT NULL,
    reference_number character varying(255),
    notes text,
    recorded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_payments_id_seq OWNED BY public.invoice_payments.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    ref character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'standard'::character varying NOT NULL,
    status character varying(255) DEFAULT 'DRAFT'::character varying NOT NULL,
    third_party_id bigint,
    client_name character varying(255) NOT NULL,
    client_email character varying(255),
    client_phone character varying(255),
    client_address text,
    order_id bigint,
    quotation_id bigint,
    date_invoice date NOT NULL,
    date_due date,
    date_sent date,
    payment_terms character varying(255),
    currency character varying(255) DEFAULT 'PHP'::character varying NOT NULL,
    subtotal numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    discount_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    shipping_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_paid numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_due numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    notes text,
    terms text,
    footer text,
    cancel_reason text,
    cancelled_at timestamp(0) without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: lead_cycles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_cycles (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    cycle_number integer NOT NULL,
    assigned_agent_id bigint NOT NULL,
    status character varying(255) DEFAULT 'ACTIVE'::character varying NOT NULL,
    outcome character varying(255),
    notes text,
    opened_at timestamp(0) without time zone NOT NULL,
    closed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    last_call_at timestamp(0) without time zone,
    call_count integer DEFAULT 0 NOT NULL,
    callback_at timestamp(0) without time zone,
    callback_notes text
);


--
-- Name: lead_cycles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_cycles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_cycles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_cycles_id_seq OWNED BY public.lead_cycles.id;


--
-- Name: lead_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_logs (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    user_id bigint,
    customer_id bigint,
    action character varying(255) NOT NULL,
    old_value character varying(255),
    new_value character varying(255),
    notes text,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: lead_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_logs_id_seq OWNED BY public.lead_logs.id;


--
-- Name: lead_pool_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_pool_audit (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    lead_cycle_id bigint,
    user_id bigint,
    action character varying(255) NOT NULL,
    old_value character varying(255),
    new_value character varying(255),
    metadata json,
    ip_address character varying(45),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: lead_pool_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_pool_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_pool_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_pool_audit_id_seq OWNED BY public.lead_pool_audit.id;


--
-- Name: lead_recycling_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_recycling_pool (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    previous_agent_id bigint,
    assigned_agent_id bigint,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    reason character varying(255),
    priority integer DEFAULT 0 NOT NULL,
    cooldown_hours integer DEFAULT 12 NOT NULL,
    available_at timestamp(0) without time zone NOT NULL,
    assigned_at timestamp(0) without time zone,
    processed_at timestamp(0) without time zone,
    outcome character varying(255),
    outcome_notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: lead_recycling_pool_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_recycling_pool_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_recycling_pool_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_recycling_pool_id_seq OWNED BY public.lead_recycling_pool.id;


--
-- Name: lead_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lead_snapshots (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    cycle_id bigint,
    data json NOT NULL,
    trigger_reason character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: lead_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lead_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lead_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lead_snapshots_id_seq OWNED BY public.lead_snapshots.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id bigint NOT NULL,
    customer_id bigint,
    recycling_pool_id bigint,
    name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    address text,
    city character varying(255),
    state character varying(255),
    barangay character varying(255),
    street character varying(255),
    postal_code character varying(255),
    status character varying(255) DEFAULT 'NEW'::character varying NOT NULL,
    sales_status character varying(255) DEFAULT 'NEW'::character varying NOT NULL,
    source character varying(255),
    assigned_to bigint,
    uploaded_by bigint,
    original_agent_id bigint,
    last_called_at timestamp(0) without time zone,
    call_attempts integer DEFAULT 0 NOT NULL,
    notes text,
    product_name character varying(255),
    product_brand character varying(255),
    previous_item character varying(255),
    amount numeric(10,2),
    assigned_at timestamp(0) without time zone,
    total_cycles integer DEFAULT 0 NOT NULL,
    max_cycles integer DEFAULT 3 NOT NULL,
    is_exhausted boolean DEFAULT false NOT NULL,
    quality_score integer,
    last_scored_at timestamp(0) without time zone,
    current_qa_level integer DEFAULT 1 NOT NULL,
    qa_required boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    pool_status character varying(255) DEFAULT 'AVAILABLE'::character varying NOT NULL,
    cooldown_until timestamp(0) without time zone
);


--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    facebook_page_id bigint,
    customer_identity_id bigint,
    external_message_id character varying(255),
    direction character varying(255) DEFAULT 'inbound'::character varying NOT NULL,
    message_type character varying(255) DEFAULT 'text'::character varying NOT NULL,
    body text,
    attachments json,
    phone_candidates json,
    raw_payload json,
    sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    read_at timestamp(0) without time zone,
    send_status character varying(255),
    send_error text,
    retry_count integer DEFAULT 0 NOT NULL,
    metadata json,
    reactions json,
    is_flagged boolean DEFAULT false NOT NULL,
    flag_reason character varying(255),
    translated_body text,
    translated_lang character varying(255),
    moderation_status character varying(255) DEFAULT 'approved'::character varying NOT NULL,
    moderation_note text,
    moderated_at timestamp(0) without time zone,
    moderated_by bigint,
    sent_by bigint
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: meta_data_deletion_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_data_deletion_requests (
    id bigint NOT NULL,
    confirmation_code character varying(255) NOT NULL,
    app_scoped_user_id character varying(255),
    status character varying(255) DEFAULT 'received'::character varying NOT NULL,
    source character varying(255) DEFAULT 'meta_callback'::character varying NOT NULL,
    payload json,
    result_summary json,
    requested_at timestamp(0) without time zone,
    processed_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: meta_data_deletion_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meta_data_deletion_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meta_data_deletion_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meta_data_deletion_requests_id_seq OWNED BY public.meta_data_deletion_requests.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.milestones (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    metric character varying(50) NOT NULL,
    target_value integer NOT NULL,
    period character varying(20) DEFAULT 'all_time'::character varying NOT NULL,
    reward_badge_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.milestones_id_seq OWNED BY public.milestones.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    type character varying(255) NOT NULL,
    notifiable_type character varying(255) NOT NULL,
    notifiable_id bigint NOT NULL,
    data text NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: order_remarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_remarks (
    id bigint NOT NULL,
    order_id bigint,
    conversation_id bigint,
    user_id bigint,
    type character varying(255) DEFAULT 'note'::character varying NOT NULL,
    body text NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    visibility character varying(255) DEFAULT 'internal'::character varying NOT NULL,
    parent_id bigint,
    mentions json,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at timestamp(0) without time zone,
    pinned_by bigint,
    tags json
);


--
-- Name: order_remarks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_remarks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_remarks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_remarks_id_seq OWNED BY public.order_remarks.id;


--
-- Name: order_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_tag (
    order_id bigint NOT NULL,
    tag_id bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    order_number character varying(255) NOT NULL,
    lead_id bigint,
    customer_id bigint,
    product_id bigint,
    variant_id bigint,
    assigned_agent_id bigint,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    courier_code character varying(255),
    waybill_id bigint,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    cod_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    shipping_cost numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    receiver_name character varying(255) NOT NULL,
    receiver_phone character varying(255) NOT NULL,
    receiver_address text NOT NULL,
    city character varying(255),
    state character varying(255),
    barangay character varying(255),
    postal_code character varying(255),
    notes text,
    rejection_reason text,
    confirmed_at timestamp(0) without time zone,
    dispatched_at timestamp(0) without time zone,
    delivered_at timestamp(0) without time zone,
    returned_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    conversation_id bigint,
    facebook_page_id bigint,
    encoder_id bigint,
    address_mapping_id bigint,
    source_channel character varying(255) DEFAULT 'manual'::character varying NOT NULL,
    address_confidence numeric(5,2),
    export_status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    encoded_at timestamp(0) without time zone,
    discount_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    draft_data json,
    parent_order_id bigint,
    remarks text,
    landmark character varying(255),
    nearest_landmark character varying(255),
    latitude numeric(10,7),
    longitude numeric(10,7),
    held_at timestamp(0) without time zone,
    hold_reason character varying(255),
    scheduled_delivery_at timestamp(0) without time zone,
    reschedule_reason character varying(255)
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: page_assignment_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_assignment_rules (
    id bigint NOT NULL,
    facebook_page_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: page_assignment_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.page_assignment_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: page_assignment_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.page_assignment_rules_id_seq OWNED BY public.page_assignment_rules.id;


--
-- Name: page_favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_favorites (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    facebook_page_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: page_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.page_favorites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: page_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.page_favorites_id_seq OWNED BY public.page_favorites.id;


--
-- Name: page_status_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_status_labels (
    id bigint NOT NULL,
    facebook_page_id bigint NOT NULL,
    status character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    color character varying(255)
);


--
-- Name: page_status_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.page_status_labels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: page_status_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.page_status_labels_id_seq OWNED BY public.page_status_labels.id;


--
-- Name: page_status_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_status_rules (
    id bigint NOT NULL,
    facebook_page_id bigint NOT NULL,
    from_status character varying(255) NOT NULL,
    to_status character varying(255) NOT NULL,
    inactivity_minutes integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: page_status_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.page_status_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: page_status_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.page_status_rules_id_seq OWNED BY public.page_status_rules.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    section character varying(255) NOT NULL,
    description character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: product_stocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_stocks (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    current_stock integer DEFAULT 0 NOT NULL,
    reserved_stock integer DEFAULT 0 NOT NULL,
    reorder_point integer DEFAULT 10 NOT NULL,
    last_restock_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    warehouse_id bigint,
    location_id bigint,
    last_movement_at timestamp(0) without time zone
);


--
-- Name: product_stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_stocks_id_seq OWNED BY public.product_stocks.id;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    sku character varying(255) NOT NULL,
    variant_name character varying(255) NOT NULL,
    selling_price numeric(10,2),
    cost_price numeric(10,2),
    weight_grams integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_variants_id_seq OWNED BY public.product_variants.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    sku character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    brand character varying(255),
    category character varying(255),
    selling_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    cost_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    weight_grams integer DEFAULT 0 NOT NULL,
    description text,
    image_url character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    requires_qa boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    barcode character varying(60),
    qr_code character varying(120),
    uom_id bigint,
    min_stock_level integer DEFAULT 0 NOT NULL,
    max_stock_level integer,
    expiry_tracking boolean DEFAULT false NOT NULL
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id bigint NOT NULL,
    po_id bigint NOT NULL,
    product_id bigint,
    supply_id bigint,
    variant_id bigint,
    uom_id bigint,
    quantity_ordered integer NOT NULL,
    quantity_received integer DEFAULT 0 NOT NULL,
    unit_price numeric(12,4) NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    line_total numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_order_items_id_seq OWNED BY public.purchase_order_items.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id bigint NOT NULL,
    po_number character varying(30) NOT NULL,
    pr_id bigint,
    supplier_id bigint NOT NULL,
    warehouse_id bigint NOT NULL,
    payment_terms character varying(60),
    expected_delivery_date date,
    status character varying(30) DEFAULT 'DRAFT'::character varying NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    exchange_rate numeric(14,6) DEFAULT '1'::numeric NOT NULL,
    exchange_rate_date date,
    subtotal numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    sent_at timestamp(0) without time zone,
    qbo_po_id character varying(60),
    notes text,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: purchase_request_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_request_items (
    id bigint NOT NULL,
    pr_id bigint NOT NULL,
    product_id bigint,
    supply_id bigint,
    variant_id bigint,
    uom_id bigint,
    quantity_requested integer NOT NULL,
    unit_price_estimate numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: purchase_request_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_request_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_request_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_request_items_id_seq OWNED BY public.purchase_request_items.id;


--
-- Name: purchase_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_requests (
    id bigint NOT NULL,
    pr_number character varying(30) NOT NULL,
    requested_by bigint NOT NULL,
    department character varying(60),
    reason text,
    priority character varying(20) DEFAULT 'NORMAL'::character varying NOT NULL,
    needed_by_date date,
    status character varying(30) DEFAULT 'DRAFT'::character varying NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejected_reason text,
    estimated_total numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_requests_id_seq OWNED BY public.purchase_requests.id;


--
-- Name: qa_decision_reasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qa_decision_reasons (
    id bigint NOT NULL,
    code character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: qa_decision_reasons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qa_decision_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qa_decision_reasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qa_decision_reasons_id_seq OWNED BY public.qa_decision_reasons.id;


--
-- Name: qa_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qa_reviews (
    id bigint NOT NULL,
    lead_id bigint NOT NULL,
    reviewer_id bigint NOT NULL,
    qa_level integer DEFAULT 1 NOT NULL,
    qa_status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    decision character varying(255),
    notes text,
    checklist json,
    reviewed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: qa_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qa_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qa_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qa_reviews_id_seq OWNED BY public.qa_reviews.id;


--
-- Name: qbo_account_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qbo_account_mappings (
    id bigint NOT NULL,
    mapping_key character varying(60) NOT NULL,
    qbo_account_id character varying(60) NOT NULL,
    qbo_account_name character varying(255),
    mapped_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: qbo_account_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qbo_account_mappings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qbo_account_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qbo_account_mappings_id_seq OWNED BY public.qbo_account_mappings.id;


--
-- Name: qbo_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qbo_connections (
    id bigint NOT NULL,
    realm_id character varying(60) NOT NULL,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    expires_at timestamp(0) without time zone NOT NULL,
    environment character varying(20) DEFAULT 'SANDBOX'::character varying NOT NULL,
    connected_by bigint NOT NULL,
    connected_at timestamp(0) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: qbo_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qbo_connections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qbo_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qbo_connections_id_seq OWNED BY public.qbo_connections.id;


--
-- Name: qbo_sync_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qbo_sync_queue (
    id bigint NOT NULL,
    entity_type character varying(60) NOT NULL,
    entity_id bigint NOT NULL,
    operation character varying(20) NOT NULL,
    idempotency_key uuid NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    qbo_id character varying(60),
    payload json,
    error_message text,
    attempts smallint DEFAULT '0'::smallint NOT NULL,
    synced_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: qbo_sync_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.qbo_sync_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: qbo_sync_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.qbo_sync_queue_id_seq OWNED BY public.qbo_sync_queue.id;


--
-- Name: receiving_report_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receiving_report_items (
    id bigint NOT NULL,
    grn_id bigint NOT NULL,
    po_item_id bigint NOT NULL,
    quantity_received integer NOT NULL,
    quantity_rejected integer DEFAULT 0 NOT NULL,
    rejection_reason character varying(120),
    condition character varying(20) DEFAULT 'GOOD'::character varying NOT NULL,
    batch_number character varying(60),
    expiry_date date,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: receiving_report_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receiving_report_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receiving_report_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receiving_report_items_id_seq OWNED BY public.receiving_report_items.id;


--
-- Name: receiving_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receiving_reports (
    id bigint NOT NULL,
    grn_number character varying(30) NOT NULL,
    po_id bigint NOT NULL,
    warehouse_id bigint NOT NULL,
    location_id bigint,
    received_by bigint NOT NULL,
    received_at timestamp(0) without time zone NOT NULL,
    exchange_rate numeric(14,6) DEFAULT '1'::numeric NOT NULL,
    exchange_rate_date date,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    notes text,
    discrepancy_notes text,
    confirmed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: receiving_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receiving_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receiving_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receiving_reports_id_seq OWNED BY public.receiving_reports.id;


--
-- Name: recycling_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recycling_rules (
    id bigint NOT NULL,
    outcome character varying(255) NOT NULL,
    cooldown_hours integer DEFAULT 24 NOT NULL,
    max_cycles integer DEFAULT 3 NOT NULL,
    next_action character varying(255) DEFAULT 'RECYCLE'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: recycling_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recycling_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recycling_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recycling_rules_id_seq OWNED BY public.recycling_rules.id;


--
-- Name: remark_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remark_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    body text NOT NULL,
    type character varying(255) DEFAULT 'agent_note'::character varying NOT NULL,
    visibility character varying(255) DEFAULT 'internal'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: remark_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.remark_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: remark_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.remark_templates_id_seq OWNED BY public.remark_templates.id;


--
-- Name: reply_template_ab_tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_template_ab_tests (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    created_by bigint,
    start_at timestamp(0) without time zone,
    end_at timestamp(0) without time zone,
    winning_variant_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: reply_template_ab_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_template_ab_tests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_template_ab_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_template_ab_tests_id_seq OWNED BY public.reply_template_ab_tests.id;


--
-- Name: reply_template_ab_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_template_ab_variants (
    id bigint NOT NULL,
    ab_test_id bigint NOT NULL,
    reply_template_id bigint NOT NULL,
    variant_label character varying(255) DEFAULT 'A'::character varying NOT NULL,
    weight integer DEFAULT 50 NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    uses integer DEFAULT 0 NOT NULL,
    conversations_resolved integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: reply_template_ab_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_template_ab_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_template_ab_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_template_ab_variants_id_seq OWNED BY public.reply_template_ab_variants.id;


--
-- Name: reply_template_favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_template_favorites (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    reply_template_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: reply_template_favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_template_favorites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_template_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_template_favorites_id_seq OWNED BY public.reply_template_favorites.id;


--
-- Name: reply_template_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_template_shares (
    id bigint NOT NULL,
    reply_template_id bigint NOT NULL,
    facebook_page_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: reply_template_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_template_shares_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_template_shares_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_template_shares_id_seq OWNED BY public.reply_template_shares.id;


--
-- Name: reply_template_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_template_usage (
    id bigint NOT NULL,
    reply_template_id bigint NOT NULL,
    user_id bigint,
    conversation_id bigint,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: reply_template_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_template_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_template_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_template_usage_id_seq OWNED BY public.reply_template_usage.id;


--
-- Name: reply_template_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_template_versions (
    id bigint NOT NULL,
    reply_template_id bigint NOT NULL,
    edited_by bigint,
    version_number integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    variables json,
    category character varying(255),
    intent character varying(255),
    allowed_roles json,
    shortcut character varying(255),
    facebook_page_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    shared_page_ids json,
    change_summary text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: reply_template_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_template_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_template_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_template_versions_id_seq OWNED BY public.reply_template_versions.id;


--
-- Name: reply_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_templates (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    shortcut character varying(255),
    facebook_page_id bigint,
    created_by bigint,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    variables json,
    category character varying(255),
    intent character varying(255),
    allowed_roles json,
    approval_status character varying(255),
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejection_reason text,
    language character varying(8) DEFAULT 'en'::character varying NOT NULL,
    media_type character varying(20) DEFAULT 'text'::character varying NOT NULL,
    media_config json
);


--
-- Name: reply_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_templates_id_seq OWNED BY public.reply_templates.id;


--
-- Name: return_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_receipts (
    id bigint NOT NULL,
    waybill_id bigint NOT NULL,
    scanned_by bigint NOT NULL,
    scanned_at timestamp(0) without time zone NOT NULL,
    condition character varying(255) NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    inventory_updated boolean DEFAULT false NOT NULL,
    inventory_movement_id bigint,
    finance_notified boolean DEFAULT false NOT NULL,
    processed_at timestamp(0) without time zone
);


--
-- Name: return_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.return_receipts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: return_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.return_receipts_id_seq OWNED BY public.return_receipts.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id bigint NOT NULL,
    role character varying(255) NOT NULL,
    permission_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: scheduled_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    facebook_page_id bigint NOT NULL,
    customer_identity_id bigint,
    body text NOT NULL,
    quick_replies json,
    scheduled_at timestamp(0) without time zone NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    sent_message_id bigint,
    created_by bigint NOT NULL,
    error_message text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scheduled_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scheduled_messages_id_seq OWNED BY public.scheduled_messages.id;


--
-- Name: scheduled_sales_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_sales_reports (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    frequency character varying(20) DEFAULT 'weekly'::character varying NOT NULL,
    send_at time(0) without time zone DEFAULT '08:00:00'::time without time zone NOT NULL,
    day_of_week character varying(10),
    day_of_month integer,
    format character varying(10) DEFAULT 'csv'::character varying NOT NULL,
    lookback_days integer DEFAULT 7 NOT NULL,
    recipients json,
    is_active boolean DEFAULT true NOT NULL,
    last_run_at timestamp(0) without time zone,
    next_run_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: scheduled_sales_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scheduled_sales_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scheduled_sales_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scheduled_sales_reports_id_seq OWNED BY public.scheduled_sales_reports.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    type character varying(255) DEFAULT 'string'::character varying NOT NULL,
    "group" character varying(255) DEFAULT 'general'::character varying NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: shipping_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_rates (
    id bigint NOT NULL,
    courier_code character varying(30) DEFAULT 'MANUAL'::character varying NOT NULL,
    courier_zone character varying(50) NOT NULL,
    base_fee numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    per_kg_fee numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    weight_threshold_kg numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    cod_fee numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: shipping_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shipping_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shipping_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shipping_rates_id_seq OWNED BY public.shipping_rates.id;


--
-- Name: shop_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_order_items (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_id bigint,
    variant_id bigint,
    sku character varying(255),
    product_name character varying(255) NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    discount_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    line_total numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    metadata json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: shop_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shop_order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shop_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shop_order_items_id_seq OWNED BY public.shop_order_items.id;


--
-- Name: shop_reply_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_reply_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    category character varying(255),
    variables json,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    facebook_page_id bigint
);


--
-- Name: shop_reply_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shop_reply_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shop_reply_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shop_reply_templates_id_seq OWNED BY public.shop_reply_templates.id;


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    value text
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: sms_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_campaigns (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    target_audience character varying(255) DEFAULT 'custom'::character varying NOT NULL,
    filters json,
    total_recipients integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    delivered_count integer DEFAULT 0 NOT NULL,
    scheduled_at timestamp(0) without time zone,
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT sms_campaigns_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'sending'::character varying, 'completed'::character varying, 'failed'::character varying, 'paused'::character varying])::text[]))),
    CONSTRAINT sms_campaigns_target_audience_check CHECK (((target_audience)::text = ANY ((ARRAY['all_customers'::character varying, 'delivered'::character varying, 'pending'::character varying, 'returned'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT sms_campaigns_type_check CHECK (((type)::text = ANY ((ARRAY['broadcast'::character varying, 'sequence'::character varying, 'reminder'::character varying])::text[])))
);


--
-- Name: sms_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_campaigns_id_seq OWNED BY public.sms_campaigns.id;


--
-- Name: sms_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_logs (
    id bigint NOT NULL,
    campaign_id bigint,
    sequence_id bigint,
    waybill_id bigint,
    lead_id bigint,
    phone character varying(20) NOT NULL,
    message text NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    external_id character varying(255),
    error_message text,
    cost numeric(8,4),
    sent_at timestamp(0) without time zone,
    delivered_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT sms_logs_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'sent'::character varying, 'delivered'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: sms_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_logs_id_seq OWNED BY public.sms_logs.id;


--
-- Name: sms_sequence_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_sequence_enrollments (
    id bigint NOT NULL,
    sequence_id bigint NOT NULL,
    waybill_id bigint,
    lead_id bigint,
    phone character varying(20) NOT NULL,
    current_step integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    next_step_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT sms_sequence_enrollments_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'paused'::character varying])::text[])))
);


--
-- Name: sms_sequence_enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_sequence_enrollments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_sequence_enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_sequence_enrollments_id_seq OWNED BY public.sms_sequence_enrollments.id;


--
-- Name: sms_sequence_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_sequence_steps (
    id bigint NOT NULL,
    sequence_id bigint NOT NULL,
    step_order integer NOT NULL,
    message text NOT NULL,
    delay_minutes integer DEFAULT 0 NOT NULL,
    delay_type character varying(255) DEFAULT 'minutes'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT sms_sequence_steps_delay_type_check CHECK (((delay_type)::text = ANY ((ARRAY['minutes'::character varying, 'hours'::character varying, 'days'::character varying])::text[])))
);


--
-- Name: sms_sequence_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_sequence_steps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_sequence_steps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_sequence_steps_id_seq OWNED BY public.sms_sequence_steps.id;


--
-- Name: sms_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_sequences (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    trigger_event character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT sms_sequences_trigger_event_check CHECK (((trigger_event)::text = ANY ((ARRAY['waybill_created'::character varying, 'waybill_dispatched'::character varying, 'waybill_out_for_delivery'::character varying, 'waybill_delivered'::character varying, 'waybill_returned'::character varying, 'lead_created'::character varying, 'lead_sale'::character varying])::text[])))
);


--
-- Name: sms_sequences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_sequences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_sequences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_sequences_id_seq OWNED BY public.sms_sequences.id;


--
-- Name: sms_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_templates (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    category character varying(255),
    variables json,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: sms_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sms_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_templates_id_seq OWNED BY public.sms_templates.id;


--
-- Name: stock_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustments (
    id bigint NOT NULL,
    product_id bigint,
    supply_id bigint,
    variant_id bigint,
    warehouse_id bigint,
    location_id bigint,
    reason_code character varying(50) NOT NULL,
    reason_notes text,
    quantity_before integer NOT NULL,
    quantity_after integer NOT NULL,
    variance integer NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    submitted_by bigint NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_adjustments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_adjustments_id_seq OWNED BY public.stock_adjustments.id;


--
-- Name: stock_audit_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_audit_items (
    id bigint NOT NULL,
    session_id bigint NOT NULL,
    product_id bigint,
    supply_id bigint,
    variant_id bigint,
    location_id bigint,
    system_qty integer NOT NULL,
    counted_qty integer,
    variance integer,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: stock_audit_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_audit_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_audit_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_audit_items_id_seq OWNED BY public.stock_audit_items.id;


--
-- Name: stock_audit_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_audit_sessions (
    id bigint NOT NULL,
    warehouse_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'OPEN'::character varying NOT NULL,
    started_by bigint NOT NULL,
    finalized_by bigint,
    started_at timestamp(0) without time zone NOT NULL,
    finalized_at timestamp(0) without time zone,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: stock_audit_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_audit_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_audit_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_audit_sessions_id_seq OWNED BY public.stock_audit_sessions.id;


--
-- Name: stock_cost_lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_cost_lots (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    warehouse_id bigint NOT NULL,
    grn_item_id bigint,
    quantity_received numeric(12,4) NOT NULL,
    quantity_remaining numeric(12,4) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    currency_code character(3) DEFAULT 'PHP'::bpchar NOT NULL,
    exchange_rate numeric(14,6) DEFAULT '1'::numeric NOT NULL,
    received_at timestamp(0) without time zone NOT NULL,
    expiry_date date,
    batch_number character varying(60),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: stock_cost_lots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_cost_lots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_cost_lots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_cost_lots_id_seq OWNED BY public.stock_cost_lots.id;


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    variant_id bigint,
    warehouse_id bigint,
    quantity integer NOT NULL,
    reference_type character varying(60) NOT NULL,
    reference_id bigint NOT NULL,
    reserved_by bigint,
    reserved_at timestamp(0) without time zone NOT NULL,
    expires_at timestamp(0) without time zone NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    released_at timestamp(0) without time zone,
    released_reason character varying(60),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: stock_reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_reservations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_reservations_id_seq OWNED BY public.stock_reservations.id;


--
-- Name: supplier_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_invoices (
    id bigint NOT NULL,
    ref character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'DRAFT'::character varying NOT NULL,
    third_party_id bigint,
    supplier_name character varying(255) NOT NULL,
    supplier_email character varying(255),
    supplier_phone character varying(255),
    supplier_address text,
    order_id bigint,
    invoice_id bigint,
    date_invoice date NOT NULL,
    date_due date,
    date_receipt date,
    payment_terms character varying(255),
    currency character varying(255) DEFAULT 'PHP'::character varying NOT NULL,
    subtotal numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    discount_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    shipping_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_paid numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_due numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    notes text,
    terms text,
    cancel_reason text,
    cancelled_at timestamp(0) without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: supplier_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplier_invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplier_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplier_invoices_id_seq OWNED BY public.supplier_invoices.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(20) NOT NULL,
    contact_person character varying(255),
    email character varying(255),
    phone character varying(255),
    address text,
    payment_terms character varying(60),
    lead_time_days integer DEFAULT 7 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    qbo_vendor_id character varying(60),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: supplies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplies (
    id bigint NOT NULL,
    sku character varying(60) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(60),
    uom_id bigint,
    cost_price numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    min_stock_level integer DEFAULT 0 NOT NULL,
    reorder_point integer DEFAULT 10 NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    section character varying(20) DEFAULT 'STOCK'::character varying NOT NULL,
    stock_category character varying(30),
    opex_category character varying(30),
    stock_status character varying(20) DEFAULT 'MOVING'::character varying NOT NULL,
    stock_status_override boolean DEFAULT false NOT NULL,
    delete_reason character varying(500)
);


--
-- Name: supplies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplies_id_seq OWNED BY public.supplies.id;


--
-- Name: supply_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_movements (
    id bigint NOT NULL,
    supply_id bigint NOT NULL,
    type character varying(30) NOT NULL,
    quantity integer NOT NULL,
    warehouse_id bigint,
    location_id bigint,
    to_location_id bigint,
    reference_type character varying(255),
    reference_id bigint,
    batch_number character varying(60),
    notes text,
    performed_by bigint,
    approved_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: supply_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supply_movements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supply_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supply_movements_id_seq OWNED BY public.supply_movements.id;


--
-- Name: supply_stocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_stocks (
    id bigint NOT NULL,
    supply_id bigint NOT NULL,
    warehouse_id bigint,
    location_id bigint,
    current_stock integer DEFAULT 0 NOT NULL,
    reserved_stock integer DEFAULT 0 NOT NULL,
    reorder_point integer DEFAULT 10 NOT NULL,
    last_restock_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    last_movement_at timestamp(0) without time zone
);


--
-- Name: supply_stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supply_stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supply_stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supply_stocks_id_seq OWNED BY public.supply_stocks.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    "group" character varying(255) DEFAULT 'general'::character varying NOT NULL,
    type character varying(255) DEFAULT 'string'::character varying NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    color character varying(255) DEFAULT '#64748b'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: third_parties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.third_parties (
    id bigint NOT NULL,
    ref character varying(255),
    name character varying(255) NOT NULL,
    alias character varying(255),
    type character varying(255) DEFAULT 'customer'::character varying NOT NULL,
    email character varying(255),
    phone character varying(255),
    phone_alt character varying(255),
    website character varying(255),
    tax_id character varying(255),
    industry character varying(255),
    currency character varying(255) DEFAULT 'PHP'::character varying NOT NULL,
    payment_terms character varying(255),
    credit_limit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    address_line1 character varying(255),
    city character varying(255),
    state_province character varying(255),
    postal_code character varying(255),
    country character varying(255) DEFAULT 'Philippines'::character varying NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    source character varying(255),
    assigned_to character varying(255),
    notes text,
    tags json,
    risk_level character varying(255) DEFAULT 'LOW'::character varying NOT NULL,
    is_blacklisted boolean DEFAULT false NOT NULL,
    blacklist_reason text,
    blacklisted_at timestamp(0) without time zone,
    total_orders integer DEFAULT 0 NOT NULL,
    successful_orders integer DEFAULT 0 NOT NULL,
    returned_orders integer DEFAULT 0 NOT NULL,
    total_revenue numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    success_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    last_order_date timestamp(0) without time zone,
    customer_id bigint,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: third_parties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.third_parties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: third_parties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.third_parties_id_seq OWNED BY public.third_parties.id;


--
-- Name: ticket_canned_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_canned_responses (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    body text NOT NULL,
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: ticket_canned_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ticket_canned_responses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ticket_canned_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ticket_canned_responses_id_seq OWNED BY public.ticket_canned_responses.id;


--
-- Name: ticket_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    color character varying(20) DEFAULT 'gray'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ticket_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ticket_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ticket_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ticket_categories_id_seq OWNED BY public.ticket_categories.id;


--
-- Name: ticket_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_comments (
    id bigint NOT NULL,
    ticket_id bigint NOT NULL,
    user_id bigint NOT NULL,
    body text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ticket_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ticket_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ticket_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ticket_comments_id_seq OWNED BY public.ticket_comments.id;


--
-- Name: ticket_priorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_priorities (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    color character varying(20) DEFAULT 'gray'::character varying NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: ticket_priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ticket_priorities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ticket_priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ticket_priorities_id_seq OWNED BY public.ticket_priorities.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tickets (
    id bigint NOT NULL,
    ticket_number character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    description text,
    status character varying(255) DEFAULT 'open'::character varying NOT NULL,
    priority character varying(255) DEFAULT 'medium'::character varying NOT NULL,
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    created_by bigint NOT NULL,
    assigned_to bigint,
    related_waybill character varying(255),
    related_lead bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    due_at timestamp(0) without time zone,
    resolved_at timestamp(0) without time zone,
    satisfaction_rating smallint,
    satisfaction_comment text,
    satisfaction_submitted_at timestamp(0) without time zone,
    CONSTRAINT tickets_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT tickets_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'waiting'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: units_of_measure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units_of_measure (
    id bigint NOT NULL,
    name character varying(60) NOT NULL,
    abbreviation character varying(10) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.units_of_measure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.units_of_measure_id_seq OWNED BY public.units_of_measure.id;


--
-- Name: unknown_waybill_scans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unknown_waybill_scans (
    id bigint NOT NULL,
    waybill_no character varying(60) NOT NULL,
    scanned_by bigint NOT NULL,
    scanned_at timestamp(0) without time zone NOT NULL,
    scan_session_id uuid NOT NULL,
    resolution_status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    resolved_to_waybill_id bigint,
    notes text,
    resolved_by bigint,
    resolved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: unknown_waybill_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.unknown_waybill_scans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: unknown_waybill_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.unknown_waybill_scans_id_seq OWNED BY public.unknown_waybill_scans.id;


--
-- Name: uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.uploads (
    id bigint NOT NULL,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'waybill'::character varying NOT NULL,
    total_rows integer DEFAULT 0 NOT NULL,
    processed_rows integer DEFAULT 0 NOT NULL,
    success_rows integer DEFAULT 0 NOT NULL,
    error_rows integer DEFAULT 0 NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    errors json,
    uploaded_by bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    courier character varying(255),
    import_type character varying(255),
    inserted_rows integer DEFAULT 0 NOT NULL,
    updated_rows integer DEFAULT 0 NOT NULL,
    skipped_rows integer DEFAULT 0 NOT NULL,
    file_hash character varying(255),
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    uuid uuid,
    file_path character varying(255),
    total_chunks integer DEFAULT 0 NOT NULL,
    processed_chunks integer DEFAULT 0 NOT NULL,
    metadata json,
    auto_import boolean DEFAULT false NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    retry_of bigint,
    retry_status character varying(255)
);


--
-- Name: uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.uploads_id_seq OWNED BY public.uploads.id;


--
-- Name: user_module_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_module_access (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    module_key character varying(255) NOT NULL,
    granted boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: user_module_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_module_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_module_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_module_access_id_seq OWNED BY public.user_module_access.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    role character varying(255) DEFAULT 'agent'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    phone character varying(255),
    last_login_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    theme character varying(255) DEFAULT 'light'::character varying NOT NULL,
    language character varying(255) DEFAULT 'en'::character varying NOT NULL,
    timezone character varying(255) DEFAULT 'Asia/Manila'::character varying NOT NULL,
    birthday date,
    hire_date date
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouse_locations (
    id bigint NOT NULL,
    warehouse_id bigint NOT NULL,
    code character varying(30) NOT NULL,
    name character varying(255),
    type character varying(20) DEFAULT 'SHELF'::character varying NOT NULL,
    capacity integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: warehouse_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouse_locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouse_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouse_locations_id_seq OWNED BY public.warehouse_locations.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(20) NOT NULL,
    address character varying(255),
    contact_person character varying(255),
    contact_phone character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: waybill_tracking_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waybill_tracking_history (
    id bigint NOT NULL,
    waybill_id bigint NOT NULL,
    status character varying(255) NOT NULL,
    previous_status character varying(255),
    reason text,
    location character varying(255),
    raw_data json,
    tracked_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    latitude numeric(10,7),
    longitude numeric(10,7)
);


--
-- Name: waybill_tracking_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.waybill_tracking_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: waybill_tracking_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.waybill_tracking_history_id_seq OWNED BY public.waybill_tracking_history.id;


--
-- Name: waybills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waybills (
    id bigint NOT NULL,
    waybill_number character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    receiver_name character varying(255) NOT NULL,
    receiver_phone character varying(255) NOT NULL,
    receiver_address text NOT NULL,
    city character varying(255),
    state character varying(255),
    barangay character varying(255),
    street character varying(255),
    postal_code character varying(255),
    item_name character varying(255),
    item_qty integer DEFAULT 1 NOT NULL,
    amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    courier_provider character varying(255) DEFAULT 'MANUAL'::character varying NOT NULL,
    lead_id bigint,
    uploaded_by bigint,
    dispatched_at timestamp(0) without time zone,
    delivered_at timestamp(0) without time zone,
    returned_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    creator_code character varying(255),
    sign_for_pictures boolean DEFAULT false NOT NULL,
    payment_method character varying(255),
    shipping_cost numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    cod_amount numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    settlement_weight numeric(8,2),
    item_value numeric(10,2),
    valuation_fee numeric(10,2),
    express_type character varying(255),
    rts_reason text,
    remarks text,
    sender_name character varying(255),
    sender_phone character varying(255),
    sender_province character varying(255),
    sender_city character varying(255),
    submitted_at timestamp(0) without time zone,
    signed_at timestamp(0) without time zone,
    upload_id bigint,
    latitude numeric(10,7),
    longitude numeric(10,7),
    last_location_at timestamp(0) without time zone,
    last_location_description character varying(255)
);


--
-- Name: waybills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.waybills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: waybills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.waybills_id_seq OWNED BY public.waybills.id;


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_logs (
    id bigint NOT NULL,
    provider character varying(255) NOT NULL,
    event_type character varying(255),
    payload json NOT NULL,
    signature character varying(255),
    signature_valid boolean DEFAULT false NOT NULL,
    processing_status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    processing_error text,
    processed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhook_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhook_logs_id_seq OWNED BY public.webhook_logs.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: address_correction_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_correction_history ALTER COLUMN id SET DEFAULT nextval('public.address_correction_history_id_seq'::regclass);


--
-- Name: address_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_mappings ALTER COLUMN id SET DEFAULT nextval('public.address_mappings_id_seq'::regclass);


--
-- Name: addresses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses ALTER COLUMN id SET DEFAULT nextval('public.addresses_id_seq'::regclass);


--
-- Name: agent_badges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_badges ALTER COLUMN id SET DEFAULT nextval('public.agent_badges_id_seq'::regclass);


--
-- Name: agent_commissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions ALTER COLUMN id SET DEFAULT nextval('public.agent_commissions_id_seq'::regclass);


--
-- Name: agent_flags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flags ALTER COLUMN id SET DEFAULT nextval('public.agent_flags_id_seq'::regclass);


--
-- Name: agent_milestones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_milestones ALTER COLUMN id SET DEFAULT nextval('public.agent_milestones_id_seq'::regclass);


--
-- Name: agent_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles ALTER COLUMN id SET DEFAULT nextval('public.agent_profiles_id_seq'::regclass);


--
-- Name: agent_streaks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_streaks ALTER COLUMN id SET DEFAULT nextval('public.agent_streaks_id_seq'::regclass);


--
-- Name: approval_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_rules ALTER COLUMN id SET DEFAULT nextval('public.approval_rules_id_seq'::regclass);


--
-- Name: approval_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_settings ALTER COLUMN id SET DEFAULT nextval('public.approval_settings_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: auto_merge_suggestions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_merge_suggestions ALTER COLUMN id SET DEFAULT nextval('public.auto_merge_suggestions_id_seq'::regclass);


--
-- Name: badges id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges ALTER COLUMN id SET DEFAULT nextval('public.badges_id_seq'::regclass);


--
-- Name: batch_item_error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_item_error_logs ALTER COLUMN id SET DEFAULT nextval('public.batch_item_error_logs_id_seq'::regclass);


--
-- Name: batch_scan_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_scan_items ALTER COLUMN id SET DEFAULT nextval('public.batch_scan_items_id_seq'::regclass);


--
-- Name: batch_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_sessions ALTER COLUMN id SET DEFAULT nextval('public.batch_sessions_id_seq'::regclass);


--
-- Name: batch_status_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_status_history ALTER COLUMN id SET DEFAULT nextval('public.batch_status_history_id_seq'::regclass);


--
-- Name: broadcast_campaigns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_campaigns ALTER COLUMN id SET DEFAULT nextval('public.broadcast_campaigns_id_seq'::regclass);


--
-- Name: broadcast_recipients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients ALTER COLUMN id SET DEFAULT nextval('public.broadcast_recipients_id_seq'::regclass);


--
-- Name: broadcast_variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_variants ALTER COLUMN id SET DEFAULT nextval('public.broadcast_variants_id_seq'::regclass);


--
-- Name: capex_asset_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_asset_assignments ALTER COLUMN id SET DEFAULT nextval('public.capex_asset_assignments_id_seq'::regclass);


--
-- Name: capex_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets ALTER COLUMN id SET DEFAULT nextval('public.capex_assets_id_seq'::regclass);


--
-- Name: capex_depreciation_schedule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_depreciation_schedule ALTER COLUMN id SET DEFAULT nextval('public.capex_depreciation_schedule_id_seq'::regclass);


--
-- Name: cart_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_templates ALTER COLUMN id SET DEFAULT nextval('public.cart_templates_id_seq'::regclass);


--
-- Name: claims id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims ALTER COLUMN id SET DEFAULT nextval('public.claims_id_seq'::regclass);


--
-- Name: cod_settlements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cod_settlements ALTER COLUMN id SET DEFAULT nextval('public.cod_settlements_id_seq'::regclass);


--
-- Name: cogs_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cogs_entries ALTER COLUMN id SET DEFAULT nextval('public.cogs_entries_id_seq'::regclass);


--
-- Name: commission_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rules ALTER COLUMN id SET DEFAULT nextval('public.commission_rules_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: conversation_assignment_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_assignment_histories ALTER COLUMN id SET DEFAULT nextval('public.conversation_assignment_histories_id_seq'::regclass);


--
-- Name: conversation_exports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_exports ALTER COLUMN id SET DEFAULT nextval('public.conversation_exports_id_seq'::regclass);


--
-- Name: conversation_status_histories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_status_histories ALTER COLUMN id SET DEFAULT nextval('public.conversation_status_histories_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: courier_api_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_api_logs ALTER COLUMN id SET DEFAULT nextval('public.courier_api_logs_id_seq'::regclass);


--
-- Name: courier_csv_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_templates ALTER COLUMN id SET DEFAULT nextval('public.courier_csv_templates_id_seq'::regclass);


--
-- Name: courier_csv_validation_error_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_validation_error_logs ALTER COLUMN id SET DEFAULT nextval('public.courier_csv_validation_error_logs_id_seq'::regclass);


--
-- Name: courier_export_batch_shares id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batch_shares ALTER COLUMN id SET DEFAULT nextval('public.courier_export_batch_shares_id_seq'::regclass);


--
-- Name: courier_export_batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batches ALTER COLUMN id SET DEFAULT nextval('public.courier_export_batches_id_seq'::regclass);


--
-- Name: courier_export_rows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_rows ALTER COLUMN id SET DEFAULT nextval('public.courier_export_rows_id_seq'::regclass);


--
-- Name: courier_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_providers ALTER COLUMN id SET DEFAULT nextval('public.courier_providers_id_seq'::regclass);


--
-- Name: courier_sync_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_sync_logs ALTER COLUMN id SET DEFAULT nextval('public.courier_sync_logs_id_seq'::regclass);


--
-- Name: customer_addresses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses ALTER COLUMN id SET DEFAULT nextval('public.customer_addresses_id_seq'::regclass);


--
-- Name: customer_audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.customer_audit_logs_id_seq'::regclass);


--
-- Name: customer_identities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_identities ALTER COLUMN id SET DEFAULT nextval('public.customer_identities_id_seq'::regclass);


--
-- Name: customer_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes ALTER COLUMN id SET DEFAULT nextval('public.customer_notes_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: dashboard_widget_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widget_configs ALTER COLUMN id SET DEFAULT nextval('public.dashboard_widget_configs_id_seq'::regclass);


--
-- Name: dead_stocks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_stocks ALTER COLUMN id SET DEFAULT nextval('public.dead_stocks_id_seq'::regclass);


--
-- Name: delivery_proofs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_proofs ALTER COLUMN id SET DEFAULT nextval('public.delivery_proofs_id_seq'::regclass);


--
-- Name: distribution_queues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_queues ALTER COLUMN id SET DEFAULT nextval('public.distribution_queues_id_seq'::regclass);


--
-- Name: distribution_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_rules ALTER COLUMN id SET DEFAULT nextval('public.distribution_rules_id_seq'::regclass);


--
-- Name: duplicate_audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.duplicate_audit_logs_id_seq'::regclass);


--
-- Name: duplicate_detection_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_detection_rules ALTER COLUMN id SET DEFAULT nextval('public.duplicate_detection_rules_id_seq'::regclass);


--
-- Name: duplicate_families id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_families ALTER COLUMN id SET DEFAULT nextval('public.duplicate_families_id_seq'::regclass);


--
-- Name: duplicate_family_members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_family_members ALTER COLUMN id SET DEFAULT nextval('public.duplicate_family_members_id_seq'::regclass);


--
-- Name: duplicate_ml_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_ml_models ALTER COLUMN id SET DEFAULT nextval('public.duplicate_ml_models_id_seq'::regclass);


--
-- Name: duplicate_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_notifications ALTER COLUMN id SET DEFAULT nextval('public.duplicate_notifications_id_seq'::regclass);


--
-- Name: duplicate_review_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_review_items ALTER COLUMN id SET DEFAULT nextval('public.duplicate_review_items_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: facebook_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_accounts ALTER COLUMN id SET DEFAULT nextval('public.facebook_accounts_id_seq'::regclass);


--
-- Name: facebook_pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_pages ALTER COLUMN id SET DEFAULT nextval('public.facebook_pages_id_seq'::regclass);


--
-- Name: facebook_webhook_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_webhook_events ALTER COLUMN id SET DEFAULT nextval('public.facebook_webhook_events_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: finance_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_settings ALTER COLUMN id SET DEFAULT nextval('public.finance_settings_id_seq'::regclass);


--
-- Name: financial_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions ALTER COLUMN id SET DEFAULT nextval('public.financial_transactions_id_seq'::regclass);


--
-- Name: fraud_flags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fraud_flags ALTER COLUMN id SET DEFAULT nextval('public.fraud_flags_id_seq'::regclass);


--
-- Name: import_chunks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_chunks ALTER COLUMN id SET DEFAULT nextval('public.import_chunks_id_seq'::regclass);


--
-- Name: inventory_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_id_seq'::regclass);


--
-- Name: invoice_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines ALTER COLUMN id SET DEFAULT nextval('public.invoice_lines_id_seq'::regclass);


--
-- Name: invoice_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments ALTER COLUMN id SET DEFAULT nextval('public.invoice_payments_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: lead_cycles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_cycles ALTER COLUMN id SET DEFAULT nextval('public.lead_cycles_id_seq'::regclass);


--
-- Name: lead_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_logs ALTER COLUMN id SET DEFAULT nextval('public.lead_logs_id_seq'::regclass);


--
-- Name: lead_pool_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_pool_audit ALTER COLUMN id SET DEFAULT nextval('public.lead_pool_audit_id_seq'::regclass);


--
-- Name: lead_recycling_pool id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_recycling_pool ALTER COLUMN id SET DEFAULT nextval('public.lead_recycling_pool_id_seq'::regclass);


--
-- Name: lead_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_snapshots ALTER COLUMN id SET DEFAULT nextval('public.lead_snapshots_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: meta_data_deletion_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_data_deletion_requests ALTER COLUMN id SET DEFAULT nextval('public.meta_data_deletion_requests_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: milestones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones ALTER COLUMN id SET DEFAULT nextval('public.milestones_id_seq'::regclass);


--
-- Name: order_remarks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks ALTER COLUMN id SET DEFAULT nextval('public.order_remarks_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: page_assignment_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_assignment_rules ALTER COLUMN id SET DEFAULT nextval('public.page_assignment_rules_id_seq'::regclass);


--
-- Name: page_favorites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_favorites ALTER COLUMN id SET DEFAULT nextval('public.page_favorites_id_seq'::regclass);


--
-- Name: page_status_labels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_labels ALTER COLUMN id SET DEFAULT nextval('public.page_status_labels_id_seq'::regclass);


--
-- Name: page_status_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_rules ALTER COLUMN id SET DEFAULT nextval('public.page_status_rules_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: product_stocks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks ALTER COLUMN id SET DEFAULT nextval('public.product_stocks_id_seq'::regclass);


--
-- Name: product_variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants ALTER COLUMN id SET DEFAULT nextval('public.product_variants_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_items_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: purchase_request_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_request_items_id_seq'::regclass);


--
-- Name: purchase_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests ALTER COLUMN id SET DEFAULT nextval('public.purchase_requests_id_seq'::regclass);


--
-- Name: qa_decision_reasons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_decision_reasons ALTER COLUMN id SET DEFAULT nextval('public.qa_decision_reasons_id_seq'::regclass);


--
-- Name: qa_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_reviews ALTER COLUMN id SET DEFAULT nextval('public.qa_reviews_id_seq'::regclass);


--
-- Name: qbo_account_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_account_mappings ALTER COLUMN id SET DEFAULT nextval('public.qbo_account_mappings_id_seq'::regclass);


--
-- Name: qbo_connections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_connections ALTER COLUMN id SET DEFAULT nextval('public.qbo_connections_id_seq'::regclass);


--
-- Name: qbo_sync_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_sync_queue ALTER COLUMN id SET DEFAULT nextval('public.qbo_sync_queue_id_seq'::regclass);


--
-- Name: receiving_report_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_report_items ALTER COLUMN id SET DEFAULT nextval('public.receiving_report_items_id_seq'::regclass);


--
-- Name: receiving_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports ALTER COLUMN id SET DEFAULT nextval('public.receiving_reports_id_seq'::regclass);


--
-- Name: recycling_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recycling_rules ALTER COLUMN id SET DEFAULT nextval('public.recycling_rules_id_seq'::regclass);


--
-- Name: remark_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remark_templates ALTER COLUMN id SET DEFAULT nextval('public.remark_templates_id_seq'::regclass);


--
-- Name: reply_template_ab_tests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_tests ALTER COLUMN id SET DEFAULT nextval('public.reply_template_ab_tests_id_seq'::regclass);


--
-- Name: reply_template_ab_variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_variants ALTER COLUMN id SET DEFAULT nextval('public.reply_template_ab_variants_id_seq'::regclass);


--
-- Name: reply_template_favorites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_favorites ALTER COLUMN id SET DEFAULT nextval('public.reply_template_favorites_id_seq'::regclass);


--
-- Name: reply_template_shares id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_shares ALTER COLUMN id SET DEFAULT nextval('public.reply_template_shares_id_seq'::regclass);


--
-- Name: reply_template_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_usage ALTER COLUMN id SET DEFAULT nextval('public.reply_template_usage_id_seq'::regclass);


--
-- Name: reply_template_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_versions ALTER COLUMN id SET DEFAULT nextval('public.reply_template_versions_id_seq'::regclass);


--
-- Name: reply_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_templates ALTER COLUMN id SET DEFAULT nextval('public.reply_templates_id_seq'::regclass);


--
-- Name: return_receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_receipts ALTER COLUMN id SET DEFAULT nextval('public.return_receipts_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: scheduled_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages ALTER COLUMN id SET DEFAULT nextval('public.scheduled_messages_id_seq'::regclass);


--
-- Name: scheduled_sales_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_sales_reports ALTER COLUMN id SET DEFAULT nextval('public.scheduled_sales_reports_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: shipping_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_rates ALTER COLUMN id SET DEFAULT nextval('public.shipping_rates_id_seq'::regclass);


--
-- Name: shop_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order_items ALTER COLUMN id SET DEFAULT nextval('public.shop_order_items_id_seq'::regclass);


--
-- Name: shop_reply_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_reply_templates ALTER COLUMN id SET DEFAULT nextval('public.shop_reply_templates_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: sms_campaigns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_campaigns ALTER COLUMN id SET DEFAULT nextval('public.sms_campaigns_id_seq'::regclass);


--
-- Name: sms_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs ALTER COLUMN id SET DEFAULT nextval('public.sms_logs_id_seq'::regclass);


--
-- Name: sms_sequence_enrollments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_enrollments ALTER COLUMN id SET DEFAULT nextval('public.sms_sequence_enrollments_id_seq'::regclass);


--
-- Name: sms_sequence_steps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_steps ALTER COLUMN id SET DEFAULT nextval('public.sms_sequence_steps_id_seq'::regclass);


--
-- Name: sms_sequences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequences ALTER COLUMN id SET DEFAULT nextval('public.sms_sequences_id_seq'::regclass);


--
-- Name: sms_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_templates ALTER COLUMN id SET DEFAULT nextval('public.sms_templates_id_seq'::regclass);


--
-- Name: stock_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustments_id_seq'::regclass);


--
-- Name: stock_audit_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items ALTER COLUMN id SET DEFAULT nextval('public.stock_audit_items_id_seq'::regclass);


--
-- Name: stock_audit_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_sessions ALTER COLUMN id SET DEFAULT nextval('public.stock_audit_sessions_id_seq'::regclass);


--
-- Name: stock_cost_lots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_lots ALTER COLUMN id SET DEFAULT nextval('public.stock_cost_lots_id_seq'::regclass);


--
-- Name: stock_reservations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations ALTER COLUMN id SET DEFAULT nextval('public.stock_reservations_id_seq'::regclass);


--
-- Name: supplier_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices ALTER COLUMN id SET DEFAULT nextval('public.supplier_invoices_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: supplies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplies ALTER COLUMN id SET DEFAULT nextval('public.supplies_id_seq'::regclass);


--
-- Name: supply_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements ALTER COLUMN id SET DEFAULT nextval('public.supply_movements_id_seq'::regclass);


--
-- Name: supply_stocks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_stocks ALTER COLUMN id SET DEFAULT nextval('public.supply_stocks_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: third_parties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.third_parties ALTER COLUMN id SET DEFAULT nextval('public.third_parties_id_seq'::regclass);


--
-- Name: ticket_canned_responses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_canned_responses ALTER COLUMN id SET DEFAULT nextval('public.ticket_canned_responses_id_seq'::regclass);


--
-- Name: ticket_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_categories ALTER COLUMN id SET DEFAULT nextval('public.ticket_categories_id_seq'::regclass);


--
-- Name: ticket_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments ALTER COLUMN id SET DEFAULT nextval('public.ticket_comments_id_seq'::regclass);


--
-- Name: ticket_priorities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_priorities ALTER COLUMN id SET DEFAULT nextval('public.ticket_priorities_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: units_of_measure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure ALTER COLUMN id SET DEFAULT nextval('public.units_of_measure_id_seq'::regclass);


--
-- Name: unknown_waybill_scans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unknown_waybill_scans ALTER COLUMN id SET DEFAULT nextval('public.unknown_waybill_scans_id_seq'::regclass);


--
-- Name: uploads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads ALTER COLUMN id SET DEFAULT nextval('public.uploads_id_seq'::regclass);


--
-- Name: user_module_access id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_module_access ALTER COLUMN id SET DEFAULT nextval('public.user_module_access_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouse_locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_locations ALTER COLUMN id SET DEFAULT nextval('public.warehouse_locations_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Name: waybill_tracking_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybill_tracking_history ALTER COLUMN id SET DEFAULT nextval('public.waybill_tracking_history_id_seq'::regclass);


--
-- Name: waybills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills ALTER COLUMN id SET DEFAULT nextval('public.waybills_id_seq'::regclass);


--
-- Name: webhook_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs ALTER COLUMN id SET DEFAULT nextval('public.webhook_logs_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_logs (id, user_id, action, entity_type, entity_id, metadata, ip_address, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: address_correction_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.address_correction_history (id, order_id, user_id, before, after, confidence_before, confidence_after, action, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: address_mappings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.address_mappings (id, country, region, province, city_municipality, barangay, island_group, courier_zone, postal_code, aliases, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.addresses (id, third_party_id, type, label, is_default, address_line1, address_line2, barangay, city, state_province, postal_code, country, contact_name, contact_phone, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_badges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_badges (id, user_id, badge_id, metadata, awarded_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_commissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_commissions (id, agent_id, order_id, product_id, lead_id, waybill_id, sale_amount, commission_rate, commission_amount, status, earned_at, approved_at, paid_at, cancelled_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flags (id, agent_id, flag_type, severity, description, metadata, is_resolved, resolved_by, resolved_at, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_milestones (id, user_id, milestone_id, current_value, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_profiles (id, user_id, max_active_cycles, product_skills, regions, priority_weight, is_available, performance_score, last_assignment_at, created_at, updated_at, distribution_weight, auto_assign_enabled, shift_start, shift_end, max_daily_leads, concurrent_lead_cap, preferred_lead_sources, excluded_regions, category_skills, last_seen_at, max_active_conversations, overflow_enabled, idle_threshold_minutes) FROM stdin;
\.


--
-- Data for Name: agent_streaks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_streaks (id, user_id, streak_type, current_streak, longest_streak, last_activity_date, streak_started_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_workloads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_workloads (agent_id, active_leads_count, today_assigned_count, today_converted_count, last_assigned_at, next_available_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: approval_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_rules (id, module, role_required, min_amount, max_amount, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: approval_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_settings (id, key, value, created_at, updated_at) FROM stdin;
1	pr_approver_roles	admin,supervisor	2026-08-02 07:21:07	2026-08-02 07:21:07
2	pr_approver_user_id	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
3	po_approver_roles	admin,finance	2026-08-02 07:21:07	2026-08-02 07:21:07
4	po_approver_user_id	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
5	adjustment_approver_roles	admin,supervisor,warehouse	2026-08-02 07:21:07	2026-08-02 07:21:07
6	adjustment_approver_user_id	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, auditable_type, auditable_id, user_id, action, old_values, new_values, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auto_merge_suggestions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_merge_suggestions (id, target_customer_id, source_customer_id, confidence_score, match_reasons, merge_preview, status, actioned_by, actioned_at, action_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.badges (id, name, slug, description, icon, color, category, criteria_type, criteria_value, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: batch_item_error_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_item_error_logs (id, courier_export_batch_id, courier_export_row_id, order_id, error_type, error_message, severity, resolution, resolved_at, resolved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: batch_scan_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_scan_items (id, batch_session_id, waybill_id, scanned_value, is_valid, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: batch_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_sessions (id, user_id, status, scanned_count, valid_count, invalid_count, started_at, closed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: batch_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_status_history (id, courier_export_batch_id, from_status, to_status, changed_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: broadcast_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.broadcast_campaigns (id, name, description, facebook_page_id, status, targeting, split_type, split_percentage, total_recipients, sent_count, delivered_count, read_count, replied_count, failed_count, scheduled_at, started_at, completed_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: broadcast_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.broadcast_recipients (id, broadcast_campaign_id, broadcast_variant_id, conversation_id, customer_id, status, error_message, message_id, sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: broadcast_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.broadcast_variants (id, broadcast_campaign_id, label, body, quick_replies, recipient_count, sent_count, delivered_count, read_count, replied_count, failed_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: capex_asset_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.capex_asset_assignments (id, capex_asset_id, assigned_to, department, location, assigned_at, returned_at, assigned_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: capex_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.capex_assets (id, asset_code, name, description, category, depreciation_years, purchase_date, acquisition_cost, salvage_value, current_book_value, status, warehouse_id, assigned_to, department, uom_id, quantity, disposed_at, disposal_reason, disposal_value, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: capex_depreciation_schedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.capex_depreciation_schedule (id, capex_asset_id, year, fiscal_year, opening_book_value, depreciation_amount, closing_book_value, depreciation_date, is_posted, posted_at, posted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cart_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_templates (id, user_id, name, items, courier_code, shipping_fee, discount_amount, tax_rate, remarks, is_shared, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.claims (id, claim_number, waybill_id, type, status, description, claim_amount, approved_amount, jnt_reference_number, filed_by, filed_at, reviewed_by, reviewed_at, resolved_at, resolution_notes, created_at, updated_at, deleted_at, auto_created, source) FROM stdin;
\.


--
-- Data for Name: cod_settlements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cod_settlements (id, courier_code, reference_number, period_start, period_end, total_cod_collected, courier_fee, net_amount, order_count, status, received_at, reconciled_at, notes, created_at, updated_at) FROM stdin;
1	JNT	COD-2026-07-001	2026-07-18	2026-08-01	42500.00	1275.00	41225.00	5	PENDING	\N	\N	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: cogs_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cogs_entries (id, product_id, variant_id, waybill_id, order_id, cost_lot_id, method, quantity, unit_cost, total_cost, currency_code, exchange_rate, recorded_at, synced_to_qbo_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: commission_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commission_rules (id, product_id, rate_type, rate_value, min_sale_amount, is_active, created_at, updated_at) FROM stdin;
1	\N	PERCENTAGE	3.00	500.00	t	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, third_party_id, first_name, last_name, title, "position", department, email, phone, phone_alt, is_primary, notes, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversation_assignment_histories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_assignment_histories (id, conversation_id, from_agent_id, to_agent_id, assigned_by_id, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversation_exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_exports (id, export_number, created_by, status, conversation_count, message_count, file_path, filters, exported_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversation_status_histories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_status_histories (id, conversation_id, from_status, to_status, changed_by_id, changed_by_role, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversation_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_tag (conversation_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, facebook_page_id, customer_id, customer_identity_id, assigned_agent_id, channel, status, thread_key, last_message_preview, last_message_at, unread_count, metadata, created_at, updated_at, deleted_at, priority, is_flagged, flag_reason, flagged_at, snoozed_until, reminder_at, snooze_reason, merged_into_id, first_response_at, resolved_at, first_response_time_seconds, resolution_time_seconds, sentiment, sentiment_score, typing_at, draft_body, archived_at, compressed_at, message_count) FROM stdin;
1	1	4	1	17	messenger	assigned	thread_001	Hi, when will my order arrive?	2026-08-02 06:59:55	1	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	normal	f	\N	\N	\N	\N	\N	\N	2026-08-02 05:29:55	\N	\N	\N	neutral	0	\N	\N	\N	\N	0
\.


--
-- Data for Name: courier_api_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_api_logs (id, courier_provider_id, courier_code, action, direction, endpoint, request_data, response_data, http_status, is_success, error_message, response_time_ms, waybill_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: courier_csv_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_csv_templates (id, name, courier_code, columns, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: courier_csv_validation_error_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_csv_validation_error_logs (id, courier_export_batch_id, courier_export_row_id, order_id, courier_code, error_type, error_message, context, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: courier_export_batch_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_export_batch_shares (id, courier_export_batch_id, token, created_by, expires_at, revoked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: courier_export_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_export_batches (id, batch_number, courier_code, status, created_by, row_count, file_path, exported_at, metadata, created_at, updated_at, downloaded_at, archived_at, region, notes, file_size, file_hash, file_generated_at) FROM stdin;
\.


--
-- Data for Name: courier_export_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_export_rows (id, courier_export_batch_id, order_id, row_number, status, receiver_name, phone_number, complete_address, province, city, barangay, landmark, product_name, cod_amount, quantity, remarks, payload, error_message, exported_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: courier_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_providers (id, code, name, is_active, config, api_endpoint, webhook_secret, created_at, updated_at) FROM stdin;
1	JNT	J&T Express	t	\N	https://api.jtexpress.ph/v1	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
2	LBC	LBC Express	t	\N	https://api.lbcexpress.com/v1	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: courier_sync_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_sync_logs (id, run_id, courier_code, trigger, waybills_checked, waybills_updated, waybills_unchanged, errors_count, errors, per_courier, duration_ms, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.currencies (code, name, symbol, decimal_places, is_active, created_at, updated_at) FROM stdin;
PHP	Philippine Peso	₱	2	t	2026-08-02 07:21:07	2026-08-02 07:21:07
USD	US Dollar	$	2	t	2026-08-02 07:21:07	2026-08-02 07:21:07
CNY	Chinese Yuan	¥	2	t	2026-08-02 07:21:07	2026-08-02 07:21:07
\.


--
-- Data for Name: customer_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_addresses (id, customer_id, label, canonical_address, landmark, barangay, city_municipality, province, region, postal_code, country, contact_name, contact_phone, is_default, source, used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_audit_logs (id, customer_id, user_id, action, field, before_state, after_state, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_identities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_identities (id, customer_id, facebook_page_id, provider, provider_user_id, display_name, profile_pic_url, phone_detected, first_seen_at, last_seen_at, metadata, created_at, updated_at) FROM stdin;
1	4	1	facebook	fb_user_001	Maria Santos	\N	09175551234	\N	\N	\N	2026-08-02 07:29:55	2026-08-02 07:29:55
\.


--
-- Data for Name: customer_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_notes (id, customer_id, user_id, note_type, body, tags, metadata, pinned_until, created_at, updated_at) FROM stdin;
1	4	17	agent_note	Customer prefers afternoon delivery. Always call before dispatch.	\N	\N	2026-09-01 07:29:55	2026-08-02 07:29:55	2026-08-02 07:29:55
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, phone, name, canonical_address, total_orders, successful_orders, returned_orders, success_rate, total_revenue, risk_level, is_blacklisted, blacklist_reason, blacklisted_at, created_at, updated_at, deleted_at, normalized_phone, facebook_name, landmark, barangay, city_municipality, province, region, last_page_ordered_from, last_order_date, tags, average_order_value, preferred_courier, payment_method, preferred_contact_method, preferred_contact_time, marketing_opt_out, language_preference, profile_image_path) FROM stdin;
1	09000000000	Fraudulent Customer 1	\N	0	0	0	0.00	0.00	BLACKLISTED	t	Chargeback fraud — 3 consecutive returns	2026-08-02 07:29:54	2026-08-02 07:29:54	2026-08-02 07:29:54	\N	09000000000	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	f	\N	\N
2	09000000001	Fraudulent Customer 2	\N	0	0	0	0.00	0.00	BLACKLISTED	t	Fake address — 5 returned orders	2026-08-02 07:29:54	2026-08-02 07:29:54	2026-08-02 07:29:54	\N	09000000001	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	f	\N	\N
3	09000000002	Fraudulent Customer 3	\N	0	0	0	0.00	0.00	BLACKLISTED	t	Impersonation scam reported	2026-08-02 07:29:54	2026-08-02 07:29:54	2026-08-02 07:29:54	\N	09000000002	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	f	\N	\N
4	09175551234	Maria Santos	123 Mabini St, Brgy San Roque, Quezon City, Metro Manila	5	4	1	80.00	12500.00	LOW	f	\N	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	639175551234	Maria Santos	Near Mercury Drug	San Roque	Quezon City	Metro Manila	NCR	\N	\N	["VIP", "Repeat Buyer"]	2500.00	JNT	COD	\N	\N	f	\N	\N
5	09185555678	Juan Dela Cruz	456 Rizal Ave, Brgy Malimban, San Fernando, Pampanga	2	1	1	50.00	3200.00	MEDIUM	f	\N	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	639185555678	Juan DC	Beside Jollibee	Malimban	San Fernando	Pampanga	Region III	\N	\N	["New Customer"]	1600.00	LBC	COD	\N	\N	f	\N	\N
\.


--
-- Data for Name: dashboard_widget_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_widget_configs (id, user_id, dashboard, widget_key, is_visible, sort_order, settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dead_stocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dead_stocks (id, item_type, supply_id, product_id, warehouse_id, quantity, unit_cost, total_value, reason, recorded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: delivery_proofs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_proofs (id, waybill_id, type, file_path, original_filename, mime_type, file_size, source, courier_code, metadata, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: distribution_queues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distribution_queues (id, lead_id, rule_id, status, assigned_agent_id, score_snapshot, attempt_count, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: distribution_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distribution_rules (id, name, strategy, priority, filters, weight_formula, is_active, supervisor_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_audit_logs (id, user_id, action, entity_type, entity_id, entity_label, before_state, after_state, note, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_detection_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_detection_rules (id, name, type, match_method, is_enabled, priority, config, description, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_families; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_families (id, type, group_key, group_method, anchor_ref_id, anchor_label, member_count, merged_count, status, metadata, actioned_by, actioned_at, action_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_family_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_family_members (id, family_id, customer_id, is_anchor, member_data, match_reason, similarity_score, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_ml_models (id, name, version, feature_weights, training_stats, training_samples, accuracy, "precision", recall, f1_score, trained_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_notifications (id, user_id, type, severity, title, message, entity_type, entity_id, action_url, action_label, metadata, read_at, read_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_review_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.duplicate_review_items (id, type, primary_ref_id, duplicate_ref_id, primary_label, duplicate_label, match_method, similarity_score, severity, status, metadata, reviewed_by, reviewed_at, review_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_rates (id, from_currency, to_currency, rate, rate_date, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: facebook_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.facebook_accounts (id, user_id, facebook_user_id, facebook_user_name, email, access_token, token_expires_at, status, connected_at, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: facebook_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.facebook_pages (id, facebook_account_id, connected_by, page_id, page_name, category, business_id, page_access_token, token_expires_at, connected_status, webhook_status, last_sync_at, metadata, created_at, updated_at, deleted_at, default_courier) FROM stdin;
1	\N	15	fb_page_001	TECC Official Store	\N	\N	\N	\N	connected	subscribed	2026-08-02 05:29:55	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	JNT
2	\N	15	fb_page_002	TECC Promo Deals	\N	\N	\N	\N	connected	subscribed	2026-08-02 02:29:55	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	LBC
\.


--
-- Data for Name: facebook_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.facebook_webhook_events (id, facebook_page_id, event_id, object, event_type, sender_psid, recipient_id, payload, signature_valid, processed_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: finance_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.finance_settings (id, key, value, locked_at, locked_by, locked_trigger_reference, created_at, updated_at) FROM stdin;
1	cogs_method	{"method":"FIFO"}	\N	\N	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
2	default_currency	{"code":"PHP"}	\N	\N	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
3	fiscal_year_start_month	{"month":1}	\N	\N	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
4	reservation_expiry_cart	{"minutes":30}	\N	\N	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
5	reservation_expiry_order	{"hours":24}	\N	\N	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
6	pr_auto_approve_under	{"amount":5000}	\N	\N	\N	2026-08-02 07:21:07	2026-08-02 07:21:07
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_transactions (id, type, amount, reference_type, reference_id, description, recorded_by, transaction_date, created_at, updated_at) FROM stdin;
1	income	41225.00	App\\Domain\\Finance\\Models\\CodSettlement	\N	COD Settlement - JNT - July Batch 1	19	2026-08-01	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: fraud_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fraud_flags (id, agent_id, lead_id, flag_type, severity, details, is_reviewed, reviewed_by, reviewed_at, resolution_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: import_chunks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_chunks (id, upload_id, chunk_number, status, rows_count, inserted_count, updated_count, error_count, errors, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_movements (id, product_id, variant_id, type, quantity, reference_type, reference_id, notes, performed_by, created_at, updated_at, warehouse_id, location_id, to_location_id, batch_number, expiry_date, approved_by, approved_at) FROM stdin;
\.


--
-- Data for Name: invoice_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_lines (id, invoice_id, "position", product_id, product_ref, description, unit, qty, unit_price, discount_pct, discount_amount, tax_rate, tax_amount, total_ht, total_ttc, created_at, updated_at) FROM stdin;
1	1	0	\N	\N	Smartphone X Pro 128GB x50 units	\N	50.000	6200.00	0.00	0.00	0.00	0.00	310000.00	310000.00	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_payments (id, invoice_id, amount, payment_date, payment_method, reference_number, notes, recorded_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, ref, type, status, third_party_id, client_name, client_email, client_phone, client_address, order_id, quotation_id, date_invoice, date_due, date_sent, payment_terms, currency, subtotal, discount_amount, tax_rate, tax_amount, shipping_amount, total_amount, amount_paid, amount_due, notes, terms, footer, cancel_reason, cancelled_at, created_by, updated_by, deleted_at, created_at, updated_at) FROM stdin;
1	INV-2026-00001	standard	SENT	1	TechBrand Distributors Inc.	orders@techbrand-dist.com	\N	\N	\N	\N	2026-07-28	2026-08-27	\N	NET_30	PHP	310000.00	0.00	0.00	0.00	0.00	310000.00	0.00	310000.00	\N	\N	\N	\N	\N	19	\N	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: lead_cycles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_cycles (id, lead_id, cycle_number, assigned_agent_id, status, outcome, notes, opened_at, closed_at, created_at, updated_at, last_call_at, call_count, callback_at, callback_notes) FROM stdin;
\.


--
-- Data for Name: lead_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_logs (id, lead_id, user_id, customer_id, action, old_value, new_value, notes, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lead_pool_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_pool_audit (id, lead_id, lead_cycle_id, user_id, action, old_value, new_value, metadata, ip_address, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lead_recycling_pool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_recycling_pool (id, lead_id, previous_agent_id, assigned_agent_id, status, reason, priority, cooldown_hours, available_at, assigned_at, processed_at, outcome, outcome_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lead_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lead_snapshots (id, lead_id, cycle_id, data, trigger_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leads (id, customer_id, recycling_pool_id, name, phone, address, city, state, barangay, street, postal_code, status, sales_status, source, assigned_to, uploaded_by, original_agent_id, last_called_at, call_attempts, notes, product_name, product_brand, previous_item, amount, assigned_at, total_cycles, max_cycles, is_exhausted, quality_score, last_scored_at, current_qa_level, qa_required, created_at, updated_at, deleted_at, pool_status, cooldown_until) FROM stdin;
2	\N	\N	Cristina Reyes	09195558888	789 Aurora Blvd, Cubao, Quezon City	Quezon City	Metro Manila	\N	\N	\N	NEW	NEW	FACEBOOK	17	\N	\N	\N	0	\N	Smartphone X Pro 128GB	TechBrand	\N	8500.00	\N	1	3	f	85	\N	1	t	2026-08-02 07:29:56	2026-08-02 07:29:56	\N	AVAILABLE	\N
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, facebook_page_id, customer_identity_id, external_message_id, direction, message_type, body, attachments, phone_candidates, raw_payload, sent_at, created_at, updated_at, read_at, send_status, send_error, retry_count, metadata, reactions, is_flagged, flag_reason, translated_body, translated_lang, moderation_status, moderation_note, moderated_at, moderated_by, sent_by) FROM stdin;
1	1	1	\N	msg_001	inbound	text	Hi, when will my order arrive?	\N	\N	\N	2026-08-02 06:59:55	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	delivered	\N	0	\N	\N	f	\N	\N	\N	approved	\N	\N	\N	\N
2	1	1	\N	msg_002	outbound	text	Hi Maria! Your order is out for delivery today via J&T. Expected arrival 2-4 PM.	\N	\N	\N	2026-08-02 07:09:55	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	sent	\N	0	\N	\N	f	\N	\N	\N	approved	\N	\N	\N	17
\.


--
-- Data for Name: meta_data_deletion_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meta_data_deletion_requests (id, confirmation_code, app_scoped_user_id, status, source, payload, result_summary, requested_at, processed_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2024_01_01_000001_create_waybill_system_tables	1
6	2024_01_01_000002_create_lead_system_tables	1
7	2024_01_01_000003_create_agent_system_tables	1
8	2024_01_01_000004_add_foreign_keys	1
9	2024_01_01_000010_add_jnt_fields_to_waybills_table	1
10	2024_06_03_000001_create_permissions_table	1
11	2026_03_22_000001_add_pool_status_to_leads	1
12	2026_03_22_000002_add_call_tracking_to_lead_cycles	1
13	2026_03_22_000003_create_recycling_rules_table	1
14	2026_03_22_000004_create_fraud_flags_table	1
15	2026_03_22_000005_create_lead_pool_audit_table	1
16	2026_03_22_163200_create_sms_system_tables	1
17	2026_03_24_000001_add_appearance_columns_to_users_table	1
18	2026_03_28_000001_create_courier_api_logs_table	1
19	2026_04_07_000001_create_product_system_tables	1
20	2026_04_07_000002_create_orders_table	1
21	2026_04_07_000003_create_finance_tables	1
22	2026_04_11_000001_add_performance_indexes	1
23	2026_04_11_000002_add_waybill_status_protection_trigger	1
24	2026_04_22_000001_create_claims_and_return_receipts_tables	1
25	2026_04_22_000002_create_unknown_waybill_scans_and_indexes	1
26	2026_04_25_000001_create_eims_phase1_tables	1
27	2026_05_10_add_import_fields_to_uploads	1
28	2026_05_11_000001_create_shop_pos_tables	1
29	2026_05_12_000001_create_shop_reply_templates_table	1
30	2026_05_13_000001_create_meta_data_deletion_requests_table	1
31	2026_05_29_000001_create_system_settings_table	1
32	2026_06_05_000001_add_pipeline_architecture_to_uploads	1
33	2026_06_06_000001_create_site_settings_table	1
34	2026_06_08_000001_create_user_module_access_table	1
35	2026_06_08_100000_create_notifications_table	1
36	2026_06_08_100001_create_approval_settings_table	1
37	2026_06_08_200000_fix_product_stocks_unique_constraint	1
38	2026_06_09_000001_add_last_movement_at_to_stock_tables	1
39	2026_06_09_000002_add_roll_and_sack_units_of_measure	1
40	2026_06_09_100001_add_section_stock_status_to_supplies	1
41	2026_06_09_100002_create_capex_assets_tables	1
42	2026_06_10_000001_create_third_parties_table	1
43	2026_06_10_000002_create_contacts_table	1
44	2026_06_10_000003_create_addresses_table	1
45	2026_06_10_000004_create_invoices_table	1
46	2026_06_10_000005_create_supplier_invoices_table	1
47	2026_06_10_100000_create_dead_stocks_table	1
48	2026_06_11_000001_add_distribution_fields_to_agent_profiles	1
49	2026_06_11_000002_create_distribution_rules_table	1
50	2026_06_11_000003_create_distribution_queues_table	1
51	2026_06_11_000004_create_agent_workloads_table	1
52	2026_06_30_000001_add_soft_deletes_to_invoice_payments	1
53	2026_07_12_000001_enforce_customer_phone_dedup	1
54	2026_07_12_000002_add_message_read_send_state_columns	1
55	2026_07_12_000003_create_customer_addresses_table	1
56	2026_07_12_000004_create_customer_notes_table	1
57	2026_07_12_000005_add_tags_to_customers_table	1
58	2026_07_12_000006_add_average_order_value_to_customers_table	1
59	2026_07_12_000007_add_preference_fields_to_customers_table	1
60	2026_07_12_000008_add_priority_and_flagging_to_conversations_table	1
61	2026_07_12_000009_create_conversation_tags_table	1
62	2026_07_12_000010_drop_tags_column_from_conversations_table	1
63	2026_07_12_000011_add_snooze_and_reminder_to_conversations_table	1
64	2026_07_12_000012_add_merged_into_to_conversations_table	1
65	2026_07_12_000013_add_analytics_to_conversations_table	1
66	2026_07_12_000014_add_sentiment_to_conversations_table	1
67	2026_07_12_000015_create_conversation_exports_table	1
68	2026_07_13_000001_add_metadata_to_messages_table	1
69	2026_07_13_000002_add_typing_at_to_conversations_table	1
70	2026_07_13_000003_add_reactions_to_messages_table	1
71	2026_07_13_000004_add_draft_body_to_conversations_table	1
72	2026_07_13_000005_add_flag_fields_to_messages_table	1
73	2026_07_13_000006_add_translation_fields_to_messages_table	1
74	2026_07_13_000007_create_scheduled_messages_table	1
75	2026_07_13_000008_add_status_workflow_to_courier_export_batches	1
76	2026_07_13_000009_add_region_to_courier_export_batches	1
77	2026_07_13_000010_add_notes_to_courier_export_batches	1
78	2026_07_14_000001_create_page_favorites_table	1
79	2026_07_14_000002_create_page_assignment_rules_table	1
80	2026_07_14_000003_add_moderation_fields_to_messages_table	1
81	2026_07_14_000004_add_facebook_page_id_to_shop_reply_templates	1
82	2026_07_14_000005_add_last_seen_at_to_agent_profiles	1
83	2026_07_14_000006_create_conversation_assignment_histories_table	1
84	2026_07_14_000007_add_queue_limits_to_agent_profiles	1
85	2026_07_14_000008_add_idle_threshold_to_agent_profiles	1
86	2026_07_14_000009_migrate_conversation_statuses_to_canonical	1
87	2026_07_14_000010_create_conversation_status_histories_table	1
88	2026_07_15_000001_add_discount_amount_to_orders_table	1
89	2026_07_15_000001_create_page_status_labels_table	1
90	2026_07_15_000002_add_color_to_page_status_labels_table	1
91	2026_07_15_000002_create_shipping_rates_table	1
92	2026_07_15_000003_add_tax_columns_to_orders_table	1
93	2026_07_15_000003_create_page_status_rules_table	1
94	2026_07_15_000004_add_draft_data_to_orders_table	1
95	2026_07_15_000004_add_sent_by_to_messages_table	1
96	2026_07_15_000005_create_cart_templates_table	1
97	2026_07_16_000001_add_default_courier_to_facebook_pages	1
98	2026_07_16_000001_add_parent_order_id_to_orders_table	1
99	2026_07_16_000002_add_remarks_to_orders_table	1
100	2026_07_16_000003_add_visibility_to_order_remarks_table	1
101	2026_07_16_000004_create_remark_templates_table	1
102	2026_07_16_000005_add_parent_id_to_order_remarks_table	1
103	2026_07_18_000001_add_mentions_to_order_remarks_table	1
104	2026_07_18_000002_add_pinning_to_order_remarks_table	1
105	2026_07_18_000003_add_tags_to_order_remarks_table	1
106	2026_07_18_000004_add_landmark_columns_to_orders_table	1
107	2026_07_18_000005_create_address_correction_history_table	1
108	2026_07_18_000006_add_coordinates_to_orders_table	1
109	2026_07_18_000007_add_hold_columns_to_orders_table	1
110	2026_07_18_000008_create_order_tag_table	1
111	2026_07_18_000009_add_scheduled_delivery_to_orders_table	1
112	2026_07_19_000001_create_batch_status_history_table	1
113	2026_07_19_000002_add_file_metadata_to_courier_export_batches_table	1
114	2026_07_19_000003_create_batch_item_error_logs_table	1
115	2026_07_20_000001_create_courier_export_batch_shares_table	1
116	2026_07_20_053000_create_courier_csv_validation_error_logs_table	1
117	2026_07_20_060000_create_courier_csv_templates_table	1
118	2026_07_21_000001_create_dashboard_widget_configs_table	1
119	2026_07_21_000001_create_duplicate_review_items_table	1
120	2026_07_21_000002_create_duplicate_detection_rules_table	1
121	2026_07_21_000002_create_scheduled_sales_reports_table	1
122	2026_07_21_000003_create_auto_merge_suggestions_table	1
123	2026_07_21_000004_create_duplicate_families_table	1
124	2026_07_21_000005_create_duplicate_notifications_table	1
125	2026_07_21_000006_create_duplicate_audit_logs_table	1
126	2026_07_21_000007_create_duplicate_ml_models_table	1
127	2026_07_21_000008_create_reply_templates_table	1
128	2026_07_21_000009_add_variables_to_reply_templates_table	1
129	2026_07_22_000010_add_category_intent_to_reply_templates_table	1
130	2026_07_22_000011_create_reply_template_favorites_table	1
131	2026_07_22_000012_add_allowed_roles_to_reply_templates_table	1
132	2026_07_22_000013_create_reply_template_usage_table	1
133	2026_07_22_000014_create_reply_template_shares_table	1
134	2026_07_22_000015_create_reply_template_versions_table	1
135	2026_07_22_000016_add_approval_workflow_to_reply_templates_table	1
136	2026_07_22_000017_create_reply_template_ab_tests_table	1
137	2026_07_23_000018_add_language_to_reply_templates_table	1
138	2026_07_23_000019_add_communication_preferences_to_customers_table	1
139	2026_07_23_000020_create_customer_audit_logs_table	1
140	2026_07_23_000021_add_profile_image_path_to_customers_table	1
141	2026_07_27_000001_create_tickets_table	1
142	2026_07_28_000001_create_ticket_categories_table	1
143	2026_07_28_000001_create_ticket_comments_table	1
144	2026_07_28_000002_create_ticket_priorities_table	1
145	2026_07_28_000003_add_sla_fields_to_tickets_table	1
146	2026_07_28_000004_create_ticket_canned_responses_table	1
147	2026_07_28_000005_add_satisfaction_survey_to_tickets_table	1
148	2026_07_29_000001_add_birthday_and_hire_date_to_users_table	1
149	2026_07_29_000002_create_broadcast_campaigns_tables	1
150	2026_07_30_000001_add_sharing_columns_to_cart_templates_table	1
151	2026_07_30_000002_add_media_columns_to_reply_templates_table	1
152	2026_07_30_000003_add_archive_columns_to_conversations_table	1
153	2026_07_30_000004_create_gamification_tables	1
154	2026_07_30_000005_create_courier_sync_logs_table	1
155	2026_07_30_000006_add_retry_tracking_to_uploads_table	1
156	2026_07_30_000007_add_auto_created_to_claims_table	1
157	2026_07_30_000008_create_delivery_proofs_table	1
158	2026_07_30_000010_add_geolocation_to_waybills_and_tracking	1
159	2026_07_30_000011_add_workflow_fields_to_return_receipts	1
160	2026_08_01_000001_make_order_remarks_order_id_nullable	1
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.milestones (id, name, slug, description, metric, target_value, period, reward_badge_id, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, type, notifiable_type, notifiable_id, data, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: order_remarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_remarks (id, order_id, conversation_id, user_id, type, body, metadata, created_at, updated_at, visibility, parent_id, mentions, is_pinned, pinned_at, pinned_by, tags) FROM stdin;
\.


--
-- Data for Name: order_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_tag (order_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, lead_id, customer_id, product_id, variant_id, assigned_agent_id, status, courier_code, waybill_id, quantity, unit_price, total_amount, cod_amount, shipping_cost, receiver_name, receiver_phone, receiver_address, city, state, barangay, postal_code, notes, rejection_reason, confirmed_at, dispatched_at, delivered_at, returned_at, created_at, updated_at, deleted_at, conversation_id, facebook_page_id, encoder_id, address_mapping_id, source_channel, address_confidence, export_status, encoded_at, discount_amount, tax_rate, tax_amount, draft_data, parent_order_id, remarks, landmark, nearest_landmark, latitude, longitude, held_at, hold_reason, scheduled_delivery_at, reschedule_reason) FROM stdin;
1	ORD-20260802-0001	\N	4	1	\N	17	DISPATCHED	JNT	\N	1	8500.00	8500.00	8500.00	150.00	Maria Santos	09175551234	123 Mabini St, Quezon City	Quezon City	Metro Manila	San Roque	\N	\N	\N	2026-07-31 07:29:55	2026-08-02 01:29:55	\N	\N	2026-08-02 07:29:56	2026-08-02 07:29:56	\N	\N	\N	\N	\N	facebook	\N	pending	\N	0.00	0.00	0.00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: page_assignment_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_assignment_rules (id, facebook_page_id, user_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_favorites (id, user_id, facebook_page_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: page_status_labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_status_labels (id, facebook_page_id, status, label, created_at, updated_at, color) FROM stdin;
\.


--
-- Data for Name: page_status_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_status_rules (id, facebook_page_id, from_status, to_status, inactivity_minutes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, key, label, section, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_stocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_stocks (id, product_id, variant_id, current_stock, reserved_stock, reorder_point, last_restock_at, created_at, updated_at, warehouse_id, location_id, last_movement_at) FROM stdin;
1	1	\N	120	15	30	2026-07-26 07:29:55	2026-08-02 07:29:55	2026-08-02 07:29:55	2	\N	2026-08-02 04:29:55
2	2	\N	25	5	20	2026-07-19 07:29:55	2026-08-02 07:29:55	2026-08-02 07:29:55	2	\N	2026-07-31 07:29:55
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (id, product_id, sku, variant_name, selling_price, cost_price, weight_grams, is_active, created_at, updated_at) FROM stdin;
1	1	TECC-PHONE-001-BLK	Black	8500.00	\N	350	t	2026-08-02 07:29:55	2026-08-02 07:29:55
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, sku, name, brand, category, selling_price, cost_price, weight_grams, description, image_url, is_active, requires_qa, created_at, updated_at, deleted_at, barcode, qr_code, uom_id, min_stock_level, max_stock_level, expiry_tracking) FROM stdin;
1	TECC-PHONE-001	Smartphone X Pro 128GB	TechBrand	Electronics	8500.00	6200.00	350	Smartphone X Pro with 128GB storage, 6.5" display, 5000mAh battery.	\N	t	t	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	4800123456789	\N	\N	0	\N	f
2	TECC-CASE-001	Premium Phone Case X Pro	TechBrand	Accessories	450.00	180.00	80	Premium silicone phone case for Smartphone X Pro.	\N	t	f	2026-08-02 07:29:55	2026-08-02 07:29:55	\N	4800123456790	\N	\N	0	\N	f
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, po_id, product_id, supply_id, variant_id, uom_id, quantity_ordered, quantity_received, unit_price, tax_rate, line_total, notes, created_at, updated_at) FROM stdin;
1	1	1	\N	\N	9	50	0	6200.0000	0.00	310000.00	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, po_number, pr_id, supplier_id, warehouse_id, payment_terms, expected_delivery_date, status, currency_code, exchange_rate, exchange_rate_date, subtotal, tax_amount, total_amount, approved_by, approved_at, sent_at, qbo_po_id, notes, created_by, created_at, updated_at, deleted_at) FROM stdin;
1	PO-20260802-0001	1	1	2	NET_30	2026-08-09	SENT	PHP	1.000000	\N	310000.00	0.00	310000.00	15	2026-07-31 07:29:56	2026-08-01 07:29:56	\N	\N	15	2026-08-02 07:29:56	2026-08-02 07:29:56	\N
\.


--
-- Data for Name: purchase_request_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_request_items (id, pr_id, product_id, supply_id, variant_id, uom_id, quantity_requested, unit_price_estimate, notes, created_at, updated_at) FROM stdin;
1	1	1	\N	\N	9	50	6200.0000	Black variant preferred	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: purchase_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_requests (id, pr_number, requested_by, department, reason, priority, needed_by_date, status, approved_by, approved_at, rejected_reason, estimated_total, created_at, updated_at, deleted_at) FROM stdin;
1	PR-20260802-0001	18	Operations	Restocking for Q3 demand	high	2026-08-12	APPROVED	15	2026-07-30 07:29:56	\N	310000.00	2026-08-02 07:29:56	2026-08-02 07:29:56	\N
\.


--
-- Data for Name: qa_decision_reasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qa_decision_reasons (id, code, label, type, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: qa_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qa_reviews (id, lead_id, reviewer_id, qa_level, qa_status, decision, notes, checklist, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: qbo_account_mappings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qbo_account_mappings (id, mapping_key, qbo_account_id, qbo_account_name, mapped_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: qbo_connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qbo_connections (id, realm_id, access_token, refresh_token, expires_at, environment, connected_by, connected_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: qbo_sync_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qbo_sync_queue (id, entity_type, entity_id, operation, idempotency_key, status, qbo_id, payload, error_message, attempts, synced_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: receiving_report_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receiving_report_items (id, grn_id, po_item_id, quantity_received, quantity_rejected, rejection_reason, condition, batch_number, expiry_date, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: receiving_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receiving_reports (id, grn_number, po_id, warehouse_id, location_id, received_by, received_at, exchange_rate, exchange_rate_date, status, notes, discrepancy_notes, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recycling_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recycling_rules (id, outcome, cooldown_hours, max_cycles, next_action, is_active, created_at, updated_at) FROM stdin;
1	NO_ANSWER	24	5	RECYCLE	t	2026-08-02 07:21:06	2026-08-02 07:21:06
2	CALLBACK	0	999	RECYCLE	t	2026-08-02 07:21:06	2026-08-02 07:21:06
3	INTERESTED	48	3	RECYCLE	t	2026-08-02 07:21:06	2026-08-02 07:21:06
4	NOT_INTERESTED	720	2	EXHAUST	t	2026-08-02 07:21:06	2026-08-02 07:21:06
5	WRONG_NUMBER	0	1	EXHAUST	t	2026-08-02 07:21:06	2026-08-02 07:21:06
6	ORDERED	1440	999	RECYCLE	t	2026-08-02 07:21:06	2026-08-02 07:21:06
\.


--
-- Data for Name: remark_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.remark_templates (id, name, body, type, visibility, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reply_template_ab_tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_template_ab_tests (id, name, description, status, created_by, start_at, end_at, winning_variant_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reply_template_ab_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_template_ab_variants (id, ab_test_id, reply_template_id, variant_label, weight, impressions, uses, conversations_resolved, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reply_template_favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_template_favorites (id, user_id, reply_template_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reply_template_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_template_shares (id, reply_template_id, facebook_page_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reply_template_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_template_usage (id, reply_template_id, user_id, conversation_id, created_at) FROM stdin;
\.


--
-- Data for Name: reply_template_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_template_versions (id, reply_template_id, edited_by, version_number, title, content, variables, category, intent, allowed_roles, shortcut, facebook_page_id, is_active, shared_page_ids, change_summary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reply_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_templates (id, title, content, shortcut, facebook_page_id, created_by, is_active, usage_count, created_at, updated_at, deleted_at, variables, category, intent, allowed_roles, approval_status, approved_by, approved_at, rejection_reason, language, media_type, media_config) FROM stdin;
\.


--
-- Data for Name: return_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_receipts (id, waybill_id, scanned_by, scanned_at, condition, notes, created_at, updated_at, inventory_updated, inventory_movement_id, finance_notified, processed_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role, permission_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scheduled_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_messages (id, conversation_id, facebook_page_id, customer_identity_id, body, quick_replies, scheduled_at, status, sent_message_id, created_by, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scheduled_sales_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_sales_reports (id, user_id, name, frequency, send_at, day_of_week, day_of_month, format, lookback_days, recipients, is_active, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, key, value, type, "group", description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shipping_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_rates (id, courier_code, courier_zone, base_fee, per_kg_fee, weight_threshold_kg, cod_fee, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shop_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_order_items (id, order_id, product_id, variant_id, sku, product_name, quantity, unit_price, discount_amount, line_total, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shop_reply_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_reply_templates (id, name, message, category, variables, is_active, sort_order, created_by, created_at, updated_at, facebook_page_id) FROM stdin;
1	Same Address Check	Hello po, same address pa rin po ba ito?\n{address}	confirmation	["{address}"]	t	10	\N	2026-08-02 07:21:07	2026-08-02 07:21:07	\N
2	Ask Complete Details	Hello po {customer_name}, paki-send po complete name, complete address, landmark, and active phone number para ma-process po ang order ninyo.	details	["{customer_name}"]	t	20	\N	2026-08-02 07:21:07	2026-08-02 07:21:07	\N
3	Confirm Order	Confirm ko lang po ang order ninyo sa {page_name}. Paki-check po kung tama ang product, quantity, complete address, and COD amount bago namin i-process.	confirmation	["{page_name}"]	t	30	\N	2026-08-02 07:21:07	2026-08-02 07:21:07	\N
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, key, value) FROM stdin;
1	integration_google_workspace	connected
2	integration_slack	connected
3	integration_microsoft_365	disconnected
4	integration_webhook	disconnected
\.


--
-- Data for Name: sms_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_campaigns (id, name, message, type, status, target_audience, filters, total_recipients, sent_count, failed_count, delivered_count, scheduled_at, started_at, completed_at, created_by, created_at, updated_at) FROM stdin;
1	July Flash Sale Blast	Hi! Get 15% off on Smartphone X Pro this weekend only. Visit TECC Official Store to order now!	broadcast	completed	all_customers	\N	150	148	2	145	\N	2026-07-30 07:29:56	2026-07-30 07:29:56	15	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: sms_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_logs (id, campaign_id, sequence_id, waybill_id, lead_id, phone, message, status, external_id, error_message, cost, sent_at, delivered_at, created_at, updated_at) FROM stdin;
1	1	\N	\N	\N	09175551234	Hi! Get 15% off on Smartphone X Pro this weekend only. Visit TECC Official Store to order now!	delivered	\N	\N	\N	2026-07-30 07:29:56	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: sms_sequence_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_sequence_enrollments (id, sequence_id, waybill_id, lead_id, phone, current_step, status, next_step_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sms_sequence_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_sequence_steps (id, sequence_id, step_order, message, delay_minutes, delay_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sms_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_sequences (id, name, description, trigger_event, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sms_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_templates (id, name, message, category, variables, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_adjustments (id, product_id, supply_id, variant_id, warehouse_id, location_id, reason_code, reason_notes, quantity_before, quantity_after, variance, status, submitted_by, approved_by, approved_at, created_at, updated_at) FROM stdin;
1	2	\N	\N	2	\N	DAMAGE	5 units damaged during handling	30	25	-5	approved	18	15	2026-07-31 07:29:55	2026-08-02 07:29:55	2026-08-02 07:29:55
\.


--
-- Data for Name: stock_audit_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_audit_items (id, session_id, product_id, supply_id, variant_id, location_id, system_qty, counted_qty, variance, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_audit_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_audit_sessions (id, warehouse_id, name, status, started_by, finalized_by, started_at, finalized_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_cost_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_cost_lots (id, product_id, variant_id, warehouse_id, grn_item_id, quantity_received, quantity_remaining, unit_cost, currency_code, exchange_rate, received_at, expiry_date, batch_number, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_reservations (id, product_id, variant_id, warehouse_id, quantity, reference_type, reference_id, reserved_by, reserved_at, expires_at, status, released_at, released_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supplier_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_invoices (id, ref, status, third_party_id, supplier_name, supplier_email, supplier_phone, supplier_address, order_id, invoice_id, date_invoice, date_due, date_receipt, payment_terms, currency, subtotal, discount_amount, tax_rate, tax_amount, shipping_amount, total_amount, amount_paid, amount_due, notes, terms, cancel_reason, cancelled_at, created_by, updated_by, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, code, contact_person, email, phone, address, payment_terms, lead_time_days, is_active, qbo_vendor_id, created_at, updated_at, deleted_at) FROM stdin;
1	TechBrand Distributors Inc.	SUP-001	Lisa Chen	orders@techbrand-dist.com	09220003333	8F Corporate Tower, Makati City	NET_30	7	t	\N	2026-08-02 07:29:56	2026-08-02 07:29:56	\N
\.


--
-- Data for Name: supplies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplies (id, sku, name, category, uom_id, cost_price, min_stock_level, reorder_point, description, is_active, created_at, updated_at, deleted_at, section, stock_category, opex_category, stock_status, stock_status_override, delete_reason) FROM stdin;
1	SUP-BOX-SM	Small Box (20x15x10cm)	\N	\N	12.0000	100	50	\N	t	2026-08-02 07:29:56	2026-08-02 07:29:56	\N	STOCK	MERCHANDISE	\N	MOVING	f	\N
\.


--
-- Data for Name: supply_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_movements (id, supply_id, type, quantity, warehouse_id, location_id, to_location_id, reference_type, reference_id, batch_number, notes, performed_by, approved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supply_stocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_stocks (id, supply_id, warehouse_id, location_id, current_stock, reserved_stock, reorder_point, last_restock_at, created_at, updated_at, last_movement_at) FROM stdin;
1	1	2	\N	250	30	50	2026-07-23 07:29:56	2026-08-02 07:29:56	2026-08-02 07:29:56	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, key, value, "group", type, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, slug, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: third_parties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.third_parties (id, ref, name, alias, type, email, phone, phone_alt, website, tax_id, industry, currency, payment_terms, credit_limit, address_line1, city, state_province, postal_code, country, status, source, assigned_to, notes, tags, risk_level, is_blacklisted, blacklist_reason, blacklisted_at, total_orders, successful_orders, returned_orders, total_revenue, success_rate, last_order_date, customer_id, created_by, updated_by, deleted_at, created_at, updated_at) FROM stdin;
1	TP-0001	TechBrand Distributors Inc.	\N	supplier	orders@techbrand-dist.com	09220003333	\N	\N	\N	\N	PHP	NET_30	500000.00	8F Corporate Tower, Makati City	Makati City	Metro Manila	\N	Philippines	active	\N	\N	\N	\N	LOW	f	\N	\N	0	0	0	0.00	0.00	\N	\N	15	\N	\N	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: ticket_canned_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_canned_responses (id, title, body, category, is_active, usage_count, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: ticket_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_categories (id, name, slug, color, is_active, sort_order, created_at, updated_at) FROM stdin;
1	General	general	gray	t	1	2026-08-02 07:21:09	2026-08-02 07:21:09
2	Waybill	waybill	blue	t	2	2026-08-02 07:21:09	2026-08-02 07:21:09
3	Delivery	delivery	green	t	3	2026-08-02 07:21:09	2026-08-02 07:21:09
4	Product	product	purple	t	4	2026-08-02 07:21:09	2026-08-02 07:21:09
5	Billing	billing	amber	t	5	2026-08-02 07:21:09	2026-08-02 07:21:09
6	Technical	technical	red	t	6	2026-08-02 07:21:09	2026-08-02 07:21:09
7	Other	other	gray	t	7	2026-08-02 07:21:09	2026-08-02 07:21:09
\.


--
-- Data for Name: ticket_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_comments (id, ticket_id, user_id, body, is_internal, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_priorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_priorities (id, name, slug, color, level, is_active, sort_order, created_at, updated_at) FROM stdin;
1	Low	low	gray	1	t	1	2026-08-02 07:21:09	2026-08-02 07:21:09
2	Medium	medium	amber	2	t	2	2026-08-02 07:21:09	2026-08-02 07:21:09
3	High	high	orange	3	t	3	2026-08-02 07:21:09	2026-08-02 07:21:09
4	Urgent	urgent	red	4	t	4	2026-08-02 07:21:09	2026-08-02 07:21:09
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tickets (id, ticket_number, subject, description, status, priority, category, created_by, assigned_to, related_waybill, related_lead, created_at, updated_at, deleted_at, due_at, resolved_at, satisfaction_rating, satisfaction_comment, satisfaction_submitted_at) FROM stdin;
\.


--
-- Data for Name: units_of_measure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units_of_measure (id, name, abbreviation, is_active, created_at, updated_at) FROM stdin;
1	Pieces	pcs	t	2026-08-02 07:21:07	2026-08-02 07:21:07
2	Boxes	box	t	2026-08-02 07:21:07	2026-08-02 07:21:07
3	Cases	case	t	2026-08-02 07:21:07	2026-08-02 07:21:07
4	Pack	pack	t	2026-08-02 07:21:07	2026-08-02 07:21:07
5	Kg	kg	t	2026-08-02 07:21:07	2026-08-02 07:21:07
6	Liter	L	t	2026-08-02 07:21:07	2026-08-02 07:21:07
7	Roll	roll	t	2026-08-02 07:21:07	2026-08-02 07:21:07
8	Sack	sack	t	2026-08-02 07:21:07	2026-08-02 07:21:07
9	Piece	pc	t	2026-08-02 07:29:56	2026-08-02 07:29:56
\.


--
-- Data for Name: unknown_waybill_scans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unknown_waybill_scans (id, waybill_no, scanned_by, scanned_at, scan_session_id, resolution_status, resolved_to_waybill_id, notes, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.uploads (id, filename, original_filename, type, total_rows, processed_rows, success_rows, error_rows, status, errors, uploaded_by, created_at, updated_at, courier, import_type, inserted_rows, updated_rows, skipped_rows, file_hash, started_at, completed_at, uuid, file_path, total_chunks, processed_chunks, metadata, auto_import, retry_count, retry_of, retry_status) FROM stdin;
\.


--
-- Data for Name: user_module_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_module_access (id, user_id, module_key, granted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, role, is_active, phone, last_login_at, deleted_at, theme, language, timezone, birthday, hire_date) FROM stdin;
15	Admin User	admin@tecc.ph	\N	$2y$12$B4fFLCXa4dsPCReKw1GImOPoQFnawLHIiJEiE6TMTGIxiYPzNjjt6	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	admin	t	\N	\N	\N	light	en	Asia/Manila	\N	\N
16	Maria Supervisor	supervisor@tecc.ph	\N	$2y$12$2eHIZb.RJSy21krOIH2hQ.1xps.EFljZv1sgsmdbHg5uvNPgA9fKe	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	supervisor	t	\N	\N	\N	light	en	Asia/Manila	\N	\N
17	Juan Agent	agent@tecc.ph	\N	$2y$12$yWy.a7c04MhDaPCgsoS8R.txWhOzS424hzqrWki3wZC3.jL0nqLCa	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	agent	t	\N	\N	\N	light	en	Asia/Manila	\N	\N
18	Pedro Warehouse	warehouse@tecc.ph	\N	$2y$12$xMZ9mkLyG8sTzlTv0AQDVOeO0vWjZYf9rfqXDBDOwRX4rytg5TSI2	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	warehouse	t	\N	\N	\N	light	en	Asia/Manila	\N	\N
19	Ana Finance	finance@tecc.ph	\N	$2y$12$TTlXn1bfYE5A8PjOZd1y1O4Nm3LUItJwhZvz4Xm3xSDgNt5k5e6hS	\N	2026-08-02 07:29:55	2026-08-02 07:29:55	finance	t	\N	\N	\N	light	en	Asia/Manila	\N	\N
20	Super Admin	admin@test.local	2026-08-02 07:33:18	$2y$12$hPuPhOpbUTHaeEyTOsXXe.ovVyWD7lyLP9EA8otcgmeVEM23pyKDO	\N	2026-08-02 07:33:18	2026-08-02 07:33:18	superadmin	t	\N	\N	\N	light	en	Asia/Manila	\N	\N
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouse_locations (id, warehouse_id, code, name, type, capacity, is_active, created_at, updated_at) FROM stdin;
1	2	A-01-01	Aisle A Rack 1 L1	shelf	500	t	2026-08-02 07:29:55	2026-08-02 07:29:55
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, name, code, address, contact_person, contact_phone, is_active, is_default, created_at, updated_at) FROM stdin;
1	Main Warehouse	MAIN	\N	\N	\N	t	t	2026-08-02 07:21:07	2026-08-02 07:21:07
2	Main Warehouse - Manila	WH-MAIN	123 Warehouse Rd, Port Area, Manila	Pedro Warehouse	09190001111	t	t	2026-08-02 07:29:55	2026-08-02 07:29:55
\.


--
-- Data for Name: waybill_tracking_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waybill_tracking_history (id, waybill_id, status, previous_status, reason, location, raw_data, tracked_at, created_at, updated_at, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: waybills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waybills (id, waybill_number, status, receiver_name, receiver_phone, receiver_address, city, state, barangay, street, postal_code, item_name, item_qty, amount, courier_provider, lead_id, uploaded_by, dispatched_at, delivered_at, returned_at, created_at, updated_at, deleted_at, creator_code, sign_for_pictures, payment_method, shipping_cost, cod_amount, settlement_weight, item_value, valuation_fee, express_type, rts_reason, remarks, sender_name, sender_phone, sender_province, sender_city, submitted_at, signed_at, upload_id, latitude, longitude, last_location_at, last_location_description) FROM stdin;
1	WB-2026-00123	dispatched	Maria Santos	09175551234	123 Mabini St, Quezon City	Quezon City	Metro Manila	\N	\N	\N	Smartphone X Pro 128GB	1	8500.00	JNT	\N	\N	2026-08-02 01:29:56	\N	\N	2026-08-02 07:29:56	2026-08-02 07:29:56	\N	JNT	f	COD	150.00	8500.00	\N	8500.00	\N	STANDARD	\N	\N	TECC Official Store	09190001234	Metro Manila	Manila	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_logs (id, provider, event_type, payload, signature, signature_valid, processing_status, processing_error, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 1, false);


--
-- Name: address_correction_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.address_correction_history_id_seq', 1, false);


--
-- Name: address_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.address_mappings_id_seq', 1, false);


--
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.addresses_id_seq', 1, false);


--
-- Name: agent_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_badges_id_seq', 1, false);


--
-- Name: agent_commissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_commissions_id_seq', 1, false);


--
-- Name: agent_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_flags_id_seq', 1, false);


--
-- Name: agent_milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_milestones_id_seq', 1, false);


--
-- Name: agent_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_profiles_id_seq', 2, true);


--
-- Name: agent_streaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_streaks_id_seq', 1, false);


--
-- Name: approval_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.approval_rules_id_seq', 1, false);


--
-- Name: approval_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.approval_settings_id_seq', 6, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: auto_merge_suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_merge_suggestions_id_seq', 1, false);


--
-- Name: badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.badges_id_seq', 1, false);


--
-- Name: batch_item_error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_item_error_logs_id_seq', 1, false);


--
-- Name: batch_scan_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_scan_items_id_seq', 1, false);


--
-- Name: batch_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_sessions_id_seq', 1, false);


--
-- Name: batch_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_status_history_id_seq', 1, false);


--
-- Name: broadcast_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.broadcast_campaigns_id_seq', 1, false);


--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.broadcast_recipients_id_seq', 1, false);


--
-- Name: broadcast_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.broadcast_variants_id_seq', 1, false);


--
-- Name: capex_asset_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.capex_asset_assignments_id_seq', 1, false);


--
-- Name: capex_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.capex_assets_id_seq', 1, false);


--
-- Name: capex_depreciation_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.capex_depreciation_schedule_id_seq', 1, false);


--
-- Name: cart_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cart_templates_id_seq', 1, false);


--
-- Name: claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.claims_id_seq', 1, false);


--
-- Name: cod_settlements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cod_settlements_id_seq', 1, true);


--
-- Name: cogs_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cogs_entries_id_seq', 1, false);


--
-- Name: commission_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commission_rules_id_seq', 1, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


--
-- Name: conversation_assignment_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_assignment_histories_id_seq', 1, false);


--
-- Name: conversation_exports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_exports_id_seq', 1, false);


--
-- Name: conversation_status_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_status_histories_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, true);


--
-- Name: courier_api_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_api_logs_id_seq', 1, false);


--
-- Name: courier_csv_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_csv_templates_id_seq', 1, false);


--
-- Name: courier_csv_validation_error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_csv_validation_error_logs_id_seq', 1, false);


--
-- Name: courier_export_batch_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_export_batch_shares_id_seq', 1, false);


--
-- Name: courier_export_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_export_batches_id_seq', 1, false);


--
-- Name: courier_export_rows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_export_rows_id_seq', 1, false);


--
-- Name: courier_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_providers_id_seq', 2, true);


--
-- Name: courier_sync_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courier_sync_logs_id_seq', 1, false);


--
-- Name: customer_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_addresses_id_seq', 1, false);


--
-- Name: customer_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_audit_logs_id_seq', 1, false);


--
-- Name: customer_identities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_identities_id_seq', 1, true);


--
-- Name: customer_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_notes_id_seq', 1, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 5, true);


--
-- Name: dashboard_widget_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dashboard_widget_configs_id_seq', 1, false);


--
-- Name: dead_stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dead_stocks_id_seq', 1, false);


--
-- Name: delivery_proofs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_proofs_id_seq', 1, false);


--
-- Name: distribution_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.distribution_queues_id_seq', 1, false);


--
-- Name: distribution_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.distribution_rules_id_seq', 1, false);


--
-- Name: duplicate_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_audit_logs_id_seq', 1, false);


--
-- Name: duplicate_detection_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_detection_rules_id_seq', 1, false);


--
-- Name: duplicate_families_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_families_id_seq', 1, false);


--
-- Name: duplicate_family_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_family_members_id_seq', 1, false);


--
-- Name: duplicate_ml_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_ml_models_id_seq', 1, false);


--
-- Name: duplicate_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_notifications_id_seq', 1, false);


--
-- Name: duplicate_review_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.duplicate_review_items_id_seq', 1, false);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 1, false);


--
-- Name: facebook_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.facebook_accounts_id_seq', 1, false);


--
-- Name: facebook_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.facebook_pages_id_seq', 2, true);


--
-- Name: facebook_webhook_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.facebook_webhook_events_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: finance_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.finance_settings_id_seq', 6, true);


--
-- Name: financial_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.financial_transactions_id_seq', 1, true);


--
-- Name: fraud_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fraud_flags_id_seq', 1, false);


--
-- Name: import_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.import_chunks_id_seq', 1, false);


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_movements_id_seq', 1, false);


--
-- Name: invoice_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_lines_id_seq', 1, true);


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_payments_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, true);


--
-- Name: lead_cycles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_cycles_id_seq', 1, true);


--
-- Name: lead_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_logs_id_seq', 1, false);


--
-- Name: lead_pool_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_pool_audit_id_seq', 1, false);


--
-- Name: lead_recycling_pool_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_recycling_pool_id_seq', 1, false);


--
-- Name: lead_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lead_snapshots_id_seq', 1, false);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leads_id_seq', 2, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 2, true);


--
-- Name: meta_data_deletion_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meta_data_deletion_requests_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 160, true);


--
-- Name: milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.milestones_id_seq', 1, false);


--
-- Name: order_remarks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_remarks_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, true);


--
-- Name: page_assignment_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.page_assignment_rules_id_seq', 1, false);


--
-- Name: page_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.page_favorites_id_seq', 1, false);


--
-- Name: page_status_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.page_status_labels_id_seq', 1, false);


--
-- Name: page_status_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.page_status_rules_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: product_stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_stocks_id_seq', 2, true);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 1, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 2, true);


--
-- Name: purchase_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_order_items_id_seq', 1, true);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, true);


--
-- Name: purchase_request_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_request_items_id_seq', 1, true);


--
-- Name: purchase_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_requests_id_seq', 1, true);


--
-- Name: qa_decision_reasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.qa_decision_reasons_id_seq', 1, false);


--
-- Name: qa_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.qa_reviews_id_seq', 1, false);


--
-- Name: qbo_account_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.qbo_account_mappings_id_seq', 1, false);


--
-- Name: qbo_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.qbo_connections_id_seq', 1, false);


--
-- Name: qbo_sync_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.qbo_sync_queue_id_seq', 1, false);


--
-- Name: receiving_report_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receiving_report_items_id_seq', 1, false);


--
-- Name: receiving_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receiving_reports_id_seq', 1, false);


--
-- Name: recycling_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recycling_rules_id_seq', 6, true);


--
-- Name: remark_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.remark_templates_id_seq', 1, false);


--
-- Name: reply_template_ab_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_template_ab_tests_id_seq', 1, false);


--
-- Name: reply_template_ab_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_template_ab_variants_id_seq', 1, false);


--
-- Name: reply_template_favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_template_favorites_id_seq', 1, false);


--
-- Name: reply_template_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_template_shares_id_seq', 1, false);


--
-- Name: reply_template_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_template_usage_id_seq', 1, false);


--
-- Name: reply_template_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_template_versions_id_seq', 1, false);


--
-- Name: reply_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_templates_id_seq', 1, false);


--
-- Name: return_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.return_receipts_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 1, false);


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scheduled_messages_id_seq', 1, false);


--
-- Name: scheduled_sales_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scheduled_sales_reports_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: shipping_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shipping_rates_id_seq', 1, false);


--
-- Name: shop_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_order_items_id_seq', 1, false);


--
-- Name: shop_reply_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shop_reply_templates_id_seq', 3, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 4, true);


--
-- Name: sms_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_campaigns_id_seq', 1, true);


--
-- Name: sms_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_logs_id_seq', 1, true);


--
-- Name: sms_sequence_enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_sequence_enrollments_id_seq', 1, false);


--
-- Name: sms_sequence_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_sequence_steps_id_seq', 1, false);


--
-- Name: sms_sequences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_sequences_id_seq', 1, false);


--
-- Name: sms_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_templates_id_seq', 1, false);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_adjustments_id_seq', 1, true);


--
-- Name: stock_audit_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_audit_items_id_seq', 1, false);


--
-- Name: stock_audit_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_audit_sessions_id_seq', 1, false);


--
-- Name: stock_cost_lots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_cost_lots_id_seq', 1, false);


--
-- Name: stock_reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_reservations_id_seq', 1, false);


--
-- Name: supplier_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_invoices_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, true);


--
-- Name: supplies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplies_id_seq', 1, true);


--
-- Name: supply_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supply_movements_id_seq', 1, false);


--
-- Name: supply_stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supply_stocks_id_seq', 1, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: third_parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.third_parties_id_seq', 1, true);


--
-- Name: ticket_canned_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ticket_canned_responses_id_seq', 1, false);


--
-- Name: ticket_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ticket_categories_id_seq', 7, true);


--
-- Name: ticket_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ticket_comments_id_seq', 1, false);


--
-- Name: ticket_priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ticket_priorities_id_seq', 4, true);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, false);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.units_of_measure_id_seq', 9, true);


--
-- Name: unknown_waybill_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.unknown_waybill_scans_id_seq', 1, false);


--
-- Name: uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.uploads_id_seq', 1, false);


--
-- Name: user_module_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_module_access_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 20, true);


--
-- Name: warehouse_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouse_locations_id_seq', 1, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 2, true);


--
-- Name: waybill_tracking_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.waybill_tracking_history_id_seq', 1, false);


--
-- Name: waybills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.waybills_id_seq', 1, true);


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhook_logs_id_seq', 1, false);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: address_correction_history address_correction_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_correction_history
    ADD CONSTRAINT address_correction_history_pkey PRIMARY KEY (id);


--
-- Name: address_mappings address_mapping_unique_location; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_mappings
    ADD CONSTRAINT address_mapping_unique_location UNIQUE (country, province, city_municipality, barangay);


--
-- Name: address_mappings address_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_mappings
    ADD CONSTRAINT address_mappings_pkey PRIMARY KEY (id);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: agent_badges agent_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_badges
    ADD CONSTRAINT agent_badges_pkey PRIMARY KEY (id);


--
-- Name: agent_badges agent_badges_user_id_badge_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_badges
    ADD CONSTRAINT agent_badges_user_id_badge_id_unique UNIQUE (user_id, badge_id);


--
-- Name: agent_commissions agent_commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_pkey PRIMARY KEY (id);


--
-- Name: agent_flags agent_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flags
    ADD CONSTRAINT agent_flags_pkey PRIMARY KEY (id);


--
-- Name: agent_milestones agent_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_milestones
    ADD CONSTRAINT agent_milestones_pkey PRIMARY KEY (id);


--
-- Name: agent_milestones agent_milestones_user_id_milestone_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_milestones
    ADD CONSTRAINT agent_milestones_user_id_milestone_id_unique UNIQUE (user_id, milestone_id);


--
-- Name: agent_profiles agent_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_profiles agent_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: agent_streaks agent_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_streaks
    ADD CONSTRAINT agent_streaks_pkey PRIMARY KEY (id);


--
-- Name: agent_streaks agent_streaks_user_id_streak_type_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_streaks
    ADD CONSTRAINT agent_streaks_user_id_streak_type_unique UNIQUE (user_id, streak_type);


--
-- Name: agent_workloads agent_workloads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_workloads
    ADD CONSTRAINT agent_workloads_pkey PRIMARY KEY (agent_id);


--
-- Name: approval_rules approval_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_rules
    ADD CONSTRAINT approval_rules_pkey PRIMARY KEY (id);


--
-- Name: approval_settings approval_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_settings
    ADD CONSTRAINT approval_settings_key_unique UNIQUE (key);


--
-- Name: approval_settings approval_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_settings
    ADD CONSTRAINT approval_settings_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auto_merge_suggestions auto_merge_pair_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_merge_suggestions
    ADD CONSTRAINT auto_merge_pair_unique UNIQUE (target_customer_id, source_customer_id);


--
-- Name: auto_merge_suggestions auto_merge_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_merge_suggestions
    ADD CONSTRAINT auto_merge_suggestions_pkey PRIMARY KEY (id);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: badges badges_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_slug_unique UNIQUE (slug);


--
-- Name: batch_item_error_logs batch_item_error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_item_error_logs
    ADD CONSTRAINT batch_item_error_logs_pkey PRIMARY KEY (id);


--
-- Name: batch_scan_items batch_scan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_scan_items
    ADD CONSTRAINT batch_scan_items_pkey PRIMARY KEY (id);


--
-- Name: batch_sessions batch_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_sessions
    ADD CONSTRAINT batch_sessions_pkey PRIMARY KEY (id);


--
-- Name: batch_status_history batch_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_status_history
    ADD CONSTRAINT batch_status_history_pkey PRIMARY KEY (id);


--
-- Name: broadcast_campaigns broadcast_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_campaigns
    ADD CONSTRAINT broadcast_campaigns_pkey PRIMARY KEY (id);


--
-- Name: broadcast_recipients broadcast_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_pkey PRIMARY KEY (id);


--
-- Name: broadcast_variants broadcast_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_variants
    ADD CONSTRAINT broadcast_variants_pkey PRIMARY KEY (id);


--
-- Name: capex_asset_assignments capex_asset_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_asset_assignments
    ADD CONSTRAINT capex_asset_assignments_pkey PRIMARY KEY (id);


--
-- Name: capex_assets capex_assets_asset_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets
    ADD CONSTRAINT capex_assets_asset_code_unique UNIQUE (asset_code);


--
-- Name: capex_assets capex_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets
    ADD CONSTRAINT capex_assets_pkey PRIMARY KEY (id);


--
-- Name: capex_depreciation_schedule capex_depreciation_schedule_capex_asset_id_year_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_depreciation_schedule
    ADD CONSTRAINT capex_depreciation_schedule_capex_asset_id_year_unique UNIQUE (capex_asset_id, year);


--
-- Name: capex_depreciation_schedule capex_depreciation_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_depreciation_schedule
    ADD CONSTRAINT capex_depreciation_schedule_pkey PRIMARY KEY (id);


--
-- Name: cart_templates cart_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_templates
    ADD CONSTRAINT cart_templates_pkey PRIMARY KEY (id);


--
-- Name: claims claims_claim_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_claim_number_unique UNIQUE (claim_number);


--
-- Name: claims claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_pkey PRIMARY KEY (id);


--
-- Name: cod_settlements cod_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cod_settlements
    ADD CONSTRAINT cod_settlements_pkey PRIMARY KEY (id);


--
-- Name: cogs_entries cogs_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cogs_entries
    ADD CONSTRAINT cogs_entries_pkey PRIMARY KEY (id);


--
-- Name: commission_rules commission_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rules
    ADD CONSTRAINT commission_rules_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversation_assignment_histories conversation_assignment_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_assignment_histories
    ADD CONSTRAINT conversation_assignment_histories_pkey PRIMARY KEY (id);


--
-- Name: conversation_exports conversation_exports_export_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_exports
    ADD CONSTRAINT conversation_exports_export_number_unique UNIQUE (export_number);


--
-- Name: conversation_exports conversation_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_exports
    ADD CONSTRAINT conversation_exports_pkey PRIMARY KEY (id);


--
-- Name: conversation_status_histories conversation_status_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_status_histories
    ADD CONSTRAINT conversation_status_histories_pkey PRIMARY KEY (id);


--
-- Name: conversation_tag conversation_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_tag
    ADD CONSTRAINT conversation_tag_pkey PRIMARY KEY (conversation_id, tag_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_thread_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_thread_key_unique UNIQUE (thread_key);


--
-- Name: courier_api_logs courier_api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_api_logs
    ADD CONSTRAINT courier_api_logs_pkey PRIMARY KEY (id);


--
-- Name: courier_csv_templates courier_csv_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_templates
    ADD CONSTRAINT courier_csv_templates_pkey PRIMARY KEY (id);


--
-- Name: courier_csv_validation_error_logs courier_csv_validation_error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_validation_error_logs
    ADD CONSTRAINT courier_csv_validation_error_logs_pkey PRIMARY KEY (id);


--
-- Name: courier_export_batch_shares courier_export_batch_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batch_shares
    ADD CONSTRAINT courier_export_batch_shares_pkey PRIMARY KEY (id);


--
-- Name: courier_export_batch_shares courier_export_batch_shares_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batch_shares
    ADD CONSTRAINT courier_export_batch_shares_token_unique UNIQUE (token);


--
-- Name: courier_export_batches courier_export_batches_batch_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batches
    ADD CONSTRAINT courier_export_batches_batch_number_unique UNIQUE (batch_number);


--
-- Name: courier_export_batches courier_export_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batches
    ADD CONSTRAINT courier_export_batches_pkey PRIMARY KEY (id);


--
-- Name: courier_export_rows courier_export_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_rows
    ADD CONSTRAINT courier_export_rows_pkey PRIMARY KEY (id);


--
-- Name: courier_providers courier_providers_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_providers
    ADD CONSTRAINT courier_providers_code_unique UNIQUE (code);


--
-- Name: courier_providers courier_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_providers
    ADD CONSTRAINT courier_providers_pkey PRIMARY KEY (id);


--
-- Name: courier_sync_logs courier_sync_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_sync_logs
    ADD CONSTRAINT courier_sync_logs_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (code);


--
-- Name: customer_addresses customer_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT customer_addresses_pkey PRIMARY KEY (id);


--
-- Name: customer_audit_logs customer_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_audit_logs
    ADD CONSTRAINT customer_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: customer_identities customer_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_identities
    ADD CONSTRAINT customer_identities_pkey PRIMARY KEY (id);


--
-- Name: customer_identities customer_identities_provider_user_page_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_identities
    ADD CONSTRAINT customer_identities_provider_user_page_unique UNIQUE (provider, provider_user_id, facebook_page_id);


--
-- Name: customer_notes customer_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_pkey PRIMARY KEY (id);


--
-- Name: customers customers_normalized_phone_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_normalized_phone_unique UNIQUE (normalized_phone);


--
-- Name: customers customers_phone_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_phone_unique UNIQUE (phone);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: dashboard_widget_configs dashboard_widget_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widget_configs
    ADD CONSTRAINT dashboard_widget_configs_pkey PRIMARY KEY (id);


--
-- Name: dashboard_widget_configs dashboard_widget_configs_user_id_dashboard_widget_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widget_configs
    ADD CONSTRAINT dashboard_widget_configs_user_id_dashboard_widget_key_unique UNIQUE (user_id, dashboard, widget_key);


--
-- Name: dead_stocks dead_stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_stocks
    ADD CONSTRAINT dead_stocks_pkey PRIMARY KEY (id);


--
-- Name: delivery_proofs delivery_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_proofs
    ADD CONSTRAINT delivery_proofs_pkey PRIMARY KEY (id);


--
-- Name: distribution_queues distribution_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_queues
    ADD CONSTRAINT distribution_queues_pkey PRIMARY KEY (id);


--
-- Name: distribution_rules distribution_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_rules
    ADD CONSTRAINT distribution_rules_pkey PRIMARY KEY (id);


--
-- Name: duplicate_audit_logs duplicate_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_audit_logs
    ADD CONSTRAINT duplicate_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: duplicate_detection_rules duplicate_detection_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_detection_rules
    ADD CONSTRAINT duplicate_detection_rules_pkey PRIMARY KEY (id);


--
-- Name: duplicate_families duplicate_families_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_families
    ADD CONSTRAINT duplicate_families_pkey PRIMARY KEY (id);


--
-- Name: duplicate_family_members duplicate_family_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_family_members
    ADD CONSTRAINT duplicate_family_members_pkey PRIMARY KEY (id);


--
-- Name: duplicate_ml_models duplicate_ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_ml_models
    ADD CONSTRAINT duplicate_ml_models_pkey PRIMARY KEY (id);


--
-- Name: duplicate_notifications duplicate_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_notifications
    ADD CONSTRAINT duplicate_notifications_pkey PRIMARY KEY (id);


--
-- Name: duplicate_review_items duplicate_review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_review_items
    ADD CONSTRAINT duplicate_review_items_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_from_currency_to_currency_rate_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_from_currency_to_currency_rate_date_unique UNIQUE (from_currency, to_currency, rate_date);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: facebook_accounts facebook_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_accounts
    ADD CONSTRAINT facebook_accounts_pkey PRIMARY KEY (id);


--
-- Name: facebook_accounts facebook_accounts_user_id_facebook_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_accounts
    ADD CONSTRAINT facebook_accounts_user_id_facebook_user_id_unique UNIQUE (user_id, facebook_user_id);


--
-- Name: facebook_pages facebook_pages_page_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_pages
    ADD CONSTRAINT facebook_pages_page_id_unique UNIQUE (page_id);


--
-- Name: facebook_pages facebook_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_pages
    ADD CONSTRAINT facebook_pages_pkey PRIMARY KEY (id);


--
-- Name: facebook_webhook_events facebook_webhook_events_event_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_webhook_events
    ADD CONSTRAINT facebook_webhook_events_event_id_unique UNIQUE (event_id);


--
-- Name: facebook_webhook_events facebook_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_webhook_events
    ADD CONSTRAINT facebook_webhook_events_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: finance_settings finance_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_settings
    ADD CONSTRAINT finance_settings_key_unique UNIQUE (key);


--
-- Name: finance_settings finance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_settings
    ADD CONSTRAINT finance_settings_pkey PRIMARY KEY (id);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: fraud_flags fraud_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fraud_flags
    ADD CONSTRAINT fraud_flags_pkey PRIMARY KEY (id);


--
-- Name: import_chunks import_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_chunks
    ADD CONSTRAINT import_chunks_pkey PRIMARY KEY (id);


--
-- Name: import_chunks import_chunks_upload_id_chunk_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_chunks
    ADD CONSTRAINT import_chunks_upload_id_chunk_number_unique UNIQUE (upload_id, chunk_number);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: invoice_lines invoice_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_ref_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_ref_unique UNIQUE (ref);


--
-- Name: lead_cycles lead_cycles_lead_id_cycle_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_cycles
    ADD CONSTRAINT lead_cycles_lead_id_cycle_number_unique UNIQUE (lead_id, cycle_number);


--
-- Name: lead_cycles lead_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_cycles
    ADD CONSTRAINT lead_cycles_pkey PRIMARY KEY (id);


--
-- Name: lead_logs lead_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_logs
    ADD CONSTRAINT lead_logs_pkey PRIMARY KEY (id);


--
-- Name: lead_pool_audit lead_pool_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_pool_audit
    ADD CONSTRAINT lead_pool_audit_pkey PRIMARY KEY (id);


--
-- Name: lead_recycling_pool lead_recycling_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_recycling_pool
    ADD CONSTRAINT lead_recycling_pool_pkey PRIMARY KEY (id);


--
-- Name: lead_snapshots lead_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_snapshots
    ADD CONSTRAINT lead_snapshots_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_external_message_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_external_message_id_unique UNIQUE (external_message_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: meta_data_deletion_requests meta_data_deletion_requests_confirmation_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_data_deletion_requests
    ADD CONSTRAINT meta_data_deletion_requests_confirmation_code_unique UNIQUE (confirmation_code);


--
-- Name: meta_data_deletion_requests meta_data_deletion_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_data_deletion_requests
    ADD CONSTRAINT meta_data_deletion_requests_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_slug_unique UNIQUE (slug);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_remarks order_remarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks
    ADD CONSTRAINT order_remarks_pkey PRIMARY KEY (id);


--
-- Name: order_tag order_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tag
    ADD CONSTRAINT order_tag_pkey PRIMARY KEY (order_id, tag_id);


--
-- Name: orders orders_order_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_unique UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: page_assignment_rules page_assignment_rules_facebook_page_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_assignment_rules
    ADD CONSTRAINT page_assignment_rules_facebook_page_id_user_id_unique UNIQUE (facebook_page_id, user_id);


--
-- Name: page_assignment_rules page_assignment_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_assignment_rules
    ADD CONSTRAINT page_assignment_rules_pkey PRIMARY KEY (id);


--
-- Name: page_favorites page_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_favorites
    ADD CONSTRAINT page_favorites_pkey PRIMARY KEY (id);


--
-- Name: page_favorites page_favorites_user_id_facebook_page_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_favorites
    ADD CONSTRAINT page_favorites_user_id_facebook_page_id_unique UNIQUE (user_id, facebook_page_id);


--
-- Name: page_status_labels page_status_labels_facebook_page_id_status_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_labels
    ADD CONSTRAINT page_status_labels_facebook_page_id_status_unique UNIQUE (facebook_page_id, status);


--
-- Name: page_status_labels page_status_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_labels
    ADD CONSTRAINT page_status_labels_pkey PRIMARY KEY (id);


--
-- Name: page_status_rules page_status_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_rules
    ADD CONSTRAINT page_status_rules_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: permissions permissions_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_key_unique UNIQUE (key);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: product_stocks product_stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_pkey PRIMARY KEY (id);


--
-- Name: product_stocks product_stocks_product_variant_warehouse_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_product_variant_warehouse_unique UNIQUE (product_id, variant_id, warehouse_id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_sku_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_sku_unique UNIQUE (sku);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_unique UNIQUE (sku);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_po_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_po_number_unique UNIQUE (po_number);


--
-- Name: purchase_request_items purchase_request_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pr_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pr_number_unique UNIQUE (pr_number);


--
-- Name: qa_decision_reasons qa_decision_reasons_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_decision_reasons
    ADD CONSTRAINT qa_decision_reasons_code_unique UNIQUE (code);


--
-- Name: qa_decision_reasons qa_decision_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_decision_reasons
    ADD CONSTRAINT qa_decision_reasons_pkey PRIMARY KEY (id);


--
-- Name: qa_reviews qa_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_reviews
    ADD CONSTRAINT qa_reviews_pkey PRIMARY KEY (id);


--
-- Name: qbo_account_mappings qbo_account_mappings_mapping_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_account_mappings
    ADD CONSTRAINT qbo_account_mappings_mapping_key_unique UNIQUE (mapping_key);


--
-- Name: qbo_account_mappings qbo_account_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_account_mappings
    ADD CONSTRAINT qbo_account_mappings_pkey PRIMARY KEY (id);


--
-- Name: qbo_connections qbo_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_connections
    ADD CONSTRAINT qbo_connections_pkey PRIMARY KEY (id);


--
-- Name: qbo_sync_queue qbo_sync_queue_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_sync_queue
    ADD CONSTRAINT qbo_sync_queue_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: qbo_sync_queue qbo_sync_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_sync_queue
    ADD CONSTRAINT qbo_sync_queue_pkey PRIMARY KEY (id);


--
-- Name: receiving_report_items receiving_report_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_report_items
    ADD CONSTRAINT receiving_report_items_pkey PRIMARY KEY (id);


--
-- Name: receiving_reports receiving_reports_grn_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports
    ADD CONSTRAINT receiving_reports_grn_number_unique UNIQUE (grn_number);


--
-- Name: receiving_reports receiving_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports
    ADD CONSTRAINT receiving_reports_pkey PRIMARY KEY (id);


--
-- Name: recycling_rules recycling_rules_outcome_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recycling_rules
    ADD CONSTRAINT recycling_rules_outcome_unique UNIQUE (outcome);


--
-- Name: recycling_rules recycling_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recycling_rules
    ADD CONSTRAINT recycling_rules_pkey PRIMARY KEY (id);


--
-- Name: remark_templates remark_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remark_templates
    ADD CONSTRAINT remark_templates_pkey PRIMARY KEY (id);


--
-- Name: reply_template_ab_tests reply_template_ab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_tests
    ADD CONSTRAINT reply_template_ab_tests_pkey PRIMARY KEY (id);


--
-- Name: reply_template_ab_variants reply_template_ab_variants_ab_test_id_variant_label_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_variants
    ADD CONSTRAINT reply_template_ab_variants_ab_test_id_variant_label_unique UNIQUE (ab_test_id, variant_label);


--
-- Name: reply_template_ab_variants reply_template_ab_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_variants
    ADD CONSTRAINT reply_template_ab_variants_pkey PRIMARY KEY (id);


--
-- Name: reply_template_favorites reply_template_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_favorites
    ADD CONSTRAINT reply_template_favorites_pkey PRIMARY KEY (id);


--
-- Name: reply_template_favorites reply_template_favorites_user_id_reply_template_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_favorites
    ADD CONSTRAINT reply_template_favorites_user_id_reply_template_id_unique UNIQUE (user_id, reply_template_id);


--
-- Name: reply_template_shares reply_template_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_shares
    ADD CONSTRAINT reply_template_shares_pkey PRIMARY KEY (id);


--
-- Name: reply_template_shares reply_template_shares_reply_template_id_facebook_page_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_shares
    ADD CONSTRAINT reply_template_shares_reply_template_id_facebook_page_id_unique UNIQUE (reply_template_id, facebook_page_id);


--
-- Name: reply_template_usage reply_template_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_usage
    ADD CONSTRAINT reply_template_usage_pkey PRIMARY KEY (id);


--
-- Name: reply_template_versions reply_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_versions
    ADD CONSTRAINT reply_template_versions_pkey PRIMARY KEY (id);


--
-- Name: reply_templates reply_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_templates
    ADD CONSTRAINT reply_templates_pkey PRIMARY KEY (id);


--
-- Name: return_receipts return_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_receipts
    ADD CONSTRAINT return_receipts_pkey PRIMARY KEY (id);


--
-- Name: return_receipts return_receipts_waybill_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_receipts
    ADD CONSTRAINT return_receipts_waybill_id_unique UNIQUE (waybill_id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_permission_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_permission_id_unique UNIQUE (role, permission_id);


--
-- Name: scheduled_messages scheduled_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_pkey PRIMARY KEY (id);


--
-- Name: scheduled_sales_reports scheduled_sales_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_sales_reports
    ADD CONSTRAINT scheduled_sales_reports_pkey PRIMARY KEY (id);


--
-- Name: settings settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_key_unique UNIQUE (key);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: shipping_rates shipping_rates_courier_code_courier_zone_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_rates
    ADD CONSTRAINT shipping_rates_courier_code_courier_zone_unique UNIQUE (courier_code, courier_zone);


--
-- Name: shipping_rates shipping_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_rates
    ADD CONSTRAINT shipping_rates_pkey PRIMARY KEY (id);


--
-- Name: shop_order_items shop_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_pkey PRIMARY KEY (id);


--
-- Name: shop_reply_templates shop_reply_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_reply_templates
    ADD CONSTRAINT shop_reply_templates_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_key_unique UNIQUE (key);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: sms_campaigns sms_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_campaigns
    ADD CONSTRAINT sms_campaigns_pkey PRIMARY KEY (id);


--
-- Name: sms_logs sms_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_pkey PRIMARY KEY (id);


--
-- Name: sms_sequence_enrollments sms_sequence_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_enrollments
    ADD CONSTRAINT sms_sequence_enrollments_pkey PRIMARY KEY (id);


--
-- Name: sms_sequence_steps sms_sequence_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_steps
    ADD CONSTRAINT sms_sequence_steps_pkey PRIMARY KEY (id);


--
-- Name: sms_sequences sms_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequences
    ADD CONSTRAINT sms_sequences_pkey PRIMARY KEY (id);


--
-- Name: sms_templates sms_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_templates
    ADD CONSTRAINT sms_templates_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustments stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: stock_audit_items stock_audit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items
    ADD CONSTRAINT stock_audit_items_pkey PRIMARY KEY (id);


--
-- Name: stock_audit_sessions stock_audit_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_sessions
    ADD CONSTRAINT stock_audit_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_cost_lots stock_cost_lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_lots
    ADD CONSTRAINT stock_cost_lots_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: supplier_invoices supplier_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_pkey PRIMARY KEY (id);


--
-- Name: supplier_invoices supplier_invoices_ref_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_ref_unique UNIQUE (ref);


--
-- Name: suppliers suppliers_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_code_unique UNIQUE (code);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: supplies supplies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_pkey PRIMARY KEY (id);


--
-- Name: supplies supplies_sku_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_sku_unique UNIQUE (sku);


--
-- Name: supply_movements supply_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_pkey PRIMARY KEY (id);


--
-- Name: supply_stocks supply_stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_stocks
    ADD CONSTRAINT supply_stocks_pkey PRIMARY KEY (id);


--
-- Name: supply_stocks supply_stocks_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_stocks
    ADD CONSTRAINT supply_stocks_uniq UNIQUE (supply_id, warehouse_id, location_id);


--
-- Name: system_settings system_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_key_unique UNIQUE (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_unique UNIQUE (slug);


--
-- Name: third_parties third_parties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.third_parties
    ADD CONSTRAINT third_parties_pkey PRIMARY KEY (id);


--
-- Name: third_parties third_parties_ref_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.third_parties
    ADD CONSTRAINT third_parties_ref_unique UNIQUE (ref);


--
-- Name: ticket_canned_responses ticket_canned_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_canned_responses
    ADD CONSTRAINT ticket_canned_responses_pkey PRIMARY KEY (id);


--
-- Name: ticket_categories ticket_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_categories
    ADD CONSTRAINT ticket_categories_pkey PRIMARY KEY (id);


--
-- Name: ticket_categories ticket_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_categories
    ADD CONSTRAINT ticket_categories_slug_unique UNIQUE (slug);


--
-- Name: ticket_comments ticket_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_pkey PRIMARY KEY (id);


--
-- Name: ticket_priorities ticket_priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_priorities
    ADD CONSTRAINT ticket_priorities_pkey PRIMARY KEY (id);


--
-- Name: ticket_priorities ticket_priorities_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_priorities
    ADD CONSTRAINT ticket_priorities_slug_unique UNIQUE (slug);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_ticket_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_ticket_number_unique UNIQUE (ticket_number);


--
-- Name: units_of_measure units_of_measure_abbreviation_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_abbreviation_unique UNIQUE (abbreviation);


--
-- Name: units_of_measure units_of_measure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_pkey PRIMARY KEY (id);


--
-- Name: unknown_waybill_scans unknown_waybill_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unknown_waybill_scans
    ADD CONSTRAINT unknown_waybill_scans_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: uploads uploads_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_uuid_unique UNIQUE (uuid);


--
-- Name: user_module_access user_module_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_module_access
    ADD CONSTRAINT user_module_access_pkey PRIMARY KEY (id);


--
-- Name: user_module_access user_module_access_user_id_module_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_module_access
    ADD CONSTRAINT user_module_access_user_id_module_key_unique UNIQUE (user_id, module_key);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_warehouse_id_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_warehouse_id_code_unique UNIQUE (warehouse_id, code);


--
-- Name: warehouses warehouses_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_code_unique UNIQUE (code);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: waybill_tracking_history waybill_tracking_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybill_tracking_history
    ADD CONSTRAINT waybill_tracking_history_pkey PRIMARY KEY (id);


--
-- Name: waybills waybills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_pkey PRIMARY KEY (id);


--
-- Name: waybills waybills_waybill_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_waybill_number_unique UNIQUE (waybill_number);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: activity_logs_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_logs_action_created_at_index ON public.activity_logs USING btree (action, created_at);


--
-- Name: activity_logs_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_logs_user_id_created_at_index ON public.activity_logs USING btree (user_id, created_at);


--
-- Name: address_mappings_courier_zone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX address_mappings_courier_zone_index ON public.address_mappings USING btree (courier_zone);


--
-- Name: address_mappings_province_city_municipality_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX address_mappings_province_city_municipality_index ON public.address_mappings USING btree (province, city_municipality);


--
-- Name: address_mappings_region_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX address_mappings_region_index ON public.address_mappings USING btree (region);


--
-- Name: addresses_third_party_id_is_default_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX addresses_third_party_id_is_default_index ON public.addresses USING btree (third_party_id, is_default);


--
-- Name: addresses_third_party_id_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX addresses_third_party_id_type_index ON public.addresses USING btree (third_party_id, type);


--
-- Name: agent_badges_awarded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_badges_awarded_at_index ON public.agent_badges USING btree (awarded_at);


--
-- Name: agent_commissions_agent_id_earned_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_agent_id_earned_at_index ON public.agent_commissions USING btree (agent_id, earned_at);


--
-- Name: agent_commissions_agent_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_agent_id_status_index ON public.agent_commissions USING btree (agent_id, status);


--
-- Name: agent_commissions_order_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_order_id_index ON public.agent_commissions USING btree (order_id);


--
-- Name: agent_commissions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_status_index ON public.agent_commissions USING btree (status);


--
-- Name: agent_flags_agent_id_is_resolved_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_flags_agent_id_is_resolved_index ON public.agent_flags USING btree (agent_id, is_resolved);


--
-- Name: agent_flags_flag_type_is_resolved_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_flags_flag_type_is_resolved_index ON public.agent_flags USING btree (flag_type, is_resolved);


--
-- Name: agent_milestones_completed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_milestones_completed_at_index ON public.agent_milestones USING btree (completed_at);


--
-- Name: agent_profiles_is_available_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_profiles_is_available_index ON public.agent_profiles USING btree (is_available);


--
-- Name: agent_profiles_is_available_last_seen_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_profiles_is_available_last_seen_at_index ON public.agent_profiles USING btree (is_available, last_seen_at);


--
-- Name: approval_rules_module_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_rules_module_is_active_index ON public.approval_rules USING btree (module, is_active);


--
-- Name: audit_log_auditable_type_auditable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_auditable_type_auditable_id_index ON public.audit_log USING btree (auditable_type, auditable_id);


--
-- Name: audit_log_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_log_user_id_created_at_index ON public.audit_log USING btree (user_id, created_at);


--
-- Name: auto_merge_suggestions_source_customer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_merge_suggestions_source_customer_id_index ON public.auto_merge_suggestions USING btree (source_customer_id);


--
-- Name: auto_merge_suggestions_status_confidence_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_merge_suggestions_status_confidence_score_index ON public.auto_merge_suggestions USING btree (status, confidence_score);


--
-- Name: auto_merge_suggestions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_merge_suggestions_status_index ON public.auto_merge_suggestions USING btree (status);


--
-- Name: auto_merge_suggestions_target_customer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auto_merge_suggestions_target_customer_id_index ON public.auto_merge_suggestions USING btree (target_customer_id);


--
-- Name: badges_category_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX badges_category_is_active_index ON public.badges USING btree (category, is_active);


--
-- Name: batch_item_error_logs_courier_export_batch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batch_item_error_logs_courier_export_batch_id_index ON public.batch_item_error_logs USING btree (courier_export_batch_id);


--
-- Name: batch_item_error_logs_courier_export_row_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batch_item_error_logs_courier_export_row_id_index ON public.batch_item_error_logs USING btree (courier_export_row_id);


--
-- Name: batch_item_error_logs_order_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batch_item_error_logs_order_id_index ON public.batch_item_error_logs USING btree (order_id);


--
-- Name: batch_item_error_logs_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batch_item_error_logs_severity_index ON public.batch_item_error_logs USING btree (severity);


--
-- Name: batch_scan_items_batch_session_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batch_scan_items_batch_session_id_index ON public.batch_scan_items USING btree (batch_session_id);


--
-- Name: batch_sessions_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX batch_sessions_user_id_status_index ON public.batch_sessions USING btree (user_id, status);


--
-- Name: capex_asset_assignments_assigned_to_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX capex_asset_assignments_assigned_to_index ON public.capex_asset_assignments USING btree (assigned_to);


--
-- Name: capex_asset_assignments_capex_asset_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX capex_asset_assignments_capex_asset_id_index ON public.capex_asset_assignments USING btree (capex_asset_id);


--
-- Name: capex_assets_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX capex_assets_category_index ON public.capex_assets USING btree (category);


--
-- Name: capex_assets_depreciation_years_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX capex_assets_depreciation_years_index ON public.capex_assets USING btree (depreciation_years);


--
-- Name: capex_assets_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX capex_assets_status_index ON public.capex_assets USING btree (status);


--
-- Name: capex_depreciation_schedule_capex_asset_id_is_posted_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX capex_depreciation_schedule_capex_asset_id_is_posted_index ON public.capex_depreciation_schedule USING btree (capex_asset_id, is_posted);


--
-- Name: claims_filed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX claims_filed_at_index ON public.claims USING btree (filed_at);


--
-- Name: claims_filed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX claims_filed_by_index ON public.claims USING btree (filed_by);


--
-- Name: claims_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX claims_status_index ON public.claims USING btree (status);


--
-- Name: claims_status_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX claims_status_type_index ON public.claims USING btree (status, type);


--
-- Name: claims_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX claims_type_index ON public.claims USING btree (type);


--
-- Name: cod_settlements_courier_code_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cod_settlements_courier_code_status_index ON public.cod_settlements USING btree (courier_code, status);


--
-- Name: cod_settlements_period_start_period_end_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cod_settlements_period_start_period_end_index ON public.cod_settlements USING btree (period_start, period_end);


--
-- Name: cogs_entries_product_id_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cogs_entries_product_id_recorded_at_index ON public.cogs_entries USING btree (product_id, recorded_at);


--
-- Name: cogs_entries_waybill_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cogs_entries_waybill_id_index ON public.cogs_entries USING btree (waybill_id);


--
-- Name: commission_rules_product_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commission_rules_product_id_is_active_index ON public.commission_rules USING btree (product_id, is_active);


--
-- Name: contacts_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_email_index ON public.contacts USING btree (email);


--
-- Name: contacts_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_phone_index ON public.contacts USING btree (phone);


--
-- Name: contacts_third_party_id_is_primary_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contacts_third_party_id_is_primary_index ON public.contacts USING btree (third_party_id, is_primary);


--
-- Name: conversation_assignment_histories_conversation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversation_assignment_histories_conversation_id_index ON public.conversation_assignment_histories USING btree (conversation_id);


--
-- Name: conversations_assigned_agent_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_assigned_agent_id_status_index ON public.conversations USING btree (assigned_agent_id, status);


--
-- Name: conversations_facebook_page_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_facebook_page_id_status_index ON public.conversations USING btree (facebook_page_id, status);


--
-- Name: conversations_is_flagged_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_is_flagged_status_index ON public.conversations USING btree (is_flagged, status);


--
-- Name: conversations_merged_into_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_merged_into_id_index ON public.conversations USING btree (merged_into_id);


--
-- Name: conversations_priority_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_priority_status_index ON public.conversations USING btree (priority, status);


--
-- Name: conversations_reminder_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_reminder_at_index ON public.conversations USING btree (reminder_at);


--
-- Name: conversations_sentiment_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_sentiment_index ON public.conversations USING btree (sentiment);


--
-- Name: conversations_snoozed_until_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_snoozed_until_index ON public.conversations USING btree (snoozed_until);


--
-- Name: conversations_status_archived_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_status_archived_at_index ON public.conversations USING btree (status, archived_at);


--
-- Name: conversations_status_last_message_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversations_status_last_message_at_index ON public.conversations USING btree (status, last_message_at);


--
-- Name: cost_lots_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_lots_expiry_idx ON public.stock_cost_lots USING btree (expiry_date);


--
-- Name: cost_lots_fifo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_lots_fifo_idx ON public.stock_cost_lots USING btree (product_id, variant_id, warehouse_id, received_at);


--
-- Name: courier_api_logs_courier_code_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_api_logs_courier_code_action_created_at_index ON public.courier_api_logs USING btree (courier_code, action, created_at);


--
-- Name: courier_api_logs_is_success_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_api_logs_is_success_created_at_index ON public.courier_api_logs USING btree (is_success, created_at);


--
-- Name: courier_api_logs_waybill_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_api_logs_waybill_id_index ON public.courier_api_logs USING btree (waybill_id);


--
-- Name: courier_csv_templates_courier_code_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_csv_templates_courier_code_is_active_index ON public.courier_csv_templates USING btree (courier_code, is_active);


--
-- Name: courier_csv_validation_error_logs_courier_code_error_type_creat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_csv_validation_error_logs_courier_code_error_type_creat ON public.courier_csv_validation_error_logs USING btree (courier_code, error_type, created_at);


--
-- Name: courier_csv_validation_error_logs_courier_export_batch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_csv_validation_error_logs_courier_export_batch_id_index ON public.courier_csv_validation_error_logs USING btree (courier_export_batch_id);


--
-- Name: courier_csv_validation_error_logs_order_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_csv_validation_error_logs_order_id_created_at_index ON public.courier_csv_validation_error_logs USING btree (order_id, created_at);


--
-- Name: courier_export_batch_shares_courier_export_batch_id_expires_at_; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_batch_shares_courier_export_batch_id_expires_at_ ON public.courier_export_batch_shares USING btree (courier_export_batch_id, expires_at);


--
-- Name: courier_export_batches_archived_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_batches_archived_at_index ON public.courier_export_batches USING btree (archived_at);


--
-- Name: courier_export_batches_courier_code_region_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_batches_courier_code_region_index ON public.courier_export_batches USING btree (courier_code, region);


--
-- Name: courier_export_batches_courier_code_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_batches_courier_code_status_index ON public.courier_export_batches USING btree (courier_code, status);


--
-- Name: courier_export_batches_exported_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_batches_exported_at_index ON public.courier_export_batches USING btree (exported_at);


--
-- Name: courier_export_rows_courier_export_batch_id_row_number_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_rows_courier_export_batch_id_row_number_index ON public.courier_export_rows USING btree (courier_export_batch_id, row_number);


--
-- Name: courier_export_rows_order_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_rows_order_id_index ON public.courier_export_rows USING btree (order_id);


--
-- Name: courier_export_rows_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_export_rows_status_index ON public.courier_export_rows USING btree (status);


--
-- Name: courier_sync_logs_courier_code_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_sync_logs_courier_code_created_at_index ON public.courier_sync_logs USING btree (courier_code, created_at);


--
-- Name: courier_sync_logs_run_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX courier_sync_logs_run_id_index ON public.courier_sync_logs USING btree (run_id);


--
-- Name: customer_addresses_customer_id_city_municipality_province_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_addresses_customer_id_city_municipality_province_index ON public.customer_addresses USING btree (customer_id, city_municipality, province);


--
-- Name: customer_addresses_customer_id_is_default_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_addresses_customer_id_is_default_index ON public.customer_addresses USING btree (customer_id, is_default);


--
-- Name: customer_audit_logs_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_audit_logs_action_index ON public.customer_audit_logs USING btree (action);


--
-- Name: customer_audit_logs_customer_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_audit_logs_customer_id_created_at_index ON public.customer_audit_logs USING btree (customer_id, created_at);


--
-- Name: customer_identities_customer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_identities_customer_id_index ON public.customer_identities USING btree (customer_id);


--
-- Name: customer_identities_last_seen_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_identities_last_seen_at_index ON public.customer_identities USING btree (last_seen_at);


--
-- Name: customer_identities_phone_detected_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_identities_phone_detected_index ON public.customer_identities USING btree (phone_detected);


--
-- Name: customer_notes_customer_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_notes_customer_id_created_at_index ON public.customer_notes USING btree (customer_id, created_at);


--
-- Name: customer_notes_customer_id_note_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_notes_customer_id_note_type_index ON public.customer_notes USING btree (customer_id, note_type);


--
-- Name: customers_is_blacklisted_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_is_blacklisted_index ON public.customers USING btree (is_blacklisted);


--
-- Name: customers_normalized_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_normalized_phone_index ON public.customers USING btree (normalized_phone);


--
-- Name: customers_risk_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_risk_level_index ON public.customers USING btree (risk_level);


--
-- Name: customers_tags_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_tags_index ON public.customers USING btree (tags);


--
-- Name: dashboard_widget_configs_user_id_dashboard_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dashboard_widget_configs_user_id_dashboard_index ON public.dashboard_widget_configs USING btree (user_id, dashboard);


--
-- Name: dead_stocks_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dead_stocks_created_at_index ON public.dead_stocks USING btree (created_at);


--
-- Name: dead_stocks_item_type_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dead_stocks_item_type_product_id_index ON public.dead_stocks USING btree (item_type, product_id);


--
-- Name: dead_stocks_item_type_supply_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dead_stocks_item_type_supply_id_index ON public.dead_stocks USING btree (item_type, supply_id);


--
-- Name: delivery_proofs_source_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_proofs_source_index ON public.delivery_proofs USING btree (source);


--
-- Name: delivery_proofs_waybill_id_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_proofs_waybill_id_type_index ON public.delivery_proofs USING btree (waybill_id, type);


--
-- Name: distribution_queues_lead_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distribution_queues_lead_id_status_index ON public.distribution_queues USING btree (lead_id, status);


--
-- Name: distribution_queues_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distribution_queues_status_created_at_index ON public.distribution_queues USING btree (status, created_at);


--
-- Name: distribution_rules_is_active_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distribution_rules_is_active_priority_index ON public.distribution_rules USING btree (is_active, priority);


--
-- Name: duplicate_audit_logs_action_entity_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_audit_logs_action_entity_type_index ON public.duplicate_audit_logs USING btree (action, entity_type);


--
-- Name: duplicate_audit_logs_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_audit_logs_action_index ON public.duplicate_audit_logs USING btree (action);


--
-- Name: duplicate_audit_logs_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_audit_logs_created_at_index ON public.duplicate_audit_logs USING btree (created_at);


--
-- Name: duplicate_audit_logs_entity_type_entity_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_audit_logs_entity_type_entity_id_index ON public.duplicate_audit_logs USING btree (entity_type, entity_id);


--
-- Name: duplicate_audit_logs_entity_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_audit_logs_entity_type_index ON public.duplicate_audit_logs USING btree (entity_type);


--
-- Name: duplicate_audit_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_audit_logs_user_id_index ON public.duplicate_audit_logs USING btree (user_id);


--
-- Name: duplicate_detection_rules_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_detection_rules_priority_index ON public.duplicate_detection_rules USING btree (priority);


--
-- Name: duplicate_detection_rules_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_detection_rules_type_index ON public.duplicate_detection_rules USING btree (type);


--
-- Name: duplicate_detection_rules_type_is_enabled_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_detection_rules_type_is_enabled_index ON public.duplicate_detection_rules USING btree (type, is_enabled);


--
-- Name: duplicate_families_group_key_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_families_group_key_type_index ON public.duplicate_families USING btree (group_key, type);


--
-- Name: duplicate_families_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_families_status_index ON public.duplicate_families USING btree (status);


--
-- Name: duplicate_families_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_families_type_index ON public.duplicate_families USING btree (type);


--
-- Name: duplicate_families_type_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_families_type_status_index ON public.duplicate_families USING btree (type, status);


--
-- Name: duplicate_family_members_family_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_family_members_family_id_index ON public.duplicate_family_members USING btree (family_id);


--
-- Name: duplicate_family_members_family_id_is_anchor_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_family_members_family_id_is_anchor_index ON public.duplicate_family_members USING btree (family_id, is_anchor);


--
-- Name: duplicate_ml_models_name_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_ml_models_name_is_active_index ON public.duplicate_ml_models USING btree (name, is_active);


--
-- Name: duplicate_notifications_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_notifications_read_at_index ON public.duplicate_notifications USING btree (read_at);


--
-- Name: duplicate_notifications_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_notifications_type_index ON public.duplicate_notifications USING btree (type);


--
-- Name: duplicate_notifications_type_severity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_notifications_type_severity_index ON public.duplicate_notifications USING btree (type, severity);


--
-- Name: duplicate_notifications_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_notifications_user_id_index ON public.duplicate_notifications USING btree (user_id);


--
-- Name: duplicate_notifications_user_id_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_notifications_user_id_read_at_index ON public.duplicate_notifications USING btree (user_id, read_at);


--
-- Name: duplicate_review_items_severity_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_review_items_severity_status_index ON public.duplicate_review_items USING btree (severity, status);


--
-- Name: duplicate_review_items_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_review_items_status_index ON public.duplicate_review_items USING btree (status);


--
-- Name: duplicate_review_items_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_review_items_type_index ON public.duplicate_review_items USING btree (type);


--
-- Name: duplicate_review_items_type_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX duplicate_review_items_type_status_index ON public.duplicate_review_items USING btree (type, status);


--
-- Name: exchange_rates_rate_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exchange_rates_rate_date_index ON public.exchange_rates USING btree (rate_date);


--
-- Name: facebook_accounts_facebook_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_accounts_facebook_user_id_index ON public.facebook_accounts USING btree (facebook_user_id);


--
-- Name: facebook_accounts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_accounts_status_index ON public.facebook_accounts USING btree (status);


--
-- Name: facebook_pages_connected_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_pages_connected_status_index ON public.facebook_pages USING btree (connected_status);


--
-- Name: facebook_pages_last_sync_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_pages_last_sync_at_index ON public.facebook_pages USING btree (last_sync_at);


--
-- Name: facebook_pages_webhook_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_pages_webhook_status_index ON public.facebook_pages USING btree (webhook_status);


--
-- Name: facebook_webhook_events_event_type_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_webhook_events_event_type_created_at_index ON public.facebook_webhook_events USING btree (event_type, created_at);


--
-- Name: facebook_webhook_events_processed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_webhook_events_processed_at_index ON public.facebook_webhook_events USING btree (processed_at);


--
-- Name: facebook_webhook_events_sender_psid_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX facebook_webhook_events_sender_psid_index ON public.facebook_webhook_events USING btree (sender_psid);


--
-- Name: financial_transactions_reference_type_reference_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_transactions_reference_type_reference_id_index ON public.financial_transactions USING btree (reference_type, reference_id);


--
-- Name: financial_transactions_transaction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_transactions_transaction_date_index ON public.financial_transactions USING btree (transaction_date);


--
-- Name: financial_transactions_type_transaction_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_transactions_type_transaction_date_index ON public.financial_transactions USING btree (type, transaction_date);


--
-- Name: fraud_flags_agent_id_is_reviewed_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fraud_flags_agent_id_is_reviewed_index ON public.fraud_flags USING btree (agent_id, is_reviewed);


--
-- Name: fraud_flags_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fraud_flags_created_at_index ON public.fraud_flags USING btree (created_at);


--
-- Name: fraud_flags_flag_type_is_reviewed_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fraud_flags_flag_type_is_reviewed_index ON public.fraud_flags USING btree (flag_type, is_reviewed);


--
-- Name: idx_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_status_created ON public.uploads USING btree (status, created_at);


--
-- Name: import_chunks_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX import_chunks_status_index ON public.import_chunks USING btree (status);


--
-- Name: inventory_movements_product_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_product_id_created_at_index ON public.inventory_movements USING btree (product_id, created_at);


--
-- Name: inventory_movements_reference_type_reference_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_reference_type_reference_id_index ON public.inventory_movements USING btree (reference_type, reference_id);


--
-- Name: inventory_movements_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_type_index ON public.inventory_movements USING btree (type);


--
-- Name: invoice_lines_invoice_id_position_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoice_lines_invoice_id_position_index ON public.invoice_lines USING btree (invoice_id, "position");


--
-- Name: invoice_payments_invoice_id_payment_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoice_payments_invoice_id_payment_date_index ON public.invoice_payments USING btree (invoice_id, payment_date);


--
-- Name: invoices_date_invoice_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_date_invoice_index ON public.invoices USING btree (date_invoice);


--
-- Name: invoices_status_date_due_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_status_date_due_index ON public.invoices USING btree (status, date_due);


--
-- Name: invoices_third_party_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_third_party_id_status_index ON public.invoices USING btree (third_party_id, status);


--
-- Name: invoices_type_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_type_status_index ON public.invoices USING btree (type, status);


--
-- Name: lead_cycles_assigned_agent_id_opened_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_cycles_assigned_agent_id_opened_at_index ON public.lead_cycles USING btree (assigned_agent_id, opened_at);


--
-- Name: lead_cycles_assigned_agent_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_cycles_assigned_agent_id_status_index ON public.lead_cycles USING btree (assigned_agent_id, status);


--
-- Name: lead_cycles_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_cycles_status_index ON public.lead_cycles USING btree (status);


--
-- Name: lead_logs_lead_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_logs_lead_id_created_at_index ON public.lead_logs USING btree (lead_id, created_at);


--
-- Name: lead_pool_audit_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_pool_audit_action_created_at_index ON public.lead_pool_audit USING btree (action, created_at);


--
-- Name: lead_pool_audit_lead_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_pool_audit_lead_id_created_at_index ON public.lead_pool_audit USING btree (lead_id, created_at);


--
-- Name: lead_pool_audit_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_pool_audit_user_id_created_at_index ON public.lead_pool_audit USING btree (user_id, created_at);


--
-- Name: lead_recycling_pool_assigned_agent_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_recycling_pool_assigned_agent_id_status_index ON public.lead_recycling_pool USING btree (assigned_agent_id, status);


--
-- Name: lead_recycling_pool_status_available_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_recycling_pool_status_available_at_index ON public.lead_recycling_pool USING btree (status, available_at);


--
-- Name: lead_snapshots_lead_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lead_snapshots_lead_id_index ON public.lead_snapshots USING btree (lead_id);


--
-- Name: leads_assigned_to_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_assigned_to_index ON public.leads USING btree (assigned_to);


--
-- Name: leads_assigned_to_pool_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_assigned_to_pool_status_index ON public.leads USING btree (assigned_to, pool_status);


--
-- Name: leads_customer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_customer_id_index ON public.leads USING btree (customer_id);


--
-- Name: leads_is_exhausted_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_is_exhausted_index ON public.leads USING btree (is_exhausted);


--
-- Name: leads_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_phone_index ON public.leads USING btree (phone);


--
-- Name: leads_pool_status_cooldown_until_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_pool_status_cooldown_until_index ON public.leads USING btree (pool_status, cooldown_until);


--
-- Name: leads_pool_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_pool_status_index ON public.leads USING btree (pool_status);


--
-- Name: leads_pool_status_product_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_pool_status_product_name_index ON public.leads USING btree (pool_status, product_name);


--
-- Name: leads_sales_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_sales_status_index ON public.leads USING btree (sales_status);


--
-- Name: leads_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_status_index ON public.leads USING btree (status);


--
-- Name: messages_conversation_id_send_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_conversation_id_send_status_index ON public.messages USING btree (conversation_id, send_status);


--
-- Name: messages_conversation_id_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_conversation_id_sent_at_index ON public.messages USING btree (conversation_id, sent_at);


--
-- Name: messages_direction_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_direction_index ON public.messages USING btree (direction);


--
-- Name: messages_facebook_page_id_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_facebook_page_id_sent_at_index ON public.messages USING btree (facebook_page_id, sent_at);


--
-- Name: messages_moderation_status_direction_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_moderation_status_direction_index ON public.messages USING btree (moderation_status, direction);


--
-- Name: messages_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_read_at_index ON public.messages USING btree (read_at);


--
-- Name: messages_sent_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_sent_by_index ON public.messages USING btree (sent_by);


--
-- Name: meta_data_deletion_requests_app_scoped_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_data_deletion_requests_app_scoped_user_id_index ON public.meta_data_deletion_requests USING btree (app_scoped_user_id);


--
-- Name: meta_data_deletion_requests_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_data_deletion_requests_status_index ON public.meta_data_deletion_requests USING btree (status);


--
-- Name: milestones_metric_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX milestones_metric_is_active_index ON public.milestones USING btree (metric, is_active);


--
-- Name: notifications_notifiable_type_notifiable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_notifiable_type_notifiable_id_index ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: order_remarks_order_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_remarks_order_id_created_at_index ON public.order_remarks USING btree (order_id, created_at);


--
-- Name: order_remarks_order_id_is_pinned_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_remarks_order_id_is_pinned_index ON public.order_remarks USING btree (order_id, is_pinned);


--
-- Name: order_remarks_order_id_parent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_remarks_order_id_parent_id_index ON public.order_remarks USING btree (order_id, parent_id);


--
-- Name: order_remarks_tags_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_remarks_tags_gin_idx ON public.order_remarks USING gin (((tags)::jsonb));


--
-- Name: order_remarks_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_remarks_type_index ON public.order_remarks USING btree (type);


--
-- Name: order_remarks_visibility_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_remarks_visibility_index ON public.order_remarks USING btree (visibility);


--
-- Name: orders_assigned_agent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_assigned_agent_id_index ON public.orders USING btree (assigned_agent_id);


--
-- Name: orders_conversation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_conversation_id_index ON public.orders USING btree (conversation_id);


--
-- Name: orders_courier_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_courier_code_index ON public.orders USING btree (courier_code);


--
-- Name: orders_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_created_at_index ON public.orders USING btree (created_at);


--
-- Name: orders_customer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_customer_id_index ON public.orders USING btree (customer_id);


--
-- Name: orders_encoder_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_encoder_id_status_index ON public.orders USING btree (encoder_id, status);


--
-- Name: orders_export_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_export_status_index ON public.orders USING btree (export_status);


--
-- Name: orders_facebook_page_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_facebook_page_id_created_at_index ON public.orders USING btree (facebook_page_id, created_at);


--
-- Name: orders_lead_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_lead_id_index ON public.orders USING btree (lead_id);


--
-- Name: orders_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_product_id_index ON public.orders USING btree (product_id);


--
-- Name: orders_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_status_created_at_index ON public.orders USING btree (status, created_at);


--
-- Name: orders_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_status_index ON public.orders USING btree (status);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: product_stocks_last_movement_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_stocks_last_movement_at_index ON public.product_stocks USING btree (last_movement_at);


--
-- Name: product_stocks_warehouse_id_location_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_stocks_warehouse_id_location_id_index ON public.product_stocks USING btree (warehouse_id, location_id);


--
-- Name: product_variants_product_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_variants_product_id_is_active_index ON public.product_variants USING btree (product_id, is_active);


--
-- Name: products_barcode_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_barcode_index ON public.products USING btree (barcode);


--
-- Name: products_brand_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_brand_index ON public.products USING btree (brand);


--
-- Name: products_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_index ON public.products USING btree (category);


--
-- Name: products_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_is_active_index ON public.products USING btree (is_active);


--
-- Name: purchase_order_items_po_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_order_items_po_id_index ON public.purchase_order_items USING btree (po_id);


--
-- Name: purchase_orders_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_status_index ON public.purchase_orders USING btree (status);


--
-- Name: purchase_orders_supplier_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_supplier_id_index ON public.purchase_orders USING btree (supplier_id);


--
-- Name: purchase_requests_requested_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_requests_requested_by_index ON public.purchase_requests USING btree (requested_by);


--
-- Name: purchase_requests_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_requests_status_index ON public.purchase_requests USING btree (status);


--
-- Name: qa_reviews_lead_id_qa_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qa_reviews_lead_id_qa_level_index ON public.qa_reviews USING btree (lead_id, qa_level);


--
-- Name: qa_reviews_reviewer_id_qa_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qa_reviews_reviewer_id_qa_status_index ON public.qa_reviews USING btree (reviewer_id, qa_status);


--
-- Name: qbo_sync_queue_entity_type_entity_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qbo_sync_queue_entity_type_entity_id_index ON public.qbo_sync_queue USING btree (entity_type, entity_id);


--
-- Name: qbo_sync_queue_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX qbo_sync_queue_status_index ON public.qbo_sync_queue USING btree (status);


--
-- Name: receiving_report_items_grn_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receiving_report_items_grn_id_index ON public.receiving_report_items USING btree (grn_id);


--
-- Name: receiving_reports_po_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receiving_reports_po_id_index ON public.receiving_reports USING btree (po_id);


--
-- Name: receiving_reports_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receiving_reports_status_index ON public.receiving_reports USING btree (status);


--
-- Name: remark_templates_is_active_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX remark_templates_is_active_type_index ON public.remark_templates USING btree (is_active, type);


--
-- Name: reply_template_ab_tests_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_template_ab_tests_status_index ON public.reply_template_ab_tests USING btree (status);


--
-- Name: reply_template_ab_variants_ab_test_id_reply_template_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_template_ab_variants_ab_test_id_reply_template_id_index ON public.reply_template_ab_variants USING btree (ab_test_id, reply_template_id);


--
-- Name: reply_template_usage_conversation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_template_usage_conversation_id_index ON public.reply_template_usage USING btree (conversation_id);


--
-- Name: reply_template_usage_reply_template_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_template_usage_reply_template_id_created_at_index ON public.reply_template_usage USING btree (reply_template_id, created_at);


--
-- Name: reply_template_usage_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_template_usage_user_id_created_at_index ON public.reply_template_usage USING btree (user_id, created_at);


--
-- Name: reply_template_versions_reply_template_id_version_number_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_template_versions_reply_template_id_version_number_index ON public.reply_template_versions USING btree (reply_template_id, version_number);


--
-- Name: reply_templates_allowed_roles_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_allowed_roles_gin_idx ON public.reply_templates USING gin (((allowed_roles)::jsonb) jsonb_path_ops);


--
-- Name: reply_templates_approval_status_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_approval_status_is_active_index ON public.reply_templates USING btree (approval_status, is_active);


--
-- Name: reply_templates_category_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_category_is_active_index ON public.reply_templates USING btree (category, is_active);


--
-- Name: reply_templates_facebook_page_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_facebook_page_id_is_active_index ON public.reply_templates USING btree (facebook_page_id, is_active);


--
-- Name: reply_templates_intent_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_intent_is_active_index ON public.reply_templates USING btree (intent, is_active);


--
-- Name: reply_templates_language_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_language_is_active_index ON public.reply_templates USING btree (language, is_active);


--
-- Name: reply_templates_media_type_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_media_type_is_active_index ON public.reply_templates USING btree (media_type, is_active);


--
-- Name: reply_templates_shortcut_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reply_templates_shortcut_index ON public.reply_templates USING btree (shortcut);


--
-- Name: return_receipts_scanned_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX return_receipts_scanned_at_index ON public.return_receipts USING btree (scanned_at);


--
-- Name: scheduled_messages_conversation_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scheduled_messages_conversation_id_index ON public.scheduled_messages USING btree (conversation_id);


--
-- Name: scheduled_messages_status_scheduled_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scheduled_messages_status_scheduled_at_index ON public.scheduled_messages USING btree (status, scheduled_at);


--
-- Name: scheduled_sales_reports_is_active_next_run_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scheduled_sales_reports_is_active_next_run_at_index ON public.scheduled_sales_reports USING btree (is_active, next_run_at);


--
-- Name: settings_group_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX settings_group_index ON public.settings USING btree ("group");


--
-- Name: shipping_rates_courier_zone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipping_rates_courier_zone_index ON public.shipping_rates USING btree (courier_zone);


--
-- Name: shop_order_items_order_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_order_items_order_id_index ON public.shop_order_items USING btree (order_id);


--
-- Name: shop_order_items_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_order_items_product_id_index ON public.shop_order_items USING btree (product_id);


--
-- Name: shop_reply_templates_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_reply_templates_category_index ON public.shop_reply_templates USING btree (category);


--
-- Name: shop_reply_templates_facebook_page_id_is_active_sort_order_inde; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_reply_templates_facebook_page_id_is_active_sort_order_inde ON public.shop_reply_templates USING btree (facebook_page_id, is_active, sort_order);


--
-- Name: shop_reply_templates_is_active_sort_order_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_reply_templates_is_active_sort_order_index ON public.shop_reply_templates USING btree (is_active, sort_order);


--
-- Name: sms_logs_campaign_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_logs_campaign_id_status_index ON public.sms_logs USING btree (campaign_id, status);


--
-- Name: sms_logs_phone_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_logs_phone_created_at_index ON public.sms_logs USING btree (phone, created_at);


--
-- Name: sms_logs_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_logs_status_index ON public.sms_logs USING btree (status);


--
-- Name: sms_sequence_enrollments_next_step_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_sequence_enrollments_next_step_at_index ON public.sms_sequence_enrollments USING btree (next_step_at);


--
-- Name: sms_sequence_enrollments_sequence_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_sequence_enrollments_sequence_id_status_index ON public.sms_sequence_enrollments USING btree (sequence_id, status);


--
-- Name: stock_adjustments_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_adjustments_status_index ON public.stock_adjustments USING btree (status);


--
-- Name: stock_audit_items_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_audit_items_status_index ON public.stock_audit_items USING btree (status);


--
-- Name: stock_audit_sessions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_audit_sessions_status_index ON public.stock_audit_sessions USING btree (status);


--
-- Name: stock_reservations_reference_type_reference_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_reservations_reference_type_reference_id_index ON public.stock_reservations USING btree (reference_type, reference_id);


--
-- Name: stock_reservations_status_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_reservations_status_expires_at_index ON public.stock_reservations USING btree (status, expires_at);


--
-- Name: supplier_invoices_date_invoice_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_invoices_date_invoice_index ON public.supplier_invoices USING btree (date_invoice);


--
-- Name: supplier_invoices_status_date_due_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_invoices_status_date_due_index ON public.supplier_invoices USING btree (status, date_due);


--
-- Name: supplier_invoices_third_party_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_invoices_third_party_id_status_index ON public.supplier_invoices USING btree (third_party_id, status);


--
-- Name: suppliers_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_is_active_index ON public.suppliers USING btree (is_active);


--
-- Name: supplies_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplies_category_index ON public.supplies USING btree (category);


--
-- Name: supplies_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplies_is_active_index ON public.supplies USING btree (is_active);


--
-- Name: supplies_section_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplies_section_index ON public.supplies USING btree (section);


--
-- Name: supplies_stock_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplies_stock_category_index ON public.supplies USING btree (stock_category);


--
-- Name: supplies_stock_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplies_stock_status_index ON public.supplies USING btree (stock_status);


--
-- Name: supply_movements_reference_type_reference_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_movements_reference_type_reference_id_index ON public.supply_movements USING btree (reference_type, reference_id);


--
-- Name: supply_movements_supply_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_movements_supply_id_created_at_index ON public.supply_movements USING btree (supply_id, created_at);


--
-- Name: supply_movements_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_movements_type_index ON public.supply_movements USING btree (type);


--
-- Name: supply_stocks_last_movement_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_stocks_last_movement_at_index ON public.supply_stocks USING btree (last_movement_at);


--
-- Name: third_parties_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX third_parties_created_at_index ON public.third_parties USING btree (created_at);


--
-- Name: third_parties_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX third_parties_email_index ON public.third_parties USING btree (email);


--
-- Name: third_parties_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX third_parties_phone_index ON public.third_parties USING btree (phone);


--
-- Name: third_parties_risk_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX third_parties_risk_level_index ON public.third_parties USING btree (risk_level);


--
-- Name: third_parties_type_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX third_parties_type_status_index ON public.third_parties USING btree (type, status);


--
-- Name: ticket_canned_responses_is_active_category_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ticket_canned_responses_is_active_category_index ON public.ticket_canned_responses USING btree (is_active, category);


--
-- Name: ticket_comments_ticket_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ticket_comments_ticket_id_created_at_index ON public.ticket_comments USING btree (ticket_id, created_at);


--
-- Name: ticket_comments_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ticket_comments_user_id_index ON public.ticket_comments USING btree (user_id);


--
-- Name: tickets_assigned_to_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tickets_assigned_to_index ON public.tickets USING btree (assigned_to);


--
-- Name: tickets_created_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tickets_created_by_index ON public.tickets USING btree (created_by);


--
-- Name: tickets_due_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tickets_due_at_index ON public.tickets USING btree (due_at);


--
-- Name: tickets_status_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tickets_status_priority_index ON public.tickets USING btree (status, priority);


--
-- Name: unknown_waybill_scans_resolution_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unknown_waybill_scans_resolution_status_index ON public.unknown_waybill_scans USING btree (resolution_status);


--
-- Name: unknown_waybill_scans_scan_session_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unknown_waybill_scans_scan_session_id_index ON public.unknown_waybill_scans USING btree (scan_session_id);


--
-- Name: unknown_waybill_scans_scanned_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unknown_waybill_scans_scanned_at_index ON public.unknown_waybill_scans USING btree (scanned_at);


--
-- Name: unknown_waybill_scans_waybill_no_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unknown_waybill_scans_waybill_no_index ON public.unknown_waybill_scans USING btree (waybill_no);


--
-- Name: uploads_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX uploads_status_index ON public.uploads USING btree (status);


--
-- Name: user_module_access_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_module_access_user_id_index ON public.user_module_access USING btree (user_id);


--
-- Name: warehouse_locations_warehouse_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX warehouse_locations_warehouse_id_is_active_index ON public.warehouse_locations USING btree (warehouse_id, is_active);


--
-- Name: warehouses_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX warehouses_is_active_index ON public.warehouses USING btree (is_active);


--
-- Name: waybill_tracking_history_waybill_id_tracked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybill_tracking_history_waybill_id_tracked_at_index ON public.waybill_tracking_history USING btree (waybill_id, tracked_at);


--
-- Name: waybills_courier_provider_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_courier_provider_status_index ON public.waybills USING btree (courier_provider, status);


--
-- Name: waybills_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_created_at_index ON public.waybills USING btree (created_at);


--
-- Name: waybills_creator_code_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_creator_code_index ON public.waybills USING btree (creator_code);


--
-- Name: waybills_dispatched_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_dispatched_at_index ON public.waybills USING btree (dispatched_at);


--
-- Name: waybills_receiver_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_receiver_name_index ON public.waybills USING btree (receiver_name);


--
-- Name: waybills_receiver_phone_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_receiver_phone_index ON public.waybills USING btree (receiver_phone);


--
-- Name: waybills_returned_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_returned_at_index ON public.waybills USING btree (returned_at);


--
-- Name: waybills_status_delivered_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_status_delivered_at_index ON public.waybills USING btree (status, delivered_at);


--
-- Name: waybills_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_status_index ON public.waybills USING btree (status);


--
-- Name: waybills_status_returned_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_status_returned_at_index ON public.waybills USING btree (status, returned_at);


--
-- Name: waybills_submitted_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_submitted_at_index ON public.waybills USING btree (submitted_at);


--
-- Name: waybills_upload_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX waybills_upload_id_status_index ON public.waybills USING btree (upload_id, status);


--
-- Name: webhook_logs_processing_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_logs_processing_status_index ON public.webhook_logs USING btree (processing_status);


--
-- Name: webhook_logs_provider_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_logs_provider_created_at_index ON public.webhook_logs USING btree (provider, created_at);


--
-- Name: waybills waybill_protect_terminal; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER waybill_protect_terminal BEFORE UPDATE ON public.waybills FOR EACH ROW EXECUTE FUNCTION public.protect_waybill_terminal_status();


--
-- Name: activity_logs activity_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: address_correction_history address_correction_history_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_correction_history
    ADD CONSTRAINT address_correction_history_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: address_correction_history address_correction_history_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_correction_history
    ADD CONSTRAINT address_correction_history_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: addresses addresses_third_party_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_third_party_id_foreign FOREIGN KEY (third_party_id) REFERENCES public.third_parties(id) ON DELETE CASCADE;


--
-- Name: agent_badges agent_badges_badge_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_badges
    ADD CONSTRAINT agent_badges_badge_id_foreign FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: agent_badges agent_badges_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_badges
    ADD CONSTRAINT agent_badges_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_commissions agent_commissions_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_agent_id_foreign FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_commissions agent_commissions_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: agent_commissions agent_commissions_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: agent_commissions agent_commissions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: agent_commissions agent_commissions_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: agent_flags agent_flags_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flags
    ADD CONSTRAINT agent_flags_agent_id_foreign FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_flags agent_flags_resolved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flags
    ADD CONSTRAINT agent_flags_resolved_by_foreign FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agent_milestones agent_milestones_milestone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_milestones
    ADD CONSTRAINT agent_milestones_milestone_id_foreign FOREIGN KEY (milestone_id) REFERENCES public.milestones(id) ON DELETE CASCADE;


--
-- Name: agent_milestones agent_milestones_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_milestones
    ADD CONSTRAINT agent_milestones_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_profiles agent_profiles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_streaks agent_streaks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_streaks
    ADD CONSTRAINT agent_streaks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_workloads agent_workloads_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_workloads
    ADD CONSTRAINT agent_workloads_agent_id_foreign FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: batch_item_error_logs batch_item_error_logs_courier_export_batch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_item_error_logs
    ADD CONSTRAINT batch_item_error_logs_courier_export_batch_id_foreign FOREIGN KEY (courier_export_batch_id) REFERENCES public.courier_export_batches(id) ON DELETE CASCADE;


--
-- Name: batch_item_error_logs batch_item_error_logs_courier_export_row_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_item_error_logs
    ADD CONSTRAINT batch_item_error_logs_courier_export_row_id_foreign FOREIGN KEY (courier_export_row_id) REFERENCES public.courier_export_rows(id) ON DELETE CASCADE;


--
-- Name: batch_item_error_logs batch_item_error_logs_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_item_error_logs
    ADD CONSTRAINT batch_item_error_logs_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: batch_item_error_logs batch_item_error_logs_resolved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_item_error_logs
    ADD CONSTRAINT batch_item_error_logs_resolved_by_foreign FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: batch_scan_items batch_scan_items_batch_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_scan_items
    ADD CONSTRAINT batch_scan_items_batch_session_id_foreign FOREIGN KEY (batch_session_id) REFERENCES public.batch_sessions(id) ON DELETE CASCADE;


--
-- Name: batch_scan_items batch_scan_items_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_scan_items
    ADD CONSTRAINT batch_scan_items_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: batch_sessions batch_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_sessions
    ADD CONSTRAINT batch_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: batch_status_history batch_status_history_changed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_status_history
    ADD CONSTRAINT batch_status_history_changed_by_foreign FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: batch_status_history batch_status_history_courier_export_batch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_status_history
    ADD CONSTRAINT batch_status_history_courier_export_batch_id_foreign FOREIGN KEY (courier_export_batch_id) REFERENCES public.courier_export_batches(id) ON DELETE CASCADE;


--
-- Name: broadcast_campaigns broadcast_campaigns_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_campaigns
    ADD CONSTRAINT broadcast_campaigns_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: broadcast_campaigns broadcast_campaigns_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_campaigns
    ADD CONSTRAINT broadcast_campaigns_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: broadcast_recipients broadcast_recipients_broadcast_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_broadcast_campaign_id_foreign FOREIGN KEY (broadcast_campaign_id) REFERENCES public.broadcast_campaigns(id) ON DELETE CASCADE;


--
-- Name: broadcast_recipients broadcast_recipients_broadcast_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_broadcast_variant_id_foreign FOREIGN KEY (broadcast_variant_id) REFERENCES public.broadcast_variants(id) ON DELETE CASCADE;


--
-- Name: broadcast_recipients broadcast_recipients_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: broadcast_recipients broadcast_recipients_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: broadcast_recipients broadcast_recipients_message_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_message_id_foreign FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: broadcast_variants broadcast_variants_broadcast_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcast_variants
    ADD CONSTRAINT broadcast_variants_broadcast_campaign_id_foreign FOREIGN KEY (broadcast_campaign_id) REFERENCES public.broadcast_campaigns(id) ON DELETE CASCADE;


--
-- Name: capex_asset_assignments capex_asset_assignments_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_asset_assignments
    ADD CONSTRAINT capex_asset_assignments_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: capex_asset_assignments capex_asset_assignments_assigned_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_asset_assignments
    ADD CONSTRAINT capex_asset_assignments_assigned_to_foreign FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: capex_asset_assignments capex_asset_assignments_capex_asset_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_asset_assignments
    ADD CONSTRAINT capex_asset_assignments_capex_asset_id_foreign FOREIGN KEY (capex_asset_id) REFERENCES public.capex_assets(id) ON DELETE CASCADE;


--
-- Name: capex_assets capex_assets_assigned_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets
    ADD CONSTRAINT capex_assets_assigned_to_foreign FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: capex_assets capex_assets_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets
    ADD CONSTRAINT capex_assets_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: capex_assets capex_assets_uom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets
    ADD CONSTRAINT capex_assets_uom_id_foreign FOREIGN KEY (uom_id) REFERENCES public.units_of_measure(id) ON DELETE SET NULL;


--
-- Name: capex_assets capex_assets_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_assets
    ADD CONSTRAINT capex_assets_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: capex_depreciation_schedule capex_depreciation_schedule_capex_asset_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_depreciation_schedule
    ADD CONSTRAINT capex_depreciation_schedule_capex_asset_id_foreign FOREIGN KEY (capex_asset_id) REFERENCES public.capex_assets(id) ON DELETE CASCADE;


--
-- Name: capex_depreciation_schedule capex_depreciation_schedule_posted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capex_depreciation_schedule
    ADD CONSTRAINT capex_depreciation_schedule_posted_by_foreign FOREIGN KEY (posted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cart_templates cart_templates_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_templates
    ADD CONSTRAINT cart_templates_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: claims claims_filed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_filed_by_foreign FOREIGN KEY (filed_by) REFERENCES public.users(id);


--
-- Name: claims claims_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: claims claims_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE CASCADE;


--
-- Name: cogs_entries cogs_entries_cost_lot_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cogs_entries
    ADD CONSTRAINT cogs_entries_cost_lot_id_foreign FOREIGN KEY (cost_lot_id) REFERENCES public.stock_cost_lots(id) ON DELETE SET NULL;


--
-- Name: cogs_entries cogs_entries_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cogs_entries
    ADD CONSTRAINT cogs_entries_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: cogs_entries cogs_entries_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cogs_entries
    ADD CONSTRAINT cogs_entries_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: commission_rules commission_rules_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_rules
    ADD CONSTRAINT commission_rules_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: contacts contacts_third_party_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_third_party_id_foreign FOREIGN KEY (third_party_id) REFERENCES public.third_parties(id) ON DELETE CASCADE;


--
-- Name: conversation_assignment_histories conversation_assignment_histories_assigned_by_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_assignment_histories
    ADD CONSTRAINT conversation_assignment_histories_assigned_by_id_foreign FOREIGN KEY (assigned_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conversation_assignment_histories conversation_assignment_histories_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_assignment_histories
    ADD CONSTRAINT conversation_assignment_histories_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_assignment_histories conversation_assignment_histories_from_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_assignment_histories
    ADD CONSTRAINT conversation_assignment_histories_from_agent_id_foreign FOREIGN KEY (from_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conversation_assignment_histories conversation_assignment_histories_to_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_assignment_histories
    ADD CONSTRAINT conversation_assignment_histories_to_agent_id_foreign FOREIGN KEY (to_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conversation_exports conversation_exports_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_exports
    ADD CONSTRAINT conversation_exports_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conversation_status_histories conversation_status_histories_changed_by_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_status_histories
    ADD CONSTRAINT conversation_status_histories_changed_by_id_foreign FOREIGN KEY (changed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conversation_status_histories conversation_status_histories_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_status_histories
    ADD CONSTRAINT conversation_status_histories_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_tag conversation_tag_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_tag
    ADD CONSTRAINT conversation_tag_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_tag conversation_tag_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_tag
    ADD CONSTRAINT conversation_tag_tag_id_foreign FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_assigned_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_assigned_agent_id_foreign FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_customer_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_customer_identity_id_foreign FOREIGN KEY (customer_identity_id) REFERENCES public.customer_identities(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_merged_into_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_merged_into_id_foreign FOREIGN KEY (merged_into_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: courier_api_logs courier_api_logs_courier_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_api_logs
    ADD CONSTRAINT courier_api_logs_courier_provider_id_foreign FOREIGN KEY (courier_provider_id) REFERENCES public.courier_providers(id) ON DELETE SET NULL;


--
-- Name: courier_api_logs courier_api_logs_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_api_logs
    ADD CONSTRAINT courier_api_logs_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: courier_csv_templates courier_csv_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_templates
    ADD CONSTRAINT courier_csv_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: courier_csv_validation_error_logs courier_csv_validation_error_logs_courier_export_batch_id_forei; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_validation_error_logs
    ADD CONSTRAINT courier_csv_validation_error_logs_courier_export_batch_id_forei FOREIGN KEY (courier_export_batch_id) REFERENCES public.courier_export_batches(id) ON DELETE SET NULL;


--
-- Name: courier_csv_validation_error_logs courier_csv_validation_error_logs_courier_export_row_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_validation_error_logs
    ADD CONSTRAINT courier_csv_validation_error_logs_courier_export_row_id_foreign FOREIGN KEY (courier_export_row_id) REFERENCES public.courier_export_rows(id) ON DELETE SET NULL;


--
-- Name: courier_csv_validation_error_logs courier_csv_validation_error_logs_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_csv_validation_error_logs
    ADD CONSTRAINT courier_csv_validation_error_logs_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: courier_export_batch_shares courier_export_batch_shares_courier_export_batch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batch_shares
    ADD CONSTRAINT courier_export_batch_shares_courier_export_batch_id_foreign FOREIGN KEY (courier_export_batch_id) REFERENCES public.courier_export_batches(id) ON DELETE CASCADE;


--
-- Name: courier_export_batch_shares courier_export_batch_shares_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batch_shares
    ADD CONSTRAINT courier_export_batch_shares_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: courier_export_batches courier_export_batches_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_batches
    ADD CONSTRAINT courier_export_batches_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: courier_export_rows courier_export_rows_courier_export_batch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_rows
    ADD CONSTRAINT courier_export_rows_courier_export_batch_id_foreign FOREIGN KEY (courier_export_batch_id) REFERENCES public.courier_export_batches(id) ON DELETE CASCADE;


--
-- Name: courier_export_rows courier_export_rows_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_export_rows
    ADD CONSTRAINT courier_export_rows_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: customer_addresses customer_addresses_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT customer_addresses_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_audit_logs customer_audit_logs_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_audit_logs
    ADD CONSTRAINT customer_audit_logs_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_audit_logs customer_audit_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_audit_logs
    ADD CONSTRAINT customer_audit_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: customer_identities customer_identities_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_identities
    ADD CONSTRAINT customer_identities_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: customer_identities customer_identities_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_identities
    ADD CONSTRAINT customer_identities_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: customer_notes customer_notes_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_notes customer_notes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: customers customers_last_page_ordered_from_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_last_page_ordered_from_foreign FOREIGN KEY (last_page_ordered_from) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: dashboard_widget_configs dashboard_widget_configs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widget_configs
    ADD CONSTRAINT dashboard_widget_configs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dead_stocks dead_stocks_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_stocks
    ADD CONSTRAINT dead_stocks_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: dead_stocks dead_stocks_recorded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_stocks
    ADD CONSTRAINT dead_stocks_recorded_by_foreign FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: dead_stocks dead_stocks_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_stocks
    ADD CONSTRAINT dead_stocks_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE SET NULL;


--
-- Name: dead_stocks dead_stocks_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dead_stocks
    ADD CONSTRAINT dead_stocks_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: delivery_proofs delivery_proofs_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_proofs
    ADD CONSTRAINT delivery_proofs_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: delivery_proofs delivery_proofs_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_proofs
    ADD CONSTRAINT delivery_proofs_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE CASCADE;


--
-- Name: distribution_queues distribution_queues_assigned_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_queues
    ADD CONSTRAINT distribution_queues_assigned_agent_id_foreign FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: distribution_queues distribution_queues_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_queues
    ADD CONSTRAINT distribution_queues_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: distribution_queues distribution_queues_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_queues
    ADD CONSTRAINT distribution_queues_rule_id_foreign FOREIGN KEY (rule_id) REFERENCES public.distribution_rules(id) ON DELETE SET NULL;


--
-- Name: distribution_rules distribution_rules_supervisor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_rules
    ADD CONSTRAINT distribution_rules_supervisor_id_foreign FOREIGN KEY (supervisor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: duplicate_family_members duplicate_family_members_family_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.duplicate_family_members
    ADD CONSTRAINT duplicate_family_members_family_id_foreign FOREIGN KEY (family_id) REFERENCES public.duplicate_families(id) ON DELETE CASCADE;


--
-- Name: facebook_accounts facebook_accounts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_accounts
    ADD CONSTRAINT facebook_accounts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: facebook_pages facebook_pages_connected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_pages
    ADD CONSTRAINT facebook_pages_connected_by_foreign FOREIGN KEY (connected_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: facebook_pages facebook_pages_facebook_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_pages
    ADD CONSTRAINT facebook_pages_facebook_account_id_foreign FOREIGN KEY (facebook_account_id) REFERENCES public.facebook_accounts(id) ON DELETE SET NULL;


--
-- Name: facebook_webhook_events facebook_webhook_events_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.facebook_webhook_events
    ADD CONSTRAINT facebook_webhook_events_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: finance_settings finance_settings_locked_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.finance_settings
    ADD CONSTRAINT finance_settings_locked_by_foreign FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_recorded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_recorded_by_foreign FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fraud_flags fraud_flags_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fraud_flags
    ADD CONSTRAINT fraud_flags_agent_id_foreign FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fraud_flags fraud_flags_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fraud_flags
    ADD CONSTRAINT fraud_flags_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: fraud_flags fraud_flags_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fraud_flags
    ADD CONSTRAINT fraud_flags_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: import_chunks import_chunks_upload_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_chunks
    ADD CONSTRAINT import_chunks_upload_id_foreign FOREIGN KEY (upload_id) REFERENCES public.uploads(id) ON DELETE CASCADE;


--
-- Name: inventory_movements inventory_movements_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_movements inventory_movements_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_movements inventory_movements_performed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_performed_by_foreign FOREIGN KEY (performed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_movements inventory_movements_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: inventory_movements inventory_movements_to_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_to_location_id_foreign FOREIGN KEY (to_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: inventory_movements inventory_movements_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: inventory_movements inventory_movements_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: invoice_lines invoice_lines_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_lines invoice_lines_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: invoice_payments invoice_payments_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_recorded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_recorded_by_foreign FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_third_party_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_third_party_id_foreign FOREIGN KEY (third_party_id) REFERENCES public.third_parties(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lead_cycles lead_cycles_assigned_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_cycles
    ADD CONSTRAINT lead_cycles_assigned_agent_id_foreign FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lead_cycles lead_cycles_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_cycles
    ADD CONSTRAINT lead_cycles_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_logs lead_logs_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_logs
    ADD CONSTRAINT lead_logs_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: lead_logs lead_logs_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_logs
    ADD CONSTRAINT lead_logs_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_logs lead_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_logs
    ADD CONSTRAINT lead_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lead_pool_audit lead_pool_audit_lead_cycle_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_pool_audit
    ADD CONSTRAINT lead_pool_audit_lead_cycle_id_foreign FOREIGN KEY (lead_cycle_id) REFERENCES public.lead_cycles(id) ON DELETE SET NULL;


--
-- Name: lead_pool_audit lead_pool_audit_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_pool_audit
    ADD CONSTRAINT lead_pool_audit_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_pool_audit lead_pool_audit_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_pool_audit
    ADD CONSTRAINT lead_pool_audit_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lead_recycling_pool lead_recycling_pool_assigned_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_recycling_pool
    ADD CONSTRAINT lead_recycling_pool_assigned_agent_id_foreign FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lead_recycling_pool lead_recycling_pool_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_recycling_pool
    ADD CONSTRAINT lead_recycling_pool_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: lead_recycling_pool lead_recycling_pool_previous_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_recycling_pool
    ADD CONSTRAINT lead_recycling_pool_previous_agent_id_foreign FOREIGN KEY (previous_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lead_snapshots lead_snapshots_cycle_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_snapshots
    ADD CONSTRAINT lead_snapshots_cycle_id_foreign FOREIGN KEY (cycle_id) REFERENCES public.lead_cycles(id) ON DELETE SET NULL;


--
-- Name: lead_snapshots lead_snapshots_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lead_snapshots
    ADD CONSTRAINT lead_snapshots_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: leads leads_assigned_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assigned_to_foreign FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leads leads_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: leads leads_original_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_original_agent_id_foreign FOREIGN KEY (original_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leads leads_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: messages messages_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_customer_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_customer_identity_id_foreign FOREIGN KEY (customer_identity_id) REFERENCES public.customer_identities(id) ON DELETE SET NULL;


--
-- Name: messages messages_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: messages messages_sent_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sent_by_foreign FOREIGN KEY (sent_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: milestones milestones_reward_badge_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_reward_badge_id_foreign FOREIGN KEY (reward_badge_id) REFERENCES public.badges(id) ON DELETE SET NULL;


--
-- Name: order_remarks order_remarks_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks
    ADD CONSTRAINT order_remarks_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: order_remarks order_remarks_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks
    ADD CONSTRAINT order_remarks_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_remarks order_remarks_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks
    ADD CONSTRAINT order_remarks_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.order_remarks(id) ON DELETE CASCADE;


--
-- Name: order_remarks order_remarks_pinned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks
    ADD CONSTRAINT order_remarks_pinned_by_foreign FOREIGN KEY (pinned_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: order_remarks order_remarks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_remarks
    ADD CONSTRAINT order_remarks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: order_tag order_tag_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tag
    ADD CONSTRAINT order_tag_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_tag order_tag_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_tag
    ADD CONSTRAINT order_tag_tag_id_foreign FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: orders orders_address_mapping_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_address_mapping_id_foreign FOREIGN KEY (address_mapping_id) REFERENCES public.address_mappings(id) ON DELETE SET NULL;


--
-- Name: orders orders_assigned_agent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_assigned_agent_id_foreign FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: orders orders_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: orders orders_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: orders orders_encoder_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_encoder_id_foreign FOREIGN KEY (encoder_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: orders orders_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: orders orders_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: orders orders_parent_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_parent_order_id_foreign FOREIGN KEY (parent_order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: orders orders_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: orders orders_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: orders orders_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: page_assignment_rules page_assignment_rules_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_assignment_rules
    ADD CONSTRAINT page_assignment_rules_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE CASCADE;


--
-- Name: page_assignment_rules page_assignment_rules_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_assignment_rules
    ADD CONSTRAINT page_assignment_rules_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: page_favorites page_favorites_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_favorites
    ADD CONSTRAINT page_favorites_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE CASCADE;


--
-- Name: page_favorites page_favorites_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_favorites
    ADD CONSTRAINT page_favorites_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: page_status_labels page_status_labels_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_labels
    ADD CONSTRAINT page_status_labels_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE CASCADE;


--
-- Name: page_status_rules page_status_rules_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_status_rules
    ADD CONSTRAINT page_status_rules_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE CASCADE;


--
-- Name: product_stocks product_stocks_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: product_stocks product_stocks_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_stocks product_stocks_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: product_stocks product_stocks_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: product_variants product_variants_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_uom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_uom_id_foreign FOREIGN KEY (uom_id) REFERENCES public.units_of_measure(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_po_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_po_id_foreign FOREIGN KEY (po_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_uom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_uom_id_foreign FOREIGN KEY (uom_id) REFERENCES public.units_of_measure(id) ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_pr_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pr_id_foreign FOREIGN KEY (pr_id) REFERENCES public.purchase_requests(id) ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_supplier_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_foreign FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: purchase_orders purchase_orders_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: purchase_request_items purchase_request_items_pr_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_pr_id_foreign FOREIGN KEY (pr_id) REFERENCES public.purchase_requests(id) ON DELETE CASCADE;


--
-- Name: purchase_request_items purchase_request_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: purchase_request_items purchase_request_items_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE SET NULL;


--
-- Name: purchase_request_items purchase_request_items_uom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_uom_id_foreign FOREIGN KEY (uom_id) REFERENCES public.units_of_measure(id) ON DELETE SET NULL;


--
-- Name: purchase_request_items purchase_request_items_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_request_items
    ADD CONSTRAINT purchase_request_items_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: purchase_requests purchase_requests_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: purchase_requests purchase_requests_requested_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_requested_by_foreign FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: qa_reviews qa_reviews_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_reviews
    ADD CONSTRAINT qa_reviews_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: qa_reviews qa_reviews_reviewer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qa_reviews
    ADD CONSTRAINT qa_reviews_reviewer_id_foreign FOREIGN KEY (reviewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: qbo_account_mappings qbo_account_mappings_mapped_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_account_mappings
    ADD CONSTRAINT qbo_account_mappings_mapped_by_foreign FOREIGN KEY (mapped_by) REFERENCES public.users(id);


--
-- Name: qbo_connections qbo_connections_connected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qbo_connections
    ADD CONSTRAINT qbo_connections_connected_by_foreign FOREIGN KEY (connected_by) REFERENCES public.users(id);


--
-- Name: receiving_report_items receiving_report_items_grn_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_report_items
    ADD CONSTRAINT receiving_report_items_grn_id_foreign FOREIGN KEY (grn_id) REFERENCES public.receiving_reports(id) ON DELETE CASCADE;


--
-- Name: receiving_report_items receiving_report_items_po_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_report_items
    ADD CONSTRAINT receiving_report_items_po_item_id_foreign FOREIGN KEY (po_item_id) REFERENCES public.purchase_order_items(id);


--
-- Name: receiving_reports receiving_reports_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports
    ADD CONSTRAINT receiving_reports_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: receiving_reports receiving_reports_po_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports
    ADD CONSTRAINT receiving_reports_po_id_foreign FOREIGN KEY (po_id) REFERENCES public.purchase_orders(id);


--
-- Name: receiving_reports receiving_reports_received_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports
    ADD CONSTRAINT receiving_reports_received_by_foreign FOREIGN KEY (received_by) REFERENCES public.users(id);


--
-- Name: receiving_reports receiving_reports_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receiving_reports
    ADD CONSTRAINT receiving_reports_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: remark_templates remark_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remark_templates
    ADD CONSTRAINT remark_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reply_template_ab_tests reply_template_ab_tests_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_tests
    ADD CONSTRAINT reply_template_ab_tests_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reply_template_ab_tests reply_template_ab_tests_winning_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_tests
    ADD CONSTRAINT reply_template_ab_tests_winning_variant_id_foreign FOREIGN KEY (winning_variant_id) REFERENCES public.reply_template_ab_variants(id) ON DELETE SET NULL;


--
-- Name: reply_template_ab_variants reply_template_ab_variants_ab_test_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_variants
    ADD CONSTRAINT reply_template_ab_variants_ab_test_id_foreign FOREIGN KEY (ab_test_id) REFERENCES public.reply_template_ab_tests(id) ON DELETE CASCADE;


--
-- Name: reply_template_ab_variants reply_template_ab_variants_reply_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_ab_variants
    ADD CONSTRAINT reply_template_ab_variants_reply_template_id_foreign FOREIGN KEY (reply_template_id) REFERENCES public.reply_templates(id) ON DELETE CASCADE;


--
-- Name: reply_template_favorites reply_template_favorites_reply_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_favorites
    ADD CONSTRAINT reply_template_favorites_reply_template_id_foreign FOREIGN KEY (reply_template_id) REFERENCES public.reply_templates(id) ON DELETE CASCADE;


--
-- Name: reply_template_favorites reply_template_favorites_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_favorites
    ADD CONSTRAINT reply_template_favorites_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reply_template_shares reply_template_shares_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_shares
    ADD CONSTRAINT reply_template_shares_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE CASCADE;


--
-- Name: reply_template_shares reply_template_shares_reply_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_shares
    ADD CONSTRAINT reply_template_shares_reply_template_id_foreign FOREIGN KEY (reply_template_id) REFERENCES public.reply_templates(id) ON DELETE CASCADE;


--
-- Name: reply_template_usage reply_template_usage_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_usage
    ADD CONSTRAINT reply_template_usage_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: reply_template_usage reply_template_usage_reply_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_usage
    ADD CONSTRAINT reply_template_usage_reply_template_id_foreign FOREIGN KEY (reply_template_id) REFERENCES public.reply_templates(id) ON DELETE CASCADE;


--
-- Name: reply_template_usage reply_template_usage_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_usage
    ADD CONSTRAINT reply_template_usage_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reply_template_versions reply_template_versions_edited_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_versions
    ADD CONSTRAINT reply_template_versions_edited_by_foreign FOREIGN KEY (edited_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reply_template_versions reply_template_versions_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_versions
    ADD CONSTRAINT reply_template_versions_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: reply_template_versions reply_template_versions_reply_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_template_versions
    ADD CONSTRAINT reply_template_versions_reply_template_id_foreign FOREIGN KEY (reply_template_id) REFERENCES public.reply_templates(id) ON DELETE CASCADE;


--
-- Name: reply_templates reply_templates_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_templates
    ADD CONSTRAINT reply_templates_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reply_templates reply_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_templates
    ADD CONSTRAINT reply_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reply_templates reply_templates_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_templates
    ADD CONSTRAINT reply_templates_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: return_receipts return_receipts_inventory_movement_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_receipts
    ADD CONSTRAINT return_receipts_inventory_movement_id_foreign FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE SET NULL;


--
-- Name: return_receipts return_receipts_scanned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_receipts
    ADD CONSTRAINT return_receipts_scanned_by_foreign FOREIGN KEY (scanned_by) REFERENCES public.users(id);


--
-- Name: return_receipts return_receipts_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_receipts
    ADD CONSTRAINT return_receipts_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_conversation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_conversation_id_foreign FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_customer_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_customer_identity_id_foreign FOREIGN KEY (customer_identity_id) REFERENCES public.customer_identities(id) ON DELETE SET NULL;


--
-- Name: scheduled_messages scheduled_messages_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_sent_message_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_sent_message_id_foreign FOREIGN KEY (sent_message_id) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: scheduled_sales_reports scheduled_sales_reports_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_sales_reports
    ADD CONSTRAINT scheduled_sales_reports_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shop_order_items shop_order_items_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: shop_order_items shop_order_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: shop_order_items shop_order_items_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_order_items
    ADD CONSTRAINT shop_order_items_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: shop_reply_templates shop_reply_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_reply_templates
    ADD CONSTRAINT shop_reply_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: shop_reply_templates shop_reply_templates_facebook_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_reply_templates
    ADD CONSTRAINT shop_reply_templates_facebook_page_id_foreign FOREIGN KEY (facebook_page_id) REFERENCES public.facebook_pages(id) ON DELETE SET NULL;


--
-- Name: sms_campaigns sms_campaigns_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_campaigns
    ADD CONSTRAINT sms_campaigns_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sms_logs sms_logs_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.sms_campaigns(id) ON DELETE SET NULL;


--
-- Name: sms_logs sms_logs_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: sms_logs sms_logs_sequence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_sequence_id_foreign FOREIGN KEY (sequence_id) REFERENCES public.sms_sequences(id) ON DELETE SET NULL;


--
-- Name: sms_logs sms_logs_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: sms_sequence_enrollments sms_sequence_enrollments_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_enrollments
    ADD CONSTRAINT sms_sequence_enrollments_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: sms_sequence_enrollments sms_sequence_enrollments_sequence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_enrollments
    ADD CONSTRAINT sms_sequence_enrollments_sequence_id_foreign FOREIGN KEY (sequence_id) REFERENCES public.sms_sequences(id) ON DELETE CASCADE;


--
-- Name: sms_sequence_enrollments sms_sequence_enrollments_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_enrollments
    ADD CONSTRAINT sms_sequence_enrollments_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: sms_sequence_steps sms_sequence_steps_sequence_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequence_steps
    ADD CONSTRAINT sms_sequence_steps_sequence_id_foreign FOREIGN KEY (sequence_id) REFERENCES public.sms_sequences(id) ON DELETE CASCADE;


--
-- Name: sms_sequences sms_sequences_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_sequences
    ADD CONSTRAINT sms_sequences_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sms_templates sms_templates_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_templates
    ADD CONSTRAINT sms_templates_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_adjustments stock_adjustments_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_adjustments stock_adjustments_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: stock_adjustments stock_adjustments_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: stock_adjustments stock_adjustments_submitted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_submitted_by_foreign FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: stock_adjustments stock_adjustments_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE SET NULL;


--
-- Name: stock_adjustments stock_adjustments_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: stock_adjustments stock_adjustments_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: stock_audit_items stock_audit_items_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items
    ADD CONSTRAINT stock_audit_items_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: stock_audit_items stock_audit_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items
    ADD CONSTRAINT stock_audit_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: stock_audit_items stock_audit_items_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items
    ADD CONSTRAINT stock_audit_items_session_id_foreign FOREIGN KEY (session_id) REFERENCES public.stock_audit_sessions(id) ON DELETE CASCADE;


--
-- Name: stock_audit_items stock_audit_items_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items
    ADD CONSTRAINT stock_audit_items_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE SET NULL;


--
-- Name: stock_audit_items stock_audit_items_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_items
    ADD CONSTRAINT stock_audit_items_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: stock_audit_sessions stock_audit_sessions_finalized_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_sessions
    ADD CONSTRAINT stock_audit_sessions_finalized_by_foreign FOREIGN KEY (finalized_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_audit_sessions stock_audit_sessions_started_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_sessions
    ADD CONSTRAINT stock_audit_sessions_started_by_foreign FOREIGN KEY (started_by) REFERENCES public.users(id);


--
-- Name: stock_audit_sessions stock_audit_sessions_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_audit_sessions
    ADD CONSTRAINT stock_audit_sessions_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: stock_cost_lots stock_cost_lots_grn_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_lots
    ADD CONSTRAINT stock_cost_lots_grn_item_id_foreign FOREIGN KEY (grn_item_id) REFERENCES public.receiving_report_items(id) ON DELETE SET NULL;


--
-- Name: stock_cost_lots stock_cost_lots_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_lots
    ADD CONSTRAINT stock_cost_lots_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_cost_lots stock_cost_lots_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_lots
    ADD CONSTRAINT stock_cost_lots_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: stock_cost_lots stock_cost_lots_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_cost_lots
    ADD CONSTRAINT stock_cost_lots_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: stock_reservations stock_reservations_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_reservations stock_reservations_reserved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_reserved_by_foreign FOREIGN KEY (reserved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: stock_reservations stock_reservations_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_third_party_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_third_party_id_foreign FOREIGN KEY (third_party_id) REFERENCES public.third_parties(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplies supplies_uom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_uom_id_foreign FOREIGN KEY (uom_id) REFERENCES public.units_of_measure(id) ON DELETE SET NULL;


--
-- Name: supply_movements supply_movements_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supply_movements supply_movements_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: supply_movements supply_movements_performed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_performed_by_foreign FOREIGN KEY (performed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supply_movements supply_movements_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE CASCADE;


--
-- Name: supply_movements supply_movements_to_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_to_location_id_foreign FOREIGN KEY (to_location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: supply_movements supply_movements_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_movements
    ADD CONSTRAINT supply_movements_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: supply_stocks supply_stocks_location_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_stocks
    ADD CONSTRAINT supply_stocks_location_id_foreign FOREIGN KEY (location_id) REFERENCES public.warehouse_locations(id) ON DELETE SET NULL;


--
-- Name: supply_stocks supply_stocks_supply_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_stocks
    ADD CONSTRAINT supply_stocks_supply_id_foreign FOREIGN KEY (supply_id) REFERENCES public.supplies(id) ON DELETE CASCADE;


--
-- Name: supply_stocks supply_stocks_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_stocks
    ADD CONSTRAINT supply_stocks_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: third_parties third_parties_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.third_parties
    ADD CONSTRAINT third_parties_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: third_parties third_parties_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.third_parties
    ADD CONSTRAINT third_parties_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: third_parties third_parties_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.third_parties
    ADD CONSTRAINT third_parties_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ticket_canned_responses ticket_canned_responses_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_canned_responses
    ADD CONSTRAINT ticket_canned_responses_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ticket_comments ticket_comments_ticket_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_ticket_id_foreign FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_comments ticket_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_assigned_to_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_assigned_to_foreign FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: unknown_waybill_scans unknown_waybill_scans_resolved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unknown_waybill_scans
    ADD CONSTRAINT unknown_waybill_scans_resolved_by_foreign FOREIGN KEY (resolved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: unknown_waybill_scans unknown_waybill_scans_resolved_to_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unknown_waybill_scans
    ADD CONSTRAINT unknown_waybill_scans_resolved_to_waybill_id_foreign FOREIGN KEY (resolved_to_waybill_id) REFERENCES public.waybills(id) ON DELETE SET NULL;


--
-- Name: unknown_waybill_scans unknown_waybill_scans_scanned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unknown_waybill_scans
    ADD CONSTRAINT unknown_waybill_scans_scanned_by_foreign FOREIGN KEY (scanned_by) REFERENCES public.users(id);


--
-- Name: uploads uploads_retry_of_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_retry_of_foreign FOREIGN KEY (retry_of) REFERENCES public.uploads(id) ON DELETE SET NULL;


--
-- Name: uploads uploads_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.uploads
    ADD CONSTRAINT uploads_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_module_access user_module_access_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_module_access
    ADD CONSTRAINT user_module_access_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: warehouse_locations warehouse_locations_warehouse_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_warehouse_id_foreign FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: waybill_tracking_history waybill_tracking_history_waybill_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybill_tracking_history
    ADD CONSTRAINT waybill_tracking_history_waybill_id_foreign FOREIGN KEY (waybill_id) REFERENCES public.waybills(id) ON DELETE CASCADE;


--
-- Name: waybills waybills_lead_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_lead_id_foreign FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: waybills waybills_upload_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_upload_id_foreign FOREIGN KEY (upload_id) REFERENCES public.uploads(id) ON DELETE SET NULL;


--
-- Name: waybills waybills_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waybills
    ADD CONSTRAINT waybills_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict dsYlgNfZzfKEZDKQ2NN8DEyzyOQSxZMlvfF8RvUnUa03SfoNVIH9GjSpUzoOf1G

